# -*- coding: utf-8 -*-
"""Atelier familles : tout pour creer des familles d'equipement CVC
parametrees, dans une seule fenetre.
1. Creer    : generateur (caisson, socle, viroles rectangulaires ou rondes,
              connecteurs de gaine) -> famille .rfa chargee dans le projet
2. Modifier : dans l'editeur de famille, cadrer une extrusion (plans de
              reference, cotes EQ, cadenas) et ajouter des viroles en
              cliquant sur une face
3. Parametres CVC courants (Local traite, Debit, pdc, puissances...)
4. Verifier : test de flexion de toutes les cotes"""

__title__ = "Atelier\nfamilles"

import os
import copy
from pyrevit import revit, DB, forms, script
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from System.Windows import Visibility, Thickness
from System.Windows.Controls import CheckBox, TextBox, TextBlock, StackPanel, Orientation, ListBoxItem, Canvas
from System.Windows.Media import SolidColorBrush, Color, DoubleCollection
from System.Windows.Shapes import Rectangle, Ellipse
from System.Windows.Input import Mouse, Cursors
import allan_familles as af

doc = revit.doc
uidoc = revit.uidoc
app = doc.Application
EST_FAMILLE = doc.IsFamilyDocument

def _dossier_extension(p):
    """Remonte jusqu'au dossier .extension (marche meme si le bouton
    est range dans un menu deroulant)."""
    while not p.lower().endswith(".extension") and os.path.dirname(p) != p:
        p = os.path.dirname(p)
    return p


ext_dir = _dossier_extension(os.path.abspath(__file__))
DOSSIER_DEF = os.path.join(ext_dir, "Familles", "Equipements")
PERSO = u"Personnalisé"

COULEUR = {u"Soufflage": (70, 140, 255), u"Reprise": (230, 80, 200),
           u"Extraction": (80, 200, 90), u"Air neuf / autre": (255, 170, 60)}


def brush(r, g, b, a=255):
    return SolidColorBrush(Color.FromArgb(a, r, g, b))


def num(txt, defaut=0.0):
    try:
        return float(unicode(txt).replace(u",", u".").strip())
    except Exception:
        return defaut


class FiltreForme(ISelectionFilter):
    def AllowElement(self, el):
        return isinstance(el, DB.GenericForm)

    def AllowReference(self, ref, pt):
        return True


# controles dont on garde la valeur quand la fenetre se ferme / se rouvre
TEXTES = ["t_famille", "t_type", "t_larg", "t_long", "t_haut", "t_hsocle", "t_debord", "t_dossier",
          "v_larg", "v_haut", "v_sail", "v_dec", "c_larg", "c_long", "c_haut",
          "m_larg", "m_haut", "m_sail", "m_dec", "i_fab", "i_mod", "i_desc"]
CASES = ["chk_socle", "chk_occ", "chk_charger", "chk_placer", "c_centrer", "c_occ", "m_occ"]
LISTES = ["cb_modele", "v_face", "v_forme", "v_classe", "v_sens", "m_forme", "m_classe", "m_sens", "cb_fam"]


class Atelier(forms.WPFWindow):
    def __init__(self, xaml, etat):
        self.pret = False
        forms.WPFWindow.__init__(self, xaml)
        self.etat = etat
        self.action = None
        self.viroles = copy.deepcopy(etat.get("viroles", []))
        self.familles = []
        # listes
        self.cb_modele.ItemsSource = [m[0] for m in af.MODELES] + [PERSO]
        for cb in (self.v_face,):
            cb.ItemsSource = af.FACES
        for cb in (self.v_forme, self.m_forme):
            cb.ItemsSource = af.FORMES
        for cb in (self.v_classe, self.m_classe):
            cb.ItemsSource = af.CLASSES
        for cb in (self.v_sens, self.m_sens):
            cb.ItemsSource = af.SENS
        self._params_ui()
        self._familles_ui()
        # onglet 2 : seulement dans l'editeur de famille
        if not EST_FAMILLE:
            self.m_info.Visibility = Visibility.Visible
            self.m_gauche.IsEnabled = False
            self.m_droite.IsEnabled = False
            self.b_params.Content = u"(les paramètres cochés seront ajoutés aux familles générées)"
            self.b_params.IsEnabled = False
            self.p_aide.Text = (u"Coche les paramètres à ajouter : ils seront mis dans chaque famille générée "
                                u"(onglet Créer). Dans l'éditeur de famille, le bouton les ajoute à la famille ouverte.")
        else:
            self.chk_charger.IsEnabled = False
            self.chk_placer.IsEnabled = False
            self.p_aide.Text = u"Coche les paramètres à ajouter à la famille ouverte (ou à mettre à jour), puis valide."
        if etat:
            self._restaurer()
        else:
            self.cb_modele.SelectedIndex = 0
            self.v_face.SelectedIndex = 0
            self.v_forme.SelectedIndex = 0
            self.v_classe.SelectedIndex = 0
            self.v_sens.SelectedIndex = 2
            self.m_forme.SelectedIndex = 0
            self.m_classe.SelectedIndex = 0
            self.m_sens.SelectedIndex = 2
            self.t_dossier.Text = DOSSIER_DEF
            self.v_larg.Text, self.v_haut.Text, self.v_sail.Text, self.v_dec.Text = u"400", u"300", u"50", u"0"
            self._appliquer_modele(0)
            if EST_FAMILLE:
                self.tabs.SelectedIndex = 1
        self.pret = True
        self._liste_vir()
        self._dessiner()

    # ------------------------------------------------------------ etat
    def _sauver(self):
        e = {"viroles": copy.deepcopy(self.viroles), "tab": self.tabs.SelectedIndex,
             "journal": self.journal.Text, "params": {}}
        for n in TEXTES:
            e[n] = getattr(self, n).Text
        for n in CASES:
            e[n] = bool(getattr(self, n).IsChecked)
        for n in LISTES:
            e[n] = getattr(self, n).SelectedIndex
        for nom, (cb, tb) in self.ctl_params.items():
            e["params"][nom] = (bool(cb.IsChecked), tb.Text)
        self.etat.clear()
        self.etat.update(e)

    def _restaurer(self):
        e = self.etat
        self.pret = False
        for n in LISTES:
            try:
                getattr(self, n).SelectedIndex = e.get(n, 0)
            except Exception:
                pass
        for n in TEXTES:
            if n in e:
                getattr(self, n).Text = e[n]
        for n in CASES:
            if n in e:
                getattr(self, n).IsChecked = e[n]
        for nom, (c, v) in e.get("params", {}).items():
            if nom in self.ctl_params:
                self.ctl_params[nom][0].IsChecked = c
                self.ctl_params[nom][1].Text = v
        self.journal.Text = e.get("journal", u"")
        self.tabs.SelectedIndex = e.get("tab", 0)

    def log(self, lignes):
        if isinstance(lignes, basestring):
            lignes = [lignes]
        txt = u"\n".join(l for l in lignes if l)
        self.journal.Text = (txt + u"\n" + self.journal.Text).strip()

    # ------------------------------------------------------------ onglet 1
    def _appliquer_modele(self, i):
        if i < 0 or i >= len(af.MODELES):
            return
        m = af.MODELES[i][1]
        self.pret = False
        self.t_famille.Text = m["famille"]
        self.t_type.Text = m["type"]
        self.t_larg.Text = unicode(m["largeur"])
        self.t_long.Text = unicode(m["longueur"])
        self.t_haut.Text = unicode(m["hauteur"])
        self.chk_socle.IsChecked = m["socle"]
        self.t_hsocle.Text = unicode(m["h_socle"])
        self.t_debord.Text = unicode(m["debord"])
        self.viroles = copy.deepcopy(m["viroles"])
        self.pret = True
        self._liste_vir()
        self._dessiner()

    def on_modele(self, s, a):
        if self.pret:
            self._appliquer_modele(self.cb_modele.SelectedIndex)

    def on_change(self, s, a):
        if self.pret:
            self.g_socle.IsEnabled = bool(self.chk_socle.IsChecked)
            self._dessiner()

    def _texte_vir(self, i, v):
        if v["forme"] == u"Ronde":
            dim = u"Ø%g" % v["larg"]
        else:
            dim = u"%gx%g" % (v["larg"], v["haut"])
        dec = (u", décalée %+g" % v["decalage"]) if v.get("decalage") else u""
        return u"V%d  %s  %s  (saillie %g%s)\n      %s - %s" % (i + 1, v["face"], dim, v["saillie"], dec, v["classe"], v["sens"])

    def _liste_vir(self):
        sel = self.lst_vir.SelectedIndex
        self.lst_vir.ItemsSource = [self._texte_vir(i, v) for i, v in enumerate(self.viroles)]
        if 0 <= sel < len(self.viroles):
            self.lst_vir.SelectedIndex = sel

    def _vir_editeur(self):
        ronde = self.v_forme.SelectedItem == u"Ronde"
        return {"face": self.v_face.SelectedItem or af.FACES[0],
                "forme": self.v_forme.SelectedItem or af.FORMES[0],
                "larg": num(self.v_larg.Text, 300), "haut": num(self.v_larg.Text if ronde else self.v_haut.Text, 200),
                "saillie": num(self.v_sail.Text, 50), "decalage": num(self.v_dec.Text, 0),
                "classe": self.v_classe.SelectedItem or af.CLASSES[0], "sens": self.v_sens.SelectedItem or af.SENS[2]}

    def on_vir_select(self, s, a):
        i = self.lst_vir.SelectedIndex
        if not (0 <= i < len(self.viroles)):
            return
        v = self.viroles[i]
        self.v_face.SelectedItem = v["face"]
        self.v_forme.SelectedItem = v["forme"]
        self.v_larg.Text = u"%g" % v["larg"]
        self.v_haut.Text = u"%g" % v["haut"]
        self.v_sail.Text = u"%g" % v["saillie"]
        self.v_dec.Text = u"%g" % (v.get("decalage") or 0)
        self.v_classe.SelectedItem = v["classe"]
        self.v_sens.SelectedItem = v["sens"]

    def on_forme(self, s, a):
        ronde = self.v_forme.SelectedItem == u"Ronde"
        self.v_l_lbl.Text = u"Diamètre (mm)" if ronde else u"Largeur (mm)"
        self.v_haut.IsEnabled = not ronde

    def on_mforme(self, s, a):
        ronde = self.m_forme.SelectedItem == u"Ronde"
        self.m_l_lbl.Text = u"Diamètre (mm)" if ronde else u"Largeur (mm)"
        self.m_haut.IsEnabled = not ronde

    def on_vir_add(self, s, a):
        self.viroles.append(self._vir_editeur())
        self._liste_vir()
        self.lst_vir.SelectedIndex = len(self.viroles) - 1
        self._perso()
        self._dessiner()

    def on_vir_mod(self, s, a):
        i = self.lst_vir.SelectedIndex
        if 0 <= i < len(self.viroles):
            self.viroles[i] = self._vir_editeur()
            self._liste_vir()
            self._perso()
            self._dessiner()

    def on_vir_del(self, s, a):
        i = self.lst_vir.SelectedIndex
        if 0 <= i < len(self.viroles):
            del self.viroles[i]
            self._liste_vir()
            self._perso()
            self._dessiner()

    def _perso(self):
        self.pret = False
        self.cb_modele.SelectedItem = PERSO
        self.pret = True

    def on_dossier(self, s, a):
        d = forms.pick_folder()
        if d:
            self.t_dossier.Text = d

    def _spec(self):
        spec = {"famille": (self.t_famille.Text or u"Equipement").strip(),
                "type": (self.t_type.Text or u"Standard").strip(),
                "largeur": num(self.t_larg.Text, 0), "longueur": num(self.t_long.Text, 0), "hauteur": num(self.t_haut.Text, 0),
                "socle": bool(self.chk_socle.IsChecked), "h_socle": num(self.t_hsocle.Text, 150),
                "debord": num(self.t_debord.Text, 100), "occurrence": bool(self.chk_occ.IsChecked),
                "viroles": copy.deepcopy(self.viroles), "params": self._params_coches(),
                "infos": {u"Fabricant": self.i_fab.Text, u"Modèle": self.i_mod.Text, u"Description": self.i_desc.Text}}
        return spec

    def _verifier(self, spec):
        err = []
        for k, n in (("largeur", u"Largeur"), ("longueur", u"Longueur"), ("hauteur", u"Hauteur")):
            if spec[k] < 50:
                err.append(u"%s trop petite (mini 50 mm)" % n)
        bad = u'\\/:*?"<>|'
        if any(c in spec["famille"] for c in bad):
            err.append(u"Le nom de famille contient un caractère interdit (\\ / : * ? \" < > |)")
        for i, v in enumerate(spec["viroles"]):
            fk = af.FACE_KEY[v["face"]]
            if fk[0] == "Z":
                da, db_ = spec["largeur"], spec["longueur"]
            elif fk[0] == "X":
                da, db_ = spec["longueur"], spec["hauteur"]
            else:
                da, db_ = spec["largeur"], spec["hauteur"]
            ha = v["larg"] if v["forme"] == u"Ronde" else v["haut"]
            if abs(v.get("decalage") or 0) + v["larg"] / 2.0 > da / 2.0 or ha > db_:
                err.append(u"V%d dépasse de la face %s" % (i + 1, v["face"]))
            if v["saillie"] <= 0 or v["larg"] <= 0 or ha <= 0:
                err.append(u"V%d : cotes nulles" % (i + 1))
        return err

    def on_generer(self, s, a):
        spec = self._spec()
        err = self._verifier(spec)
        if err:
            self.log([u"Génération annulée :"] + [u" - " + e for e in err])
            return
        dossier = self.t_dossier.Text.strip() or DOSSIER_DEF
        chemin = os.path.join(dossier, spec["famille"] + u".rfa")
        if os.path.exists(chemin):
            if not forms.alert(u"%s existe déjà.\nL'écraser ?" % chemin, yes=True, no=True):
                return
        Mouse.OverrideCursor = Cursors.Wait
        log = []
        try:
            chemin = af.generer(app, spec, dossier, log)
        except Exception as ex:
            log.append(u"Erreur : %s" % ex)
            chemin = None
        finally:
            Mouse.OverrideCursor = None
        if chemin and not EST_FAMILLE and self.chk_charger.IsChecked:
            sym = af.charger(doc, chemin, log)
            if sym is not None:
                log.append(u"Chargée dans le projet : %s : %s" % (sym.FamilyName, spec["type"]))
                self._familles_ui()
                if self.chk_placer.IsChecked:
                    self.action = ("placer", sym.Id)
                    self.log(log)
                    self._sauver()
                    self.Close()
                    return
        self.log(log if chemin else log + [u"La famille n'a pas été créée."])

    # ------------------------------------------------------------ apercu
    def _dessiner(self):
        if not self.pret:
            return
        try:
            self._dessiner_vue(self.cv_face, "face")
            self._dessiner_vue(self.cv_plan, "plan")
        except Exception as ex:
            self.legende.Text = u"Aperçu impossible : %s" % ex
            return
        noms = sorted(set(v["classe"] for v in self.viroles))
        self.legende.Text = u"Couleurs : " + u", ".join(
            u"%s %s" % (n, {u"Soufflage": u"(bleu)", u"Reprise": u"(rose)", u"Extraction": u"(vert)",
                            u"Air neuf / autre": u"(orange)"}.get(n, u"")) for n in noms) if noms else u""

    def _dessiner_vue(self, cv, vue):
        cv.Children.Clear()
        W = cv.ActualWidth if cv.ActualWidth > 50 else 420.0
        Hc = cv.ActualHeight if cv.ActualHeight > 50 else 215.0
        Lx, Ly, H = num(self.t_larg.Text, 0), num(self.t_long.Text, 0), num(self.t_haut.Text, 0)
        if Lx <= 0 or Ly <= 0 or H <= 0:
            return
        socle = bool(self.chk_socle.IsChecked)
        hs, deb = (num(self.t_hsocle.Text, 0), num(self.t_debord.Text, 0)) if socle else (0.0, 0.0)
        sail_max = max([v["saillie"] for v in self.viroles] + [0])
        if vue == "face":
            ext_w, ext_h = Lx + 2 * max(deb, sail_max), hs + H + sail_max
        else:
            ext_w, ext_h = Lx + 2 * max(deb, sail_max), Ly + 2 * max(deb, sail_max)
        k = min((W - 30) / ext_w, (Hc - 30) / ext_h)
        cx, cy = W / 2.0, Hc / 2.0
        if vue == "face":
            base = cy + (hs + H) * k / 2.0 - sail_max * k / 2.0

            def P(x, z):
                return cx + x * k, base - z * k
        else:
            def P(x, y):
                return cx + x * k, cy - y * k

        def rect(x0, y0, x1, y1, fill, stroke, dash=False, thick=1.2):
            (a1, b1), (a2, b2) = P(x0, y0), P(x1, y1)
            r = Rectangle()
            r.Width = abs(a2 - a1)
            r.Height = abs(b2 - b1)
            r.Fill = fill
            r.Stroke = stroke
            r.StrokeThickness = thick
            if dash:
                dc = DoubleCollection()
                dc.Add(4)
                dc.Add(3)
                r.StrokeDashArray = dc
            Canvas.SetLeft(r, min(a1, a2))
            Canvas.SetTop(r, min(b1, b2))
            cv.Children.Add(r)

        def rond(xc, yc, d, fill, stroke):
            (a, b) = P(xc, yc)
            e = Ellipse()
            e.Width = e.Height = d * k
            e.Fill = fill
            e.Stroke = stroke
            e.StrokeThickness = 1.2
            Canvas.SetLeft(e, a - d * k / 2.0)
            Canvas.SetTop(e, b - d * k / 2.0)
            cv.Children.Add(e)

        gris = brush(150, 150, 150)
        if vue == "face":
            if socle:
                rect(-Lx / 2 - deb, 0, Lx / 2 + deb, hs, brush(90, 90, 90), gris)
            rect(-Lx / 2, hs, Lx / 2, hs + H, brush(70, 70, 75), brush(220, 220, 220))
        else:
            if socle:
                rect(-Lx / 2 - deb, -Ly / 2 - deb, Lx / 2 + deb, Ly / 2 + deb, brush(90, 90, 90), gris)
            rect(-Lx / 2, -Ly / 2, Lx / 2, Ly / 2, brush(70, 70, 75), brush(220, 220, 220))
        zm = hs + H / 2.0
        for v in self.viroles:
            col = COULEUR.get(v["classe"], (200, 200, 200))
            f, s_ = brush(col[0], col[1], col[2], 150), brush(col[0], col[1], col[2])
            ronde = v["forme"] == u"Ronde"
            l_, h_ = v["larg"], (v["larg"] if ronde else v["haut"])
            dec, sl = v.get("decalage") or 0, v["saillie"]
            face = v["face"]
            if vue == "face":
                if face in (u"Avant", u"Arrière"):
                    if ronde:
                        rond(dec, zm, l_, f if face == u"Avant" else brush(0, 0, 0, 0), s_)
                    else:
                        rect(dec - l_ / 2, zm - h_ / 2, dec + l_ / 2, zm + h_ / 2,
                             f if face == u"Avant" else brush(0, 0, 0, 0), s_, dash=(face == u"Arrière"))
                elif face == u"Gauche":
                    rect(-Lx / 2 - sl, zm - h_ / 2, -Lx / 2, zm + h_ / 2, f, s_)
                elif face == u"Droite":
                    rect(Lx / 2, zm - h_ / 2, Lx / 2 + sl, zm + h_ / 2, f, s_)
                else:
                    rect(dec - l_ / 2, hs + H, dec + l_ / 2, hs + H + sl, f, s_)
            else:
                if face == u"Avant":
                    rect(dec - l_ / 2, -Ly / 2 - sl, dec + l_ / 2, -Ly / 2, f, s_)
                elif face == u"Arrière":
                    rect(dec - l_ / 2, Ly / 2, dec + l_ / 2, Ly / 2 + sl, f, s_)
                elif face == u"Gauche":
                    rect(-Lx / 2 - sl, dec - l_ / 2, -Lx / 2, dec + l_ / 2, f, s_)
                elif face == u"Droite":
                    rect(Lx / 2, dec - l_ / 2, Lx / 2 + sl, dec + l_ / 2, f, s_)
                else:
                    if ronde:
                        rond(dec, 0, l_, f, s_)
                    else:
                        rect(dec - l_ / 2, -h_ / 2, dec + l_ / 2, h_ / 2, f, s_)

    # ------------------------------------------------------------ onglet 2
    def _mvir(self):
        ronde = self.m_forme.SelectedItem == u"Ronde"
        return {"face": u"", "forme": self.m_forme.SelectedItem or af.FORMES[0],
                "larg": num(self.m_larg.Text, 300), "haut": num(self.m_larg.Text if ronde else self.m_haut.Text, 200),
                "saillie": num(self.m_sail.Text, 50), "decalage": num(self.m_dec.Text, 0),
                "classe": self.m_classe.SelectedItem or af.CLASSES[0], "sens": self.m_sens.SelectedItem or af.SENS[2]}

    def on_cadrer(self, s, a):
        noms = [self.c_larg.Text.strip(), self.c_long.Text.strip(), self.c_haut.Text.strip()]
        if not all(noms) or len(set(noms)) < 3:
            self.log(u"Donne 3 noms de paramètres différents.")
            return
        self.action = ("cadrer", noms, bool(self.c_centrer.IsChecked), bool(self.c_occ.IsChecked))
        self._sauver()
        self.Close()

    def on_virole(self, s, a):
        self.action = ("virole", self._mvir(), bool(self.m_occ.IsChecked))
        self._sauver()
        self.Close()

    # ------------------------------------------------------------ onglet 3
    def _params_ui(self):
        self.ctl_params = {}
        for nom, spec, grp, inst, unite, defaut in af.PARAMS_CVC:
            sp = StackPanel()
            sp.Orientation = Orientation.Horizontal
            sp.Margin = Thickness(0, 2, 0, 2)
            cb = CheckBox()
            cb.Content = nom
            cb.Width = 230
            cb.IsChecked = nom in (u"Local traité",)
            tb = TextBox()
            tb.Width = 110
            tb.Text = defaut
            un = TextBlock()
            un.Margin = Thickness(8, 0, 0, 0)
            un.Text = {"CubicMetersPerHour": u"m³/h", "PascalsPerMeter": u"Pa/m", "Pascals": u"Pa",
                       "Watts": u"W", "Kilograms": u"kg"}.get(unite, u"texte" if spec == "texte" else u"")
            un.Text += u"   (%s)" % (u"occurrence" if inst else u"type")
            sp.Children.Add(cb)
            sp.Children.Add(tb)
            sp.Children.Add(un)
            self.sp_params.Children.Add(sp)
            self.ctl_params[nom] = (cb, tb)

    def _params_coches(self):
        return [(nom, tb.Text) for nom, (cb, tb) in self.ctl_params.items() if cb.IsChecked]

    def on_params(self, s, a):
        if not EST_FAMILLE:
            return
        infos = [(u"Fabricant", self.i_fab.Text), (u"Modèle", self.i_mod.Text), (u"Description", self.i_desc.Text)]
        log = []
        af.ajouter_parametres(doc, self._params_coches(), infos, log)
        self.log(log)

    # ------------------------------------------------------------ onglet 4
    def _familles_ui(self):
        sel = self.cb_fam.SelectedIndex
        if EST_FAMILLE:
            self.familles = [None]
            self.cb_fam.ItemsSource = [u"Famille ouverte : " + doc.Title]
        else:
            cats = [int(DB.BuiltInCategory.OST_MechanicalEquipment), int(DB.BuiltInCategory.OST_DuctTerminal),
                    int(DB.BuiltInCategory.OST_GenericModel), int(DB.BuiltInCategory.OST_PlumbingFixtures),
                    int(DB.BuiltInCategory.OST_SpecialityEquipment)]
            fams = []
            for f in DB.FilteredElementCollector(doc).OfClass(DB.Family):
                try:
                    c = f.FamilyCategory
                    cid = c.Id.Value if hasattr(c.Id, "Value") else c.Id.IntegerValue
                    if f.IsEditable and not f.IsInPlace and cid in cats:
                        fams.append(f)
                except Exception:
                    pass
            fams.sort(key=lambda f: f.Name.lower())
            self.familles = fams
            self.cb_fam.ItemsSource = [u"%s   (%s)" % (f.Name, f.FamilyCategory.Name) for f in fams]
        self.cb_fam.SelectedIndex = sel if 0 <= sel < len(self.familles) else (0 if self.familles else -1)

    def on_tester(self, s, a):
        i = self.cb_fam.SelectedIndex
        if i < 0:
            self.log(u"Aucune famille à tester.")
            return
        Mouse.OverrideCursor = Cursors.Wait
        fd = None
        try:
            if EST_FAMILLE:
                fd = doc
            else:
                fd = doc.EditFamily(self.familles[i])
            res = af.test_flexion(fd)
        except Exception as ex:
            res = [(u"(erreur)", False, unicode(ex))]
        finally:
            if fd is not None and not EST_FAMILLE:
                try:
                    fd.Close(False)
                except Exception:
                    pass
            Mouse.OverrideCursor = None
        items = []
        nok = 0
        for nom, ok, msg in sorted(res, key=lambda r: (r[1], r[0])):
            it = ListBoxItem()
            it.Content = (u"✔  " if ok else u"✘  ") + nom + u"  —  " + msg
            it.Foreground = brush(110, 220, 120) if ok else brush(255, 110, 110)
            items.append(it)
            nok += 0 if ok else 1
        self.lst_res.ItemsSource = items
        self.v_resume.Text = (u"%d cote(s) testée(s) : tout est OK" % len(res)) if nok == 0 else \
            (u"%d cote(s) testée(s) : %d problème(s)" % (len(res), nok))


# ================================================================ boucle
xaml = os.path.join(os.path.dirname(__file__), "ui.xaml")
etat = {}
while True:
    w = Atelier(xaml, etat)
    w.show_dialog()
    act = w.action
    if act is None:
        break
    log = []
    try:
        if act[0] == "placer":
            sym = doc.GetElement(act[1])
            try:
                uidoc.PromptForFamilyInstancePlacement(sym)
            except Exception:
                pass
            break
        elif act[0] == "cadrer":
            try:
                ref = uidoc.Selection.PickObject(ObjectType.Element, FiltreForme(), u"Clique sur l'extrusion à cadrer (Echap pour annuler)")
                el = doc.GetElement(ref)
                af.cadrer_extrusion(doc, el, act[1], act[2], act[3], log)
            except Exception as ex:
                if "cancel" in unicode(ex).lower() or "annul" in unicode(ex).lower():
                    log.append(u"Annulé.")
                else:
                    log.append(u"Erreur : %s" % ex)
        elif act[0] == "virole":
            try:
                ref = uidoc.Selection.PickObject(ObjectType.Face, FiltreForme(),
                                                 u"Clique sur la face où poser la virole (Echap pour annuler)")
                el = doc.GetElement(ref)
                geo = el.GetGeometryObjectFromReference(ref)
                if not isinstance(geo, DB.PlanarFace):
                    log.append(u"Choisis une face plane.")
                else:
                    af.ajouter_virole(doc, el, geo.FaceNormal, act[1], act[2], log)
            except Exception as ex:
                if "cancel" in unicode(ex).lower() or "annul" in unicode(ex).lower():
                    log.append(u"Annulé.")
                else:
                    log.append(u"Erreur : %s" % ex)
    except Exception as ex:
        log.append(u"Erreur : %s" % ex)
    etat["journal"] = (u"\n".join(log) + u"\n" + etat.get("journal", u"")).strip()
