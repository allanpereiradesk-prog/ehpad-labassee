# -*- coding: utf-8 -*-
"""Controle qualite des reseaux du projet :
- bouts non raccordes (gaines, canalisations, raccords, bouches)
- pentes des evacuations (a plat, trop faibles, contre-pentes)
- gaines / canalisations sans systeme
- calorifuge manquant (chauffage, eau glacee, ECS, soufflage)
Le panneau liste les defauts et montre chacun en 3D (element en rouge).
Rien n'est modifie dans le projet."""

__title__ = "Controle\nqualite"

import os
import io
from pyrevit import revit, DB, forms, script
from Autodesk.Revit.UI import PreviewControl
from System.Collections.Generic import List
from System.Windows.Input import Mouse, Cursors
import allan_clash as ac
import allan_controle as ctl

doc = revit.doc
uidoc = revit.uidoc


class ControleWindow(forms.WPFWindow):
    def __init__(self, xaml, defauts):
        self.maj = True
        forms.WPFWindow.__init__(self, xaml)
        self.defauts = defauts
        self.vus = []            # defauts affiches (apres filtre)
        self.cur = None
        self.pc = None
        self.vues = {}
        self.zoom = 1.0
        self.a_selectionner = []
        self.maj = False
        self.Loaded += self._charge
        self.Closed += self._ferme

    def _attente(self, on):
        try:
            Mouse.OverrideCursor = Cursors.Wait if on else None
        except Exception:
            pass

    def _drop(self):
        try:
            self.host.Children.Clear()
            if self.pc is not None:
                self.pc.Dispose()
        except Exception:
            pass
        self.pc = None

    def _preview(self):
        self._drop()
        vid = self.vues.get("3d" if self.chk_3d.IsChecked else "coupe")
        if vid is None:
            return
        try:
            self.pc = PreviewControl(doc, vid)
            self.host.Children.Add(self.pc)
        except Exception as ex:
            self.info.Text = "Apercu impossible : %s" % ex

    # ---- liste
    def _charge(self, s, a):
        self._filtres()

    def _filtres(self):
        items = ["Tous les defauts (%d)" % len(self.defauts)]
        for t in ctl.TYPES:
            items.append("%s (%d)" % (t, len([d for d in self.defauts if d.type == t])))
        self.maj = True
        self.cmb.ItemsSource = items
        self.cmb.SelectedIndex = 0
        self.maj = False
        self._liste()

    def _liste(self):
        k = self.cmb.SelectedIndex
        self.vus = self.defauts if k <= 0 else [d for d in self.defauts if d.type == ctl.TYPES[k - 1]]
        self.titre.Text = "%d defaut(s) dans le projet, %d affiche(s)" % (len(self.defauts), len(self.vus))
        self.maj = True
        self.lst.ItemsSource = [d.ligne() for d in self.vus]
        self.lst.SelectedIndex = 0 if self.vus else -1
        self.maj = False
        self.cur = self.vus[0] if self.vus else None
        self._montrer()

    def on_filtre(self, s, a):
        if not self.maj:
            self._liste()

    def on_select(self, s, a):
        if self.maj:
            return
        i = self.lst.SelectedIndex
        self.cur = self.vus[i] if 0 <= i < len(self.vus) else None
        self._montrer()

    def on_analyser(self, s, a):
        try:
            p = float(self.txt_pente.Text.replace(",", "."))
        except Exception:
            p = 1.0
        self._attente(True)
        try:
            self._drop()
            self.defauts = ctl.controler(doc, p)
        finally:
            self._attente(False)
        self._filtres()

    # ---- defaut selectionne
    def _montrer(self):
        self._attente(True)
        try:
            self._drop()
            d = self.cur
            if d is None:
                self.vues = {}
                self.leg.Text = ""
                self.info.Text = "Aucun defaut : rien a signaler."
                return
            self.leg.Text = "ROUGE = %s (id %s)" % (d.nom, ac.eid(d.id))
            self.info.Text = "%s : %s" % (d.type, d.texte)
            t = ac.tx_debut(doc, "Allan BIM - vue controle")
            try:
                self.vues = ac.preparer_vues(doc, ctl.Zone(d), self.zoom)
                ac.colorer(doc, [self.vues["coupe"], self.vues["3d"]], [d.id], ac.ROUGE)
                ac.valider_tx(t)
            except Exception as ex:
                t.RollBack()
                self.vues = {}
                self.info.Text += "\nVue impossible : %s" % ex
            self._preview()
        finally:
            self._attente(False)

    def on_plus(self, s, a):
        self.zoom = min(12.0, self.zoom * 1.5)
        self._montrer()

    def on_moins(self, s, a):
        self.zoom = max(0.4, self.zoom / 1.5)
        self._montrer()

    def on_3d(self, s, a):
        self._preview()

    # ---- actions
    def on_sel_un(self, s, a):
        if self.cur is not None:
            self.a_selectionner = [self.cur.id]
            self.Close()

    def on_sel_tous(self, s, a):
        self.a_selectionner = [d.id for d in self.vus]
        self.Close()

    def on_export(self, s, a):
        chemin = forms.save_file(file_ext="csv", default_name="controle_reseaux.csv")
        if not chemin:
            return
        with io.open(chemin, "w", encoding="utf-8-sig") as f:
            f.write(u"Type;Element;Id;Detail\n")
            for d in self.vus:
                f.write(u"%s;%s;%s;%s\n" % (d.type, d.nom, ac.eid(d.id), d.texte.replace(";", ",")))
        self.info.Text = "Liste exportee : %s" % chemin

    def on_fermer(self, s, a):
        self.Close()

    def _ferme(self, s, a):
        self._drop()
        t = ac.tx_debut(doc, "Allan BIM - nettoyage vues")
        try:
            ac.supprimer_vues(doc)
            t.Commit()
        except Exception:
            t.RollBack()
        self._attente(False)


if ac.nom(doc.ActiveView) in (ac.VUE_COUPE, ac.VUE_3D):
    forms.alert("Ferme d'abord la vue '%s' (elle sera recreee par l'outil)." % ac.nom(doc.ActiveView),
                title="Controle", exitscript=True)

defauts = ctl.controler(doc, 1.0)
if not defauts:
    forms.alert("Aucun defaut trouve : bouts raccordes, pentes, systemes et calorifuge sont bons.", title="Controle")
    script.exit()

w = ControleWindow(os.path.join(os.path.dirname(__file__), "ui.xaml"), defauts)
w.ShowDialog()
if w.a_selectionner:
    ids = List[DB.ElementId]()
    vus = set()
    for i in w.a_selectionner:
        if ac.eid(i) not in vus and doc.GetElement(i) is not None:
            vus.add(ac.eid(i))
            ids.Add(i)
    try:
        uidoc.Selection.SetElementIds(ids)
        uidoc.ShowElements(ids)
    except Exception as ex:
        forms.alert("Selection impossible : %s" % ex, title="Controle")
