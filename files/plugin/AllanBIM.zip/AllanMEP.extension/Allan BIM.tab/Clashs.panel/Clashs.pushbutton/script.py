# -*- coding: utf-8 -*-
"""Detecte tous les clashs du projet (gaines / canalisations qui se
traversent) et ouvre un panneau :
- liste des clashs, avec une coupe sur le clash (case "Coupe 3D" pour la
  voir en 3D)
- 3 solutions : passer dessus, passer dessous, proposition Allan BIM.
  Chaque solution est verifiee : elle ne cree aucun nouveau clash.
- cocher une solution = apercu dans la coupe, puis "Valider mon choix"
  (ou cocher "Refuser" pour laisser le clash tel quel)."""

__title__ = "Clashs"

import os
from pyrevit import revit, DB, forms, script
from Autodesk.Revit.UI import PreviewControl
from System.Windows.Input import Mouse, Cursors
import allan_clash as ac
import allan_relier as rel

doc = revit.doc
uidoc = revit.uidoc
TITRES = ("Variante 1 - Passer DESSUS", "Variante 2 - Passer DESSOUS", "Variante 3 - Proposition Allan BIM")


class ClashWindow(forms.WPFWindow):
    def __init__(self, xaml, clashes):
        self.maj = True
        forms.WPFWindow.__init__(self, xaml)
        self.rbs = (self.rb1, self.rb2, self.rb3)
        self.txs = (self.tx1, self.tx2, self.tx3)
        self.pc = None           # PreviewControl
        self.grp = None          # groupe de transactions de l'apercu en cours
        self.vues = {}
        self.cur = None
        self.refuses = set()
        self.resolus = 0
        self.garder = False
        self.zoom = 1.0
        self.box = None          # cube de la coupe 3D regle a la main (demi-dimensions, pieds)
        self.clashes = clashes
        self.univ = ac.univers(doc)
        self.maj = False
        self.Loaded += self._charge
        self.Closed += self._ferme

    # ---- outils
    def _attente(self, on):
        try:
            Mouse.OverrideCursor = Cursors.Wait if on else None
        except Exception:
            pass

    def _jeu(self):
        try:
            return max(0.0, float(self.txt_jeu.Text.replace(",", "."))) * ac.MM
        except Exception:
            return 50 * ac.MM

    def _drop(self):
        """Ferme l'apercu Revit (obligatoire avant de modifier le projet)."""
        try:
            self.host.Children.Clear()
            if self.pc is not None:
                self.pc.Dispose()
        except Exception:
            pass
        self.pc = None

    def _preview(self):
        self._drop()
        vid = self.vues.get("3d" if self.chk_3d.IsChecked else "coupe")
        if vid is None:
            return
        try:
            self.pc = PreviewControl(doc, vid)
            self.host.Children.Add(self.pc)
        except Exception as ex:
            self.info.Text = "Apercu impossible : %s" % ex

    def _annuler_apercu(self):
        if self.grp is not None:
            try:
                self.grp.RollBack()
            except Exception:
                pass
            self.grp = None

    def _choix(self):
        for i, rb in enumerate(self.rbs):
            if rb.IsChecked:
                return i
        if self.rb0.IsChecked:
            return "refus"
        if self.rbB.IsChecked:
            return "base"
        return None

    # ---- liste
    def _charge(self, s, a):
        self._liste()

    def _liste(self, garder_index=None):
        n = len(self.clashes)
        reste = len([c for c in self.clashes if c.etat == "A traiter"])
        self.titre.Text = "%d clash(s) - %d a traiter, %d resolu(s), %d refuse(s)" % (
            n, reste, self.resolus, n - reste)
        items = ["%d.  %s\n      %s" % (i + 1, c.titre(), c.etat) for i, c in enumerate(self.clashes)]
        idx = -1
        for i, c in enumerate(self.clashes):
            if c.etat == "A traiter":
                idx = i
                break
        if idx < 0 and n:
            idx = 0
        self.maj = True
        self.lst.ItemsSource = items
        self.lst.SelectedIndex = idx
        self.maj = False
        self.cur = self.clashes[idx] if idx >= 0 else None
        self._montrer()

    def on_select(self, s, a):
        if self.maj:
            return
        i = self.lst.SelectedIndex
        self.cur = self.clashes[i] if 0 <= i < len(self.clashes) else None
        self._montrer()

    def on_analyser(self, s, a):
        self.analyser()

    def analyser(self):
        self._attente(True)
        try:
            self._drop()
            self._annuler_apercu()
            self.clashes = ac.detecter(doc)
            for c in self.clashes:
                if c.key in self.refuses:
                    c.etat = "Refuse"
            self.univ = ac.univers(doc)
        finally:
            self._attente(False)
        self._liste()

    # ---- clash selectionne
    def _montrer(self, choix=None):
        self._attente(True)
        try:
            self._drop()
            self._annuler_apercu()
            c = self.cur
            self.maj = True
            for rb in self.rbs + (self.rb0, self.rbB):
                rb.IsChecked = False
                rb.IsEnabled = c is not None
            self.rbB.IsChecked = c is not None
            self.maj = False
            self.leg_a.Text = self.leg_b.Text = ""
            if c is None:
                self.vues = {}
                self.info.Text = "Aucun clash dans le projet."
                for tx in self.txs:
                    tx.Text = ""
                return
            self.leg_a.Text = "ROUGE = %s (id %s)" % (c.a.nom, ac.eid(c.a.id))
            self.leg_b.Text = "BLEU = %s (id %s)" % (c.b.nom, ac.eid(c.b.id))
            self.info.Text = "Les autres reseaux gardent leur couleur normale.   Volume commun : %.0f cm3   Vue x%.1f" % (
                (c.volume or 0) * 28316.8, self.zoom)
            t = ac.tx_debut(doc, "Allan BIM - vues clash")
            try:
                self.vues = ac.preparer_vues(doc, c, self.zoom, self.box)
                self._sliders(self.vues["box"])
                ac.valider_tx(t)
            except Exception as ex:
                t.RollBack()
                self.vues = {}
                self.info.Text = "Coupe impossible : %s" % ex
            if c.vars is None:
                c.vars = ac.variantes(doc, c, self._jeu(), self.univ)
            for i, v in enumerate(c.vars):
                self.txs[i].Text = "%s%s\n%s" % (TITRES[i], "   * RECOMMANDEE" if v.reco else "", v.texte())
                self.rbs[i].IsEnabled = v.ok
            self._preview()
        finally:
            self._attente(False)
        # on remet le choix qui etait coche (apres un changement de vue)
        if c is not None and choix in (0, 1, 2) and c.vars[choix].ok:
            self.rbs[choix].IsChecked = True
        elif c is not None and choix == "refus":
            self.rb0.IsChecked = True

    def _zoom(self, f):
        if self.cur is None:
            return
        self.zoom = min(8.0, max(0.5, self.zoom * f))
        if self.box is not None:
            self.box = tuple(v * f for v in self.box)
        self._montrer(self._choix())

    def on_plus(self, s, a):
        self._zoom(1.5)

    def on_moins(self, s, a):
        self._zoom(1 / 1.5)

    def on_3d(self, s, a):
        from System.Windows import Visibility
        self.pan_3d.Visibility = Visibility.Visible if self.chk_3d.IsChecked else Visibility.Collapsed
        self._preview()

    # ---- cube de la coupe 3D
    def _sliders(self, box):
        self.maj = True
        try:
            for sl, v in zip((self.sl_x, self.sl_y, self.sl_z), box):
                sl.Value = v * 0.3048
        finally:
            self.maj = False
        self.on_box_txt(None, None)

    def on_box_txt(self, s, a):
        try:
            self.lb_x.Text = "Longueur (le long du reseau) : %.1f m" % (2 * self.sl_x.Value)
            self.lb_y.Text = "Largeur (en travers) : %.1f m" % (2 * self.sl_y.Value)
            self.lb_z.Text = "Hauteur : %.1f m" % (2 * self.sl_z.Value)
        except Exception:
            pass

    def _boite(self):
        """Applique le cube regle a la main a la vue 3D (dans une transaction)."""
        if self.box is None or "3d" not in self.vues:
            return
        t = ac.tx_debut(doc, "Allan BIM - cube 3D")
        try:
            ac.boite3d(doc, self.vues["3d"], self.vues["tr3"], self.box)
            t.Commit()
        except Exception:
            t.RollBack()

    def on_box(self, s, a):
        if self.maj or self.cur is None:
            return
        self.box = tuple(sl.Value / 0.3048 for sl in (self.sl_x, self.sl_y, self.sl_z))
        self._attente(True)
        try:
            self._drop()
            self._boite()
            self._preview()
        finally:
            self._attente(False)

    def on_variante(self, s, a):
        if self.maj or self.cur is None:
            return
        self._attente(True)
        try:
            self._drop()
            self._annuler_apercu()
            k = self._choix()
            c = self.cur
            if k in (0, 1, 2) and c.vars[k].ok:
                self.grp = DB.TransactionGroup(doc, "Allan BIM - resoudre clash")
                self.grp.Start()
                try:
                    ids = ac.appliquer(doc, c, c.vars[k], self.univ)
                    # le reseau devie garde SA couleur (rouge ou bleu) sur tous ses morceaux
                    t = ac.tx_debut(doc, "Allan BIM - couleurs")
                    try:
                        ac.colorer(doc, [self.vues["coupe"], self.vues["3d"]], ids,
                                   ac.ROUGE if c.vars[k].mv is c.a else ac.BLEU)
                        t.Commit()
                    except Exception:
                        t.RollBack()   # couleurs ratees : la correction reste valable
                except Exception as ex:
                    self._annuler_apercu()
                    self.maj = True
                    self.rbs[k].IsChecked = False
                    self.maj = False
                    forms.alert("Cette solution ne peut pas etre appliquee :\n%s" % ex, title="Clashs")
            self._boite()
            self._preview()
        finally:
            self._attente(False)

    def on_valider(self, s, a):
        c, k = self.cur, self._choix()
        if c is None:
            return
        if k is None or k == "base":
            forms.alert("Coche une des 3 variantes, ou Refuser.", title="Clashs")
            return
        if k == "refus":
            self.refuses.add(c.key)
            c.etat = "Refuse"
            self._liste()
            return
        if self.grp is None:
            return
        self._drop()
        self.grp.Assimilate()
        self.grp = None
        self.resolus += 1
        self.analyser()          # on recontrole tout le projet apres la modification

    def on_garder(self, s, a):
        self.garder = True
        self.Close()

    def on_fermer(self, s, a):
        self.Close()

    def _ferme(self, s, a):
        self._drop()
        self._annuler_apercu()
        if not self.garder:
            t = ac.tx_debut(doc, "Allan BIM - nettoyage vues clash")
            try:
                ac.supprimer_vues(doc)
                t.Commit()
            except Exception:
                t.RollBack()
        self._attente(False)


if ac.nom(doc.ActiveView) in (ac.VUE_COUPE, ac.VUE_3D):
    forms.alert("Ferme d'abord la vue '%s' (elle sera recreee par l'outil)." % ac.nom(doc.ActiveView),
                title="Clashs", exitscript=True)

t0 = DB.Transaction(doc, "Raccords manquants")
t0.Start()
try:
    info_raccords = rel.ensure_fittings(doc)
    t0.Commit()
except Exception as ex:
    t0.RollBack()
    info_raccords = "Raccords par defaut non verifies :\n%s" % ex
if info_raccords:
    forms.alert(info_raccords, title="Clashs")

clashes = ac.detecter(doc)
if not clashes:
    forms.alert("Aucun clash detecte entre les gaines et les canalisations du projet.", title="Clashs")
    script.exit()

w = ClashWindow(os.path.join(os.path.dirname(__file__), "ui.xaml"), clashes)
w.ShowDialog()
if w.garder:
    vid = w.vues.get("3d" if w.chk_3d.IsChecked else "coupe")
    try:
        if vid is not None:
            uidoc.ActiveView = doc.GetElement(vid)
    except Exception:
        pass
forms.alert("%d clash(s) resolu(s), %d refuse(s), %d restant(s)." % (
    w.resolus, len(w.refuses), len([c for c in w.clashes if c.etat == "A traiter"])), title="Clashs")
