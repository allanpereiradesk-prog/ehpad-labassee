# -*- coding: utf-8 -*-
"""Pertes de charge (ENF117) : TD1 pertes lineaires (Colebrook) et TD2
pertes singulieres (coefficients k). Lit les valeurs dans la maquette,
compare au calcul, et exporte un Excel avec une feuille par fluide."""

__title__ = "Pertes\nde charge"

import os
import copy
from pyrevit import revit, DB, forms
import System
import clr
clr.AddReference("System.Data")
from System.Data import DataTable
from System.Windows.Media import SolidColorBrush, Color
from System.Windows.Input import Mouse, Cursors
from System.Windows.Controls import DataGridRow
import allan_pdc as pdc

doc = revit.doc
uidoc = revit.uidoc
ICI = os.path.dirname(__file__)

VERT = SolidColorBrush(Color.FromRgb(0x1F, 0x3B, 0x2A))
ORANGE = SolidColorBrush(Color.FromRgb(0x4A, 0x3A, 0x16))
ROUGE = SolidColorBrush(Color.FromRgb(0x4D, 0x22, 0x20))


def num(t):
    t = (t or u"").strip().replace(u" ", u"").replace(u",", u".")
    return float(t)


def fmt(v, n):
    if v is None or v == u"":
        return u""
    try:
        return (u"%." + str(n) + u"f") % v
    except Exception:
        return u"%s" % v


def pc(e):
    return u"" if e is None else u"%+.3f %%" % (e * 100)


def etat_ecart(*es):
    es = [abs(e) for e in es if e is not None]
    if not es:
        return u""
    m = max(es)
    return u"✓" if m <= 0.001 else (u"≈" if m <= 0.01 else u"✗")


def etat_td2(ek, ee, es):
    if ek is not None:
        return etat_ecart(ek)
    dp = [e for e in (ee, es) if e is not None]
    return etat_ecart(min(dp, key=abs)) if dp else u""


# ======================================================================= dialogue "Ajouter un fluide"
class NouveauFluide(forms.WPFWindow):
    def __init__(self, fluides_revit, cas, types_sys, type_defaut):
        self.pret = False
        forms.WPFWindow.__init__(self, os.path.join(ICI, "nouveau_fluide.xaml"))
        self.fluides_revit = fluides_revit
        self.cas = cas
        self.types_sys = types_sys
        self.sources = [u"Eau TD 1 (Thermexcel, interpolée)"] + [u"Fluide Revit : " + n for n, _ in fluides_revit] + [u"Saisie manuelle"]
        self.cb_src.ItemsSource = self.sources
        self.cb_modele.ItemsSource = [c["nom"] for c in cas] + [u"(aucun : je lirai les canalisations ensuite)"]
        self.cb_modele.SelectedIndex = 0
        self.cb_typesys.ItemsSource = [n for n, _ in types_sys]
        self.cb_typesys.SelectedIndex = type_defaut if type_defaut >= 0 else 0
        self.t_nom.Text = u"Eau TD 1 - 54 °C"
        self.t_fluide.Text = u"Eau TD 1"
        self.t_theta.Text = u"54"
        self.resultat = None
        self.pret = True
        self.cb_src.SelectedIndex = 0

    def on_maj(self, s, a):
        if not self.pret:
            return
        i = self.cb_src.SelectedIndex
        try:
            th = num(self.t_theta.Text)
        except Exception:
            return
        manuel = i == len(self.sources) - 1
        self.t_rho.IsReadOnly = not manuel
        self.t_mu.IsReadOnly = not manuel
        self.o_creer.IsEnabled = True
        if i == 0:
            rho, mu = pdc.thermexcel(th)
            if s is self.cb_src:
                self.t_fluide.Text = u"Eau TD 1"
            self.t_info.Text = u"Interpolé entre 40, 54 et 70 °C (tableau Thermexcel du TD)."
        elif not manuel:
            n, f = self.fluides_revit[i - 1]
            rho, mu = pdc.proprietes_fluide(f, th)
            if s is self.cb_src:
                self.t_fluide.Text = n
            self.o_creer.IsChecked = False
            self.t_info.Text = u"Valeurs de la table du fluide « %s » dans Revit." % n
        else:
            self.t_info.Text = u"Saisis ρ et µ à la main (par exemple pour un autre fluide)."
            return
        if rho is not None:
            self.t_rho.Text = u"%.4f" % rho
            self.t_mu.Text = u"%.9f" % mu

    def on_annuler(self, s, a):
        self.Close()

    def on_ok(self, s, a):
        try:
            th, rho, mu = num(self.t_theta.Text), num(self.t_rho.Text), num(self.t_mu.Text)
        except Exception:
            self.t_info.Text = u"θ, ρ et µ doivent être des nombres."
            return
        nom = (self.t_nom.Text or u"").strip()
        if not nom:
            self.t_info.Text = u"Donne un nom au cas."
            return
        i = self.cb_src.SelectedIndex
        src = u"Thermexcel" if i == 0 else (u"Saisie manuelle" if i == len(self.sources) - 1 else u"Revit")
        mi = self.cb_modele.SelectedIndex
        self.resultat = {
            "nom": nom, "fluide": (self.t_fluide.Text or u"").strip() or nom, "theta": th, "rho": rho, "mu": mu,
            "source": src, "modele": self.cas[mi] if 0 <= mi < len(self.cas) else None,
            "creer": bool(self.o_creer.IsChecked) and self.o_creer.IsEnabled,
            "affecter": bool(self.o_affecter.IsChecked),
            "typesys": self.types_sys[self.cb_typesys.SelectedIndex][1] if self.cb_typesys.SelectedIndex >= 0 else None,
        }
        self.Close()


# ======================================================================= fenetre principale
class Fenetre(forms.WPFWindow):
    def __init__(self, xaml):
        self.pret = False
        forms.WPFWindow.__init__(self, xaml)
        self.chemin_json = pdc.chemin_sauvegarde(doc)
        self.etat = pdc.charger_etat(self.chemin_json)
        self.etat.setdefault("cas", [])
        self.etat.setdefault("td2", [])
        self.kf, msg = pdc.charger_kfactors(pdc.chemin_kfactors(doc.Application))
        self.log(msg)
        self.systemes = pdc.systemes(doc)
        self.types = pdc.types_systeme(doc)
        noms_sys = [n for n, _ in self.systemes] or [u"(aucun système)"]
        self.cb_sys.ItemsSource = noms_sys
        self.cb_sys2.ItemsSource = noms_sys
        self.cb_sys.SelectedIndex = 0
        self.cb_sys2.SelectedIndex = 0
        self.cb_typesys.ItemsSource = [n for n, _ in self.types]
        self.cb_typesys.SelectedIndex = self._type_par_defaut()
        if uidoc.Selection.GetElementIds().Count:
            self.p_sel.IsChecked = True
            self.p2_sel.IsChecked = True
        self.courant = None
        self.dessiner_coudes()
        self.pret = True
        if not self.etat["cas"]:
            self._premier_cas()
        self.rafraichir_liste(0)
        self.rafraichir_rho()
        self.dessiner_td2()
        self.Closing += self.on_fermer

    # ------------------------------------------------------------ outils
    def log(self, lignes):
        if isinstance(lignes, basestring):
            lignes = [lignes]
        self.journal.Text = (u"\n".join(l for l in lignes if l) + u"\n" + self.journal.Text).strip()

    def sauver(self):
        try:
            pdc.sauver_etat(self.chemin_json, self.etat)
        except Exception as ex:
            self.log(u"Sauvegarde impossible : %s" % ex)

    def _type_par_defaut(self):
        for i, (n, _) in enumerate(self.types):
            if u"retour" in n.lower() and u"chauff" in n.lower():
                return i
        for i, (n, _) in enumerate(self.types):
            if u"chauff" in n.lower():
                return i
        return 0

    def _portee(self, sel, sys_):
        return "selection" if sel.IsChecked else ("systeme" if sys_.IsChecked else "projet")

    def _systeme(self, cb):
        i = cb.SelectedIndex
        return self.systemes[i][1] if 0 <= i < len(self.systemes) else None

    def _pipes(self):
        return pdc.elements(doc, DB.BuiltInCategory.OST_PipeCurves, self._portee(self.p_sel, self.p_sys), uidoc, self._systeme(self.cb_sys))

    def _fits(self):
        return pdc.elements(doc, DB.BuiltInCategory.OST_PipeFitting, self._portee(self.p2_sel, self.p2_sys), uidoc, self._systeme(self.cb_sys2))

    def _premier_cas(self):
        """Premiere ouverture : un cas 'Eau Revit' lu directement dans la maquette."""
        c = pdc.nouveau_cas(u"Eau Revit", source=u"Revit")
        self.etat["cas"].append(c)
        self.courant = c
        log = []
        pipes = self._pipes() or pdc.elements(doc, DB.BuiltInCategory.OST_PipeCurves, "projet")
        if pipes:
            self._remplir_depuis_revit(c, pipes, True, log)
        log.append(u"Premier cas créé à partir de la maquette. Ajoute les autres fluides avec « + Ajouter un fluide ».")
        self.log(log)

    # ------------------------------------------------------------ TD1 : liste / champs
    def rafraichir_liste(self, sel=None):
        self.pret = False
        self.lst_cas.ItemsSource = [u"%s\n   %s · %s °C · %d DN" % (c["nom"], c.get("fluide") or u"?", fmt(c["theta"], 1), len(c["lignes"]))
                                    for c in self.etat["cas"]]
        self.pret = True
        if sel is None:
            sel = self.etat["cas"].index(self.courant) if self.courant in self.etat["cas"] else 0
        if self.etat["cas"]:
            self.lst_cas.SelectedIndex = min(sel, len(self.etat["cas"]) - 1)
        else:
            self.courant = None
            self.dessiner_td1()

    def on_sel_cas(self, s, a):
        if not self.pret:
            return
        i = self.lst_cas.SelectedIndex
        if i < 0 or i >= len(self.etat["cas"]):
            return
        c = self.etat["cas"][i]
        self.courant = c
        self.t_nom.Text = c["nom"]
        self.t_fluide.Text = c.get("fluide") or u""
        self.t_theta.Text = fmt(c["theta"], 4)
        self.t_rho.Text = fmt(c["rho"], 4)
        self.t_mu.Text = fmt(c["mu"], 9)
        self.t_eps.Text = fmt(c["eps"], 5)
        self.t_qv.Text = fmt(c["qv"], 3)
        self.t_seg.Text = c.get("segment") or u""
        self.cb_kc.SelectedIndex = 1 if abs(c.get("kc", 3.7) - 3.71) < 1e-6 else 0
        self.t_source.Text = c.get("source") or u""
        self.dessiner_td1()

    def lire_champs(self):
        c = self.courant
        if c is None:
            return False
        try:
            c["theta"] = num(self.t_theta.Text)
            c["rho"] = num(self.t_rho.Text)
            c["mu"] = num(self.t_mu.Text)
            c["eps"] = num(self.t_eps.Text)
            c["qv"] = num(self.t_qv.Text)
        except Exception:
            self.log(u"Valeur non numérique dans les paramètres du cas.")
            return False
        c["nom"] = (self.t_nom.Text or u"").strip() or c["nom"]
        c["fluide"] = (self.t_fluide.Text or u"").strip()
        c["segment"] = (self.t_seg.Text or u"").strip()
        c["kc"] = 3.71 if self.cb_kc.SelectedIndex == 1 else 3.7
        return True

    def on_appliquer(self, s, a):
        if self.lire_champs():
            self.rafraichir_liste()
            self.sauver()
            self.rafraichir_rho()

    # ------------------------------------------------------------ TD1 : tableau
    def dessiner_td1(self):
        dt = DataTable()
        cols = [u"DN", u"Dint (mm)", u"v (m/s)", u"Re calculé", u"Re Revit", u"λ calculé", u"λ Revit", u"Écart λ",
                u"j calculé (Pa/m)", u"j Revit (Pa/m)", u"Écart j", u"État"]
        for h in cols:
            dt.Columns.Add(h, System.String)
        c = self.courant
        if c is None:
            self.dg_td1.ItemsSource = dt.DefaultView
            self.t_concl.Text = u"Ajoute un fluide pour commencer."
            return
        for l in c["lignes"]:
            rv = l.get("revit") or {}
            r = pdc.calc(rv.get("qv") or c["qv"], c["rho"], c["mu"], c["eps"], c.get("kc", 3.7), l["dint"]) or {}
            el = pdc.ecart(r.get("lam"), rv.get("lam"))
            ej = pdc.ecart(r.get("j"), rv.get("j"))
            ere = pdc.ecart(r.get("re"), rv.get("re"))
            row = dt.NewRow()
            vals = [u"%d" % l["dn"], fmt(l["dint"], 1), fmt(r.get("v"), 3), fmt(r.get("re"), 0), fmt(rv.get("re"), 0),
                    fmt(r.get("lam"), 6), fmt(rv.get("lam"), 6), pc(el), fmt(r.get("j"), 2), fmt(rv.get("j"), 2), pc(ej),
                    etat_ecart(el, ere)]
            for k, v in enumerate(vals):
                row[k] = v
            dt.Rows.Add(row)
        self.dg_td1.ItemsSource = dt.DefaultView
        self.t_concl.Text = u"\n".join(pdc.conclusion_cas(c))

    def on_ligne(self, s, e):
        try:
            v = e.Row.Item[u"État"]
        except Exception:
            return
        b = {u"✓": VERT, u"≈": ORANGE, u"✗": ROUGE}.get(v)
        if b is not None:
            e.Row.Background = b
        else:
            e.Row.ClearValue(DataGridRow.BackgroundProperty)

    # ------------------------------------------------------------ TD1 : actions
    def _remplir_depuis_revit(self, c, pipes, avec_fluide, log):
        lignes, infos = pdc.lire_canalisations(doc, pipes, log)
        if not lignes:
            log.append(u"Aucune canalisation trouvée dans la portée choisie.")
            return
        c["lignes"] = lignes
        if infos["eps"] is not None:
            c["eps"] = infos["eps"]
        if infos["segment"]:
            c["segment"] = infos["segment"]
        if infos["qv"]:
            c["qv"] = infos["qv"]
        if avec_fluide and infos["type_systeme"] is not None:
            st = doc.GetElement(infos["type_systeme"])
            fl = pdc.fluide_du_type_systeme(doc, st) if st is not None else None
            if fl and fl["rho"]:
                c.update({"fluide": fl["fluide"], "theta": fl["theta"], "rho": fl["rho"], "mu": fl["mu"],
                          "source": u"Revit · système « %s »" % fl["systeme"]})
                log.append(u"Fluide du système : %s à %.2f °C → ρ = %.4f kg/m³ ; µ = %.9f Pa.s" % (
                    fl["fluide"], fl["theta"], fl["rho"], fl["mu"]))
        log.append(u"%d diamètre(s) lus (%d canalisation(s)) · ε = %s mm · Qv = %s L/s · %s" % (
            len(lignes), len(pipes), fmt(c["eps"], 5), fmt(c["qv"], 3), c.get("segment") or u""))

    def on_lire_canal(self, s, a):
        if self.courant is None:
            self.log(u"Ajoute d'abord un fluide.")
            return
        self.lire_champs()
        pipes = self._pipes()
        if not pipes:
            self.log(u"Aucune canalisation : sélectionne des canalisations avant d'ouvrir l'outil, ou choisis un système.")
            return
        log = []
        Mouse.OverrideCursor = Cursors.Wait
        try:
            self._remplir_depuis_revit(self.courant, pipes, bool(self.o_fluide.IsChecked), log)
        except Exception as ex:
            log.append(u"Erreur : %s" % ex)
        finally:
            Mouse.OverrideCursor = None
        self.log(log)
        self.sauver()
        self.rafraichir_liste()
        self.on_sel_cas(None, None)

    def _points_fluide(self, c):
        if u"thermexcel" in (c.get("source") or u"").lower():
            pts = list(pdc.THERMEXCEL)
            if all(abs(p[0] - c["theta"]) > 0.01 for p in pts):
                pts.append((c["theta"], c["rho"], c["mu"]))
            return sorted(pts)
        return [(c["theta"], c["rho"], c["mu"])]

    def on_creer_fluide(self, s, a):
        if not self.lire_champs():
            return
        c = self.courant
        if not c.get("fluide"):
            self.log(u"Donne un nom au fluide.")
            return
        log = []
        try:
            with revit.Transaction(u"Allan BIM - Créer le fluide %s" % c["fluide"], doc):
                pdc.creer_fluide(doc, c["fluide"], self._points_fluide(c), log)
        except Exception as ex:
            log.append(u"Création du fluide impossible : %s" % ex)
        self.log(log)

    def on_affecter(self, s, a):
        if not self.lire_champs():
            return
        c = self.courant
        i = self.cb_typesys.SelectedIndex
        if i < 0:
            return
        fl = [f for n, f in pdc.fluides(doc) if n == c.get("fluide")]
        log = []
        if not fl:
            log.append(u"Le fluide « %s » n'existe pas dans Revit : clique d'abord sur « Créer / mettre à jour ce fluide »." % c.get("fluide"))
        else:
            try:
                with revit.Transaction(u"Allan BIM - Affecter le fluide", doc):
                    pdc.affecter_fluide(doc, self.types[i][1], fl[0], c["theta"], log)
                log.append(u"Revit a recalculé le réseau : clique sur « Lire les canalisations » pour récupérer les nouvelles valeurs.")
            except Exception as ex:
                log.append(u"Affectation impossible : %s" % ex)
        self.log(log)

    def on_ajouter(self, s, a):
        self.lire_champs()
        d = NouveauFluide(pdc.fluides(doc), self.etat["cas"], self.types, self.cb_typesys.SelectedIndex)
        d.Owner = self
        d.ShowDialog()
        r = d.resultat
        if not r:
            return
        c = pdc.nouveau_cas(r["nom"], r["fluide"], r["theta"], r["rho"], r["mu"], source=r["source"])
        m = r["modele"]
        if m is not None:
            c["eps"], c["qv"], c["kc"], c["segment"] = m["eps"], m["qv"], m.get("kc", 3.7), m.get("segment", u"")
            c["lignes"] = [{"dn": l["dn"], "dint": l["dint"], "dext": l.get("dext"), "revit": {}} for l in m["lignes"]]
        self.etat["cas"].append(c)
        self.courant = c
        log = [u"Cas « %s » ajouté." % c["nom"]]
        if r["creer"] or r["affecter"]:
            try:
                with revit.Transaction(u"Allan BIM - Fluide %s" % c["fluide"], doc):
                    fl = None
                    if r["creer"]:
                        fl = pdc.creer_fluide(doc, c["fluide"], self._points_fluide(c), log)
                    else:
                        found = [f for n, f in pdc.fluides(doc) if n == c["fluide"]]
                        fl = found[0] if found else None
                    if r["affecter"] and fl is not None and r["typesys"] is not None:
                        pdc.affecter_fluide(doc, r["typesys"], fl, c["theta"], log)
                if r["affecter"]:
                    log.append(u"Clique maintenant sur « Lire les canalisations » (sans reprendre le fluide) pour avoir les valeurs Revit de ce cas.")
                    self.o_fluide.IsChecked = False
            except Exception as ex:
                log.append(u"Revit : %s" % ex)
        self.log(log)
        self.sauver()
        self.rafraichir_liste(len(self.etat["cas"]) - 1)
        self.rafraichir_rho()

    def on_dupliquer(self, s, a):
        if self.courant is None:
            return
        self.lire_champs()
        c = copy.deepcopy(self.courant)
        c["nom"] = c["nom"] + u" (copie)"
        self.etat["cas"].append(c)
        self.courant = c
        self.sauver()
        self.rafraichir_liste(len(self.etat["cas"]) - 1)
        self.rafraichir_rho()

    def on_supprimer(self, s, a):
        if self.courant is None:
            return
        if not forms.alert(u"Supprimer le cas « %s » ?" % self.courant["nom"], yes=True, no=True):
            return
        i = self.etat["cas"].index(self.courant)
        self.etat["cas"].remove(self.courant)
        self.courant = None
        self.sauver()
        self.rafraichir_liste(max(0, i - 1))
        self.rafraichir_rho()

    # ------------------------------------------------------------ TD2
    def rafraichir_rho(self):
        self.pret = False
        self.cb_rho.ItemsSource = [u"%s (ρ = %.2f)" % (c["nom"], c["rho"]) for c in self.etat["cas"]] or [u"ρ = 985.94 (eau Revit)"]
        idx = 0
        rho = self.etat.get("td2_rho")
        for i, c in enumerate(self.etat["cas"]):
            if rho is not None and abs(c["rho"] - rho) < 1e-6:
                idx = i
                break
        self.cb_rho.SelectedIndex = idx
        self.pret = True
        if self.etat["cas"] and rho is None:
            self.etat["td2_rho"] = self.etat["cas"][0]["rho"]

    def on_rho(self, s, a):
        if not self.pret:
            return
        i = self.cb_rho.SelectedIndex
        if 0 <= i < len(self.etat["cas"]):
            self.etat["td2_rho"] = self.etat["cas"][i]["rho"]
            self.dessiner_td2()

    def dessiner_coudes(self):
        dt = DataTable()
        for h in [u"DN", u"Pouces", u"k interpolé"]:
            dt.Columns.Add(h, System.String)
        for dn in pdc.DN_COUDES:
            r = dt.NewRow()
            r[0] = u"%d" % dn
            r[1] = fmt(dn * pdc.POUCE, 6)
            r[2] = fmt(pdc.k_coude(dn, self.kf), 8)
            dt.Rows.Add(r)
        self.dg_coudes.ItemsSource = dt.DefaultView

    def dessiner_td2(self):
        dt = DataTable()
        cols = [u"ID", u"Pièce", u"Taille", u"Tableau K", u"DN e", u"DN s", u"Ve (m/s)", u"Vs (m/s)", u"ΔP Revit (Pa)",
                u"K Revit", u"k calculé", u"Écart k", u"ΔP calc. Ve", u"ΔP calc. Vs", u"Écart ΔP Ve", u"Écart ΔP Vs", u"État"]
        for h in cols:
            dt.Columns.Add(h, System.String)
        rho = self.etat.get("td2_rho") or 985.9364
        concl = []
        n_ve = n_vs = 0
        for r0 in self.etat.get("td2") or []:
            k = pdc.k_calcule(r0, self.kf)
            dpe = k * r0["ve"] ** 2 / 2 * rho if k is not None and r0.get("ve") else None
            dps = k * r0["vs"] ** 2 / 2 * rho if k is not None and r0.get("vs") else None
            ek = pdc.ecart(k, r0.get("k_revit"))
            ee = pdc.ecart(dpe, r0.get("dp"))
            es = pdc.ecart(dps, r0.get("dp"))
            if r0["piece"] == u"Réduction" and ee is not None and es is not None:
                if abs(es) < abs(ee):
                    n_vs += 1
                else:
                    n_ve += 1
            row = dt.NewRow()
            vals = [u"%d" % r0["id"], r0["piece"], r0["taille"], r0["table"], u"%s" % (r0["dn1"] or u""), u"%s" % (r0["dn2"] or u""),
                    fmt(r0.get("ve"), 3), fmt(r0.get("vs"), 3), fmt(r0.get("dp"), 3), fmt(r0.get("k_revit"), 6), fmt(k, 5), pc(ek),
                    fmt(dpe, 3), fmt(dps, 3), pc(ee), pc(es), etat_td2(ek, ee, es)]
            for i, v in enumerate(vals):
                row[i] = v
            dt.Rows.Add(row)
        self.dg_td2.ItemsSource = dt.DefaultView
        td2 = self.etat.get("td2") or []
        if not td2:
            self.t_concl2.Text = u"1. Paramètre les raccords, 2. lis-les, 3. importe le rapport HTML pour avoir le K de Revit."
            return
        coudes = [r for r in td2 if r["piece"] == u"Coude"]
        reds = [r for r in td2 if r["piece"] == u"Réduction"]
        concl.append(u"%d coude(s), %d réduction(s) lus. ρ utilisé : %.4f kg/m³." % (len(coudes), len(reds), rho))
        mal = [r for r in td2 if r["piece"] in (u"Coude", u"Réduction") and r["table"] not in (pdc.TABLE_COUDE, pdc.TABLE_REDUC)]
        if mal:
            concl.append(u"⚠ %d raccord(s) n'utilisent pas la bonne table : clique sur « 1. Paramétrer les raccords »." % len(mal))
        ek_c = [abs(pdc.ecart(pdc.k_calcule(r, self.kf), r.get("k_revit"))) for r in coudes if r.get("k_revit")]
        if ek_c:
            concl.append(u"Coudes : écart max sur k = %.3f %% → Revit interpole bien la table Long Radius Elbow sur le DN en pouces." % (max(ek_c) * 100)
                         if max(ek_c) < 0.01 else u"Coudes : écart max sur k = %.2f %%." % (max(ek_c) * 100))
        if n_vs or n_ve:
            concl.append(u"Réductions : le ΔP de Revit correspond mieux au calcul avec la vitesse %s (%d cas sur %d)." % (
                u"de sortie Vs" if n_vs >= n_ve else u"d'entrée Ve", max(n_vs, n_ve), n_vs + n_ve))
        for r in reds:
            if r.get("k_revit"):
                ratio = pdc.ratio_depuis_k(r["k_revit"], self.kf)
                if ratio:
                    concl.append(u"ID %d (%s) : K Revit %.4f ↔ D1/D2 = %.3f dans la table, contre %.3f avec les DN nominaux." % (
                        r["id"], r["taille"], r["k_revit"], ratio, max(r["dn1"], r["dn2"]) / float(min(r["dn1"], r["dn2"]))))
        self.t_concl2.Text = u"\n".join(concl)

    def on_param_raccords(self, s, a):
        fits = self._fits()
        if not fits:
            self.log(u"Aucun raccord dans la portée choisie.")
            return
        log = []
        try:
            with revit.Transaction(u"Allan BIM - Paramétrer les raccords (TD2)", doc):
                n = pdc.parametrer_raccords(doc, fits, log)
            log.append(u"%d type(s) de raccord paramétré(s). Clique sur « 2. Lire les raccords »." % n)
        except Exception as ex:
            log.append(u"Erreur : %s" % ex)
        self.log(log)

    def on_lire_raccords(self, s, a):
        fits = self._fits()
        if not fits:
            self.log(u"Aucun raccord dans la portée choisie.")
            return
        log = []
        Mouse.OverrideCursor = Cursors.Wait
        try:
            anciens = dict((r["id"], r.get("k_revit")) for r in self.etat.get("td2") or [])
            rows = pdc.lire_raccords(doc, fits, self.kf, log)
            for r in rows:
                r["k_revit"] = anciens.get(r["id"])
            self.etat["td2"] = rows
            log.append(u"%d raccord(s) lus." % len(rows))
        except Exception as ex:
            log.append(u"Erreur : %s" % ex)
        finally:
            Mouse.OverrideCursor = None
        self.log(log)
        self.sauver()
        self.dessiner_td2()

    def on_rapport(self, s, a):
        f = forms.pick_file(files_filter=u"Rapport Revit (*.html;*.htm)|*.html;*.htm",
                            init_dir=os.path.dirname(self.chemin_json))
        if not f:
            return
        try:
            data = pdc.lire_rapport_html(f)
        except Exception as ex:
            self.log(u"Lecture du rapport impossible : %s" % ex)
            return
        n = 0
        for r in self.etat.get("td2") or []:
            d = data.get(r["id"])
            if d:
                r["k_revit"] = d.get("k")
                if r.get("dp") in (None, 0) and d.get("dp") is not None:
                    r["dp"] = d["dp"]
                n += 1
        self.log(u"Rapport : %d raccord(s) trouvés dans le fichier, %d reliés par leur ID." % (len(data), n))
        self.sauver()
        self.dessiner_td2()

    def on_kfactors(self, s, a):
        f = forms.pick_file(file_ext="xml", init_dir=os.path.dirname(pdc.chemin_kfactors(doc.Application) or u"C:\\"))
        if not f:
            return
        self.kf, msg = pdc.charger_kfactors(f)
        self.log(msg)
        self.dessiner_coudes()
        self.dessiner_td2()

    # ------------------------------------------------------------ export / fermeture
    def on_enregistrer(self, s, a):
        self.lire_champs()
        self.sauver()
        self.rafraichir_liste()
        self.log(u"Enregistré : %s" % self.chemin_json)

    def on_exporter(self, s, a):
        self.lire_champs()
        self.sauver()
        projet = os.path.splitext(os.path.basename(doc.PathName or doc.Title))[0]
        defaut = u"%s - pertes de charge.xlsx" % projet
        f = forms.save_file(file_ext="xlsx", default_name=defaut, init_dir=os.path.dirname(self.chemin_json))
        if not f:
            return
        if not f.lower().endswith(u".xlsx"):
            f += u".xlsx"
        log = []
        Mouse.OverrideCursor = Cursors.Wait
        try:
            pdc.exporter(f, self.etat, self.kf, projet, log)
        except IOError as ex:
            log.append(u"Impossible d'écrire le fichier (déjà ouvert dans Excel ?) : %s" % ex)
            f = None
        except Exception as ex:
            log.append(u"Erreur : %s" % ex)
            f = None
        finally:
            Mouse.OverrideCursor = None
        self.log(log)
        if f:
            try:
                import System.Diagnostics as D
                p = D.ProcessStartInfo(f)
                p.UseShellExecute = True
                D.Process.Start(p)
            except Exception as ex:
                self.log(u"Fichier créé mais pas ouvert : %s" % ex)

    def on_fermer(self, s, a):
        self.lire_champs()
        self.sauver()


Fenetre(os.path.join(ICI, "ui.xaml")).show_dialog()
