# -*- coding: utf-8 -*-
"""Mini calculatrice flottante.
Clic sur l'icone : ouvre la calculatrice. Re-clic : la reduit / l'agrandit.
Elle reste au-dessus de Revit sans bloquer le travail.
Saisie au clavier : 2,5*(3+4)  racine(16)  2^3  15%  pi  ans
Entree = calculer, Echap = effacer, fleche haut = reprendre le dernier calcul."""

__title__ = "Calculatrice"
__persistentengine__ = True

import os
import math
import clr
clr.AddReference("PresentationFramework")
clr.AddReference("PresentationCore")
clr.AddReference("WindowsBase")
from pyrevit import forms
from System import AppDomain
from System.Windows import Visibility, Clipboard, WindowState
from System.Windows.Input import Key

CLE = "AllanBIM.Calculatrice"


# ------------------------------------------------------------------ evaluateur
class Erreur(Exception):
    pass


FONCTIONS = {
    "racine": math.sqrt, "sqrt": math.sqrt,
    "sin": lambda d: math.sin(math.radians(d)),
    "cos": lambda d: math.cos(math.radians(d)),
    "tan": lambda d: math.tan(math.radians(d)),
    "asin": lambda v: math.degrees(math.asin(v)),
    "acos": lambda v: math.degrees(math.acos(v)),
    "atan": lambda v: math.degrees(math.atan(v)),
    "ln": math.log, "log": math.log10, "abs": abs,
    "arrondi": lambda v: float(round(v)), "round": lambda v: float(round(v)),
}


def jetons(txt):
    t = txt.replace(u",", u".").replace(u"×", u"*").replace(u"÷", u"/").replace(u"−", u"-").replace(u"√", u"racine")
    t = t.replace(u"π", u"pi").replace(u"²", u"^2").replace(u"³", u"^3")
    out, i = [], 0
    while i < len(t):
        c = t[i]
        if c.isspace():
            i += 1
        elif c.isdigit() or c == ".":
            j = i
            while j < len(t) and (t[j].isdigit() or t[j] == "."):
                j += 1
            if j < len(t) and t[j] in "eE" and j + 1 < len(t) and (t[j + 1].isdigit() or t[j + 1] in "+-"):
                j += 2
                while j < len(t) and t[j].isdigit():
                    j += 1
            try:
                out.append(("n", float(t[i:j])))
            except ValueError:
                raise Erreur(u"nombre invalide : " + t[i:j])
            i = j
        elif c.isalpha():
            j = i
            while j < len(t) and t[j].isalpha():
                j += 1
            out.append(("id", t[i:j].lower()))
            i = j
        elif c in "+-*/^()%":
            out.append(("op", c))
            i += 1
        else:
            raise Erreur(u"caractère non reconnu : " + c)
    return out


class Calcul(object):
    """Analyse descendante : expr = terme {(+|-) terme}, terme = puiss {(*|/) puiss},
    puiss = unaire [^ puiss], unaire = [-|+] unaire | primaire [%]"""

    def __init__(self, txt, ans):
        self.j = jetons(txt)
        self.k = 0
        self.ans = ans

    def voir(self):
        return self.j[self.k] if self.k < len(self.j) else (None, None)

    def prendre(self):
        x = self.voir()
        self.k += 1
        return x

    def evaluer(self):
        if not self.j:
            raise Erreur(u"rien à calculer")
        v = self.expr()
        if self.k < len(self.j):
            raise Erreur(u"expression incomplète")
        return v

    def expr(self):
        v = self.terme()
        while self.voir() in (("op", "+"), ("op", "-")):
            op = self.prendre()[1]
            w = self.terme()
            v = v + w if op == "+" else v - w
        return v

    def terme(self):
        v = self.unaire()
        while True:
            t = self.voir()
            if t in (("op", "*"), ("op", "/")):
                op = self.prendre()[1]
                w = self.unaire()
                if op == "*":
                    v *= w
                else:
                    if w == 0:
                        raise Erreur(u"division par zéro")
                    v /= w
            elif t[0] in ("n", "id") or t == ("op", "("):
                v *= self.puiss()      # multiplication implicite : 2pi, 3(4+1)
            else:
                return v

    def unaire(self):
        t = self.voir()
        if t == ("op", "-"):
            self.prendre()
            return -self.unaire()
        if t == ("op", "+"):
            self.prendre()
            return self.unaire()
        return self.puiss()

    def puiss(self):
        v = self.primaire()
        while self.voir() == ("op", "%"):
            self.prendre()
            v = v / 100.0
        if self.voir() == ("op", "^"):
            self.prendre()
            try:
                v = v ** self.unaire()
            except (ValueError, OverflowError, ZeroDivisionError):
                raise Erreur(u"puissance impossible")
            if isinstance(v, complex):
                raise Erreur(u"puissance impossible")
        return v

    def primaire(self):
        t = self.prendre()
        if t[0] == "n":
            return t[1]
        if t == ("op", "("):
            v = self.expr()
            if self.prendre() != ("op", ")"):
                raise Erreur(u"parenthèse fermante manquante")
            return v
        if t[0] == "id":
            nom = t[1]
            if nom == "pi":
                return math.pi
            if nom == "ans":
                return self.ans
            if nom in FONCTIONS:
                if self.voir() == ("op", "("):
                    self.prendre()
                    a = self.expr()
                    if self.prendre() != ("op", ")"):
                        raise Erreur(u"parenthèse fermante manquante")
                else:
                    a = self.unaire()
                try:
                    return float(FONCTIONS[nom](a))
                except (ValueError, OverflowError):
                    raise Erreur(u"%s impossible pour cette valeur" % nom)
            raise Erreur(u"inconnu : " + nom)
        raise Erreur(u"expression incomplète")


def formater(v):
    if v != v or v in (float("inf"), float("-inf")):
        return u"erreur"
    if abs(v - round(v)) < 1e-9 and abs(v) < 1e15:
        return u"{:,}".format(int(round(v))).replace(u",", u" ")
    s = (u"%.10g" % v)
    if "e" in s:
        return s.replace(u".", u",")
    ent, dec = s.split(u".") if u"." in s else (s, u"")
    ent = u"{:,}".format(int(ent)).replace(u",", u" ") if ent not in (u"-0", u"-") else ent
    return ent + (u"," + dec if dec else u"")


# ------------------------------------------------------------------ fenetre
class Calculatrice(forms.WPFWindow):
    def __init__(self, xaml):
        forms.WPFWindow.__init__(self, xaml)
        self.ans = 0.0
        self.histo = []
        self.reduite = False
        self.haut_pleine = self.Height
        self.saisie.KeyDown += self.on_touche
        self.Closed += self.on_ferme
        self.saisie.Focus()

    # --- calcul
    def calculer(self):
        txt = self.saisie.Text.strip()
        if not txt:
            return
        try:
            v = Calcul(txt, self.ans).evaluer()
            self.ans = v
            r = formater(v)
            self.resultat.Text = u"= " + r
            self.resultat.Foreground = self.Resources["Ok"]
            self.histo.insert(0, (txt, r))
            del self.histo[40:]
            self.lst.ItemsSource = [u"%s  =  %s" % h for h in self.histo]
        except Erreur as ex:
            self.resultat.Text = unicode(ex)
            self.resultat.Foreground = self.Resources["Ko"]
        except Exception as ex:
            self.resultat.Text = u"erreur : %s" % ex
            self.resultat.Foreground = self.Resources["Ko"]

    def on_touche(self, s, a):
        if a.Key in (Key.Enter, Key.Return):
            self.calculer()
            a.Handled = True
        elif a.Key == Key.Escape:
            self.saisie.Text = u""
            self.resultat.Text = u""
            a.Handled = True
        elif a.Key == Key.Up and self.histo:
            self.saisie.Text = self.histo[0][0]
            self.saisie.CaretIndex = len(self.saisie.Text)
            a.Handled = True

    def on_bouton(self, s, a):
        t = s.Tag if s.Tag is not None else s.Content
        t = unicode(t)
        if t == u"=":
            self.calculer()
        elif t == u"C":
            self.saisie.Text = u""
            self.resultat.Text = u""
        elif t == u"⌫":
            self.saisie.Text = self.saisie.Text[:-1]
        else:
            i = self.saisie.CaretIndex
            self.saisie.Text = self.saisie.Text[:i] + t + self.saisie.Text[i:]
            self.saisie.CaretIndex = i + len(t)
        self.saisie.Focus()

    def on_histo(self, s, a):
        i = self.lst.SelectedIndex
        if 0 <= i < len(self.histo):
            self.saisie.Text = self.histo[i][0]
            self.saisie.CaretIndex = len(self.saisie.Text)
            self.saisie.Focus()

    def on_copier(self, s, a):
        if self.histo:
            try:
                Clipboard.SetText(self.histo[0][1].replace(u" ", u""))
                self.resultat.Text = u"= %s  (copié)" % self.histo[0][1]
            except Exception:
                pass

    # --- taille
    def basculer(self):
        if self.reduite:
            self.pave.Visibility = Visibility.Visible
            self.Height = self.haut_pleine
            self.b_reduire.Content = u"▾"
            self.reduite = False
        else:
            self.haut_pleine = self.ActualHeight
            self.pave.Visibility = Visibility.Collapsed
            self.Height = self.barre.ActualHeight + 70
            self.b_reduire.Content = u"▸"
            self.reduite = True
        self.saisie.Focus()

    def on_reduire(self, s, a):
        self.basculer()

    def on_dessus(self, s, a):
        self.Topmost = bool(self.chk_dessus.IsChecked)

    def on_ferme(self, s, a):
        try:
            AppDomain.CurrentDomain.SetData(CLE, None)
        except Exception:
            pass


# ------------------------------------------------------------------ lancement
w = AppDomain.CurrentDomain.GetData(CLE)
try:
    vivante = w is not None and w.IsLoaded
except Exception:
    vivante = False

if vivante:
    # deja ouverte : un clic sur l'icone la reduit ou l'agrandit
    if w.WindowState == WindowState.Minimized:
        w.WindowState = WindowState.Normal
    w.basculer()
    w.Activate()
else:
    w = Calculatrice(os.path.join(os.path.dirname(__file__), "ui.xaml"))
    AppDomain.CurrentDomain.SetData(CLE, w)
    w.show(modal=False)
