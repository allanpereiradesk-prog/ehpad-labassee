# -*- coding: utf-8 -*-
"""Lien Excel : exporte des parametres vers un vrai fichier Excel (.xlsx),
on les modifie dans Excel, puis on les reimporte dans Revit
(apercu des changements avant d'appliquer)."""

__title__ = "Lien\nExcel"

import os
import re
from pyrevit import revit, DB, forms
from System.Windows import Visibility
from System.Windows.Controls import CheckBox
from System.Windows.Media import SolidColorBrush, Color
from System.Windows.Input import Mouse, Cursors
import allan_excel as xl

doc = revit.doc
uidoc = revit.uidoc


def dossier_defaut():
    d = os.path.dirname(doc.PathName) if doc.PathName else os.path.join(os.path.expanduser("~"), "Documents")
    return d if os.path.isdir(d) else os.path.expanduser("~")


def nettoyer(n):
    return re.sub(u'[\\\\/:*?"<>|]', u"_", n).strip() or u"export"


class Fenetre(forms.WPFWindow):
    def __init__(self, xaml):
        self.pret = False
        forms.WPFWindow.__init__(self, xaml)
        self.cats = xl.categories(doc)
        self.cb_cat.ItemsSource = [c[0] for c in self.cats]
        self.infos = []
        self.coches = []
        self.changements = []
        self.pret = True
        if self.cats:
            self.cb_cat.SelectedIndex = 0
        else:
            self.log(u"Aucun élément dans le projet.")

    def log(self, lignes):
        if isinstance(lignes, basestring):
            lignes = [lignes]
        self.journal.Text = (u"\n".join(l for l in lignes if l) + u"\n" + self.journal.Text).strip()

    # ---------------------------------------------------- export
    def _portee(self):
        return "vue" if self.p_vue.IsChecked else ("selection" if self.p_sel.IsChecked else "projet")

    def _elements(self):
        i = self.cb_cat.SelectedIndex
        if i < 0:
            return []
        return xl.elements(doc, self.cats[i][1], self._portee(), uidoc)

    def on_cat(self, s, a):
        if not self.pret or self.cb_cat.SelectedIndex < 0:
            return
        anciens = set(cb.Tag.nom for cb in self.coches if cb.IsChecked)
        els = self._elements()
        self.nb_el.Text = u"%d élément(s) concerné(s)" % len(els)
        self.infos = xl.parametres(doc, els) if els else []
        self.wp_params.Children.Clear()
        self.coches = []
        gris = SolidColorBrush(Color.FromRgb(140, 140, 140))
        for inf in self.infos:
            cb = CheckBox()
            cb.Content = inf.libelle() + (u"  (lecture seule)" if inf.lecture else u"")
            cb.Tag = inf
            cb.Width = 300
            cb.IsChecked = inf.nom in anciens
            if inf.lecture:
                cb.Foreground = gris
            self.wp_params.Children.Add(cb)
            self.coches.append(cb)
        nom_cat = self.cats[self.cb_cat.SelectedIndex][0].split(u" (")[0]
        projet = os.path.splitext(os.path.basename(doc.PathName or doc.Title))[0]
        self.t_export.Text = os.path.join(dossier_defaut(), nettoyer(u"%s - %s.xlsx" % (projet, nom_cat)))

    def on_cherche(self, s, a):
        t = (self.t_cherche.Text or u"").lower()
        for cb in self.coches:
            cb.Visibility = Visibility.Visible if t in unicode(cb.Content).lower() else Visibility.Collapsed

    def on_modif(self, s, a):
        for cb in self.coches:
            if not cb.Tag.lecture and cb.Visibility == Visibility.Visible:
                cb.IsChecked = True

    def on_aucun(self, s, a):
        for cb in self.coches:
            cb.IsChecked = False

    def on_fichier_export(self, s, a):
        f = forms.save_file(file_ext="xlsx", default_name=os.path.basename(self.t_export.Text),
                            init_dir=os.path.dirname(self.t_export.Text) or dossier_defaut())
        if f:
            self.t_export.Text = f if f.lower().endswith(".xlsx") else f + ".xlsx"

    def on_exporter(self, s, a):
        infos = [cb.Tag for cb in self.coches if cb.IsChecked]
        els = self._elements()
        if not els:
            self.log(u"Aucun élément à exporter.")
            return
        if not infos:
            self.log(u"Coche au moins un paramètre.")
            return
        chemin = self.t_export.Text.strip()
        if not chemin.lower().endswith(".xlsx"):
            chemin += ".xlsx"
        log = []
        Mouse.OverrideCursor = Cursors.Wait
        try:
            xl.exporter(doc, els, infos, chemin, log)
        except IOError as ex:
            log.append(u"Impossible d'écrire le fichier (déjà ouvert dans Excel ?) : %s" % ex)
            chemin = None
        except Exception as ex:
            log.append(u"Erreur : %s" % ex)
            chemin = None
        finally:
            Mouse.OverrideCursor = None
        self.log(log)
        if chemin:
            self.t_import.Text = chemin
            if self.o_ouvrir.IsChecked:
                try:
                    import System.Diagnostics as D
                    p = D.ProcessStartInfo(chemin)
                    p.UseShellExecute = True
                    D.Process.Start(p)
                except Exception as ex:
                    self.log(u"Fichier créé mais pas ouvert automatiquement : %s" % ex)

    # ---------------------------------------------------- import
    def on_fichier_import(self, s, a):
        f = forms.pick_file(file_ext="xlsx", init_dir=os.path.dirname(self.t_import.Text) or dossier_defaut())
        if f:
            self.t_import.Text = f

    def on_analyser(self, s, a):
        chemin = self.t_import.Text.strip()
        self.changements = []
        self.b_appliquer.IsEnabled = False
        if not os.path.exists(chemin):
            self.log(u"Fichier introuvable : %s" % chemin)
            return
        log = []
        Mouse.OverrideCursor = Cursors.Wait
        try:
            lignes, meta = xl.lire(chemin)
            self.changements = xl.comparer(doc, lignes, meta, log)
        except IOError as ex:
            log.append(u"Impossible de lire le fichier (ferme-le dans Excel puis réessaie) : %s" % ex)
        except Exception as ex:
            log.append(u"Erreur : %s" % ex)
        finally:
            Mouse.OverrideCursor = None
        self.log(log)
        self.lst_ch.ItemsSource = [u"%s  |  %s :  %s  →  %s%s" % (c.libelle, c.nom_param, xl._txt(c.ancien) or u"(vide)",
                                                                     xl._txt(c.nouveau) or u"(vide)",
                                                                     u"   [type]" if c.est_type else u"")
                                   for c in self.changements]
        self.resume.Text = (u"%d valeur(s) à modifier dans Revit" % len(self.changements)) if self.changements else \
            u"Aucune différence avec le projet."
        self.b_appliquer.IsEnabled = bool(self.changements)

    def on_appliquer(self, s, a):
        if not self.changements:
            return
        log = []
        Mouse.OverrideCursor = Cursors.Wait
        try:
            xl.appliquer(doc, self.changements, log)
        finally:
            Mouse.OverrideCursor = None
        self.log(log)
        self.on_analyser(None, None)


Fenetre(os.path.join(os.path.dirname(__file__), "ui.xaml")).show_dialog()
