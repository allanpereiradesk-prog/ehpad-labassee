# -*- coding: utf-8 -*-
"""Modifie les hypotheses du bilan thermique (temperatures, renouvellement...)
et permet d'effacer les valeurs U memorisees."""

from pyrevit import revit, DB, forms, script

config = script.get_config()


def cfg_get(key, default):
    try:
        v = getattr(config, key)
        return default if v is None else v
    except Exception:
        return default


def ask_float(prompt, default):
    txt = forms.ask_for_string(default=str(default), prompt=prompt,
                               title="Reglages bilan thermique")
    if txt is None:
        script.exit()
    try:
        return float(str(txt).replace(",", "."))
    except Exception:
        return float(default)


choix = forms.ask_for_one_item(
    ["Modifier les hypotheses de calcul",
     "Effacer les valeurs U memorisees",
     "Voir les reglages actuels"],
    title="Reglages", prompt="Que veux-tu faire ?")

if not choix:
    script.exit()

if choix == "Voir les reglages actuels":
    u_vals = cfg_get("u_values", {})
    lignes = [
        "Temperature exterieure : " + str(cfg_get("t_ext", -7.0)) + " degres C",
        "Temperature interieure : " + str(cfg_get("t_int", 19.0)) + " degres C",
        "Renouvellement d'air : " + str(cfg_get("n_air", 0.6)) + " vol/h",
        "Ponts thermiques : +" + str(cfg_get("pct_pt", 15.0)) + " %",
        "b plancher bas : " + str(cfg_get("b_sol", 0.45)),
        "",
        "Valeurs U memorisees : " + str(len(u_vals)),
    ]
    try:
        for k in u_vals:
            lignes.append("   " + str(k) + " = " + str(u_vals[k]) + " W/(m2.K)")
    except Exception:
        pass
    forms.alert("\n".join(lignes), title="Reglages actuels")
    script.exit()

if choix == "Effacer les valeurs U memorisees":
    setattr(config, "u_values", {})
    script.save_config()
    forms.alert("Valeurs U effacees. Elles seront redemandees au prochain calcul.")
    script.exit()

t_ext = ask_float("Temperature exterieure de base (degres C)", cfg_get("t_ext", -7.0))
t_int = ask_float("Temperature interieure de consigne (degres C)", cfg_get("t_int", 19.0))
n_air = ask_float("Taux de renouvellement d'air (vol/h)", cfg_get("n_air", 0.6))
pct_pt = ask_float("Majoration ponts thermiques (%)", cfg_get("pct_pt", 15.0))
b_sol = ask_float("Coefficient plancher sur terre-plein", cfg_get("b_sol", 0.45))

setattr(config, "t_ext", t_ext)
setattr(config, "t_int", t_int)
setattr(config, "n_air", n_air)
setattr(config, "pct_pt", pct_pt)
setattr(config, "b_sol", b_sol)
setattr(config, "initialise", True)
script.save_config()

forms.alert("Reglages enregistres.\nDeltaT = " + str(t_int - t_ext) + " K")
