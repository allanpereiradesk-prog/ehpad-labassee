# -*- coding: utf-8 -*-
"""Bilan thermique EN 12831 simplifie : deperditions local par local.

Pour chaque espace MEP :
  - transmission a travers l'enveloppe (somme U x A x b x DeltaT)
  - majoration ponts thermiques (pourcentage)
  - renouvellement d'air (0.34 x n x V x DeltaT)

Les parois sont classees via le parametre Fonction des types de murs
(Exterieur / Fondation = deperditif, Interieur = ignore). Les fenetres et
portes des murs exterieurs sont deduites de la surface opaque et comptees
avec leur propre coefficient U.

Cadre pedagogique : pas de valeur reglementaire (pas de moteur Th-BCE).
"""

import os

from pyrevit import revit, DB, forms, script

doc = revit.doc
output = script.get_output()
config = script.get_config()

FT2_TO_M2 = 0.09290304
FT3_TO_M3 = 0.02831685
FT_TO_M = 0.3048


def get_name(el):
    try:
        n = el.Name
        if n:
            return n
    except Exception:
        pass
    for bip in (DB.BuiltInParameter.ROOM_NAME,
                DB.BuiltInParameter.ALL_MODEL_TYPE_NAME,
                DB.BuiltInParameter.SYMBOL_NAME_PARAM):
        try:
            p = el.get_Parameter(bip)
            if p and p.AsString():
                return p.AsString()
        except Exception:
            pass
    try:
        return str(el.Id.Value)
    except Exception:
        return str(el.Id)


def to_m2(v):
    try:
        return DB.UnitUtils.ConvertFromInternalUnits(v, DB.UnitTypeId.SquareMeters)
    except Exception:
        return v * FT2_TO_M2


def to_m3(v):
    try:
        return DB.UnitUtils.ConvertFromInternalUnits(v, DB.UnitTypeId.CubicMeters)
    except Exception:
        return v * FT3_TO_M3


def to_m(v):
    try:
        return DB.UnitUtils.ConvertFromInternalUnits(v, DB.UnitTypeId.Meters)
    except Exception:
        return v * FT_TO_M


def u_from_type(type_el):
    try:
        p = type_el.get_Parameter(
            DB.BuiltInParameter.ANALYTICAL_HEAT_TRANSFER_COEFFICIENT)
        if p and p.HasValue:
            raw = p.AsDouble()
            if raw and raw > 0:
                try:
                    return DB.UnitUtils.ConvertFromInternalUnits(
                        raw, DB.UnitTypeId.WattsPerSquareMeterKelvin)
                except Exception:
                    return raw
    except Exception:
        pass
    return None


def cfg_get(key, default):
    try:
        v = getattr(config, key)
        if v is None:
            return default
        return v
    except Exception:
        return default


def cfg_set(key, value):
    try:
        setattr(config, key, value)
    except Exception:
        pass


def ask_float(prompt, default):
    txt = forms.ask_for_string(default=str(default), prompt=prompt,
                               title="Bilan thermique - reglages")
    if txt is None:
        script.exit()
    try:
        return float(str(txt).replace(",", "."))
    except Exception:
        return float(default)


def cat_id_of(bic):
    try:
        c = DB.Category.GetCategory(doc, bic)
        if c is not None:
            try:
                return c.Id.Value
            except Exception:
                return c.Id.IntegerValue
    except Exception:
        pass
    return -1


CAT_WALLS = cat_id_of(DB.BuiltInCategory.OST_Walls)
CAT_WINDOWS = cat_id_of(DB.BuiltInCategory.OST_Windows)
CAT_DOORS = cat_id_of(DB.BuiltInCategory.OST_Doors)
CAT_FLOORS = cat_id_of(DB.BuiltInCategory.OST_Floors)
CAT_ROOFS = cat_id_of(DB.BuiltInCategory.OST_Roofs)
CAT_CEIL = cat_id_of(DB.BuiltInCategory.OST_Ceilings)

ENVELOPE_CATS = (CAT_WALLS, CAT_WINDOWS, CAT_DOORS, CAT_FLOORS, CAT_ROOFS,
                 CAT_CEIL)

U_DEFAULTS = {
    CAT_WALLS: 0.30,
    CAT_WINDOWS: 1.60,
    CAT_DOORS: 2.00,
    CAT_FLOORS: 0.30,
    CAT_ROOFS: 0.25,
    CAT_CEIL: 0.25,
}

# ------------------------------------------------------------------ reglages

first_run = cfg_get("initialise", False) is not True

t_ext = cfg_get("t_ext", -7.0)
t_int = cfg_get("t_int", 19.0)
n_air = cfg_get("n_air", 0.6)
pct_pt = cfg_get("pct_pt", 15.0)
b_sol = cfg_get("b_sol", 0.45)
u_toit = cfg_get("u_toit", 0.25)

if first_run:
    forms.alert("Premier lancement : quelques reglages a saisir.\n"
                "Ils seront memorises pour les fois suivantes.",
                title="Bilan thermique EN 12831")
    t_ext = ask_float("Temperature exterieure de base (degres C)\n"
                      "ex : -7 pour une grande partie de la France", t_ext)
    t_int = ask_float("Temperature interieure de consigne (degres C)\n"
                      "ex : 19 pour des bureaux", t_int)
    n_air = ask_float("Taux de renouvellement d'air (volumes / heure)\n"
                      "ex : 0.6", n_air)
    pct_pt = ask_float("Majoration ponts thermiques (%)\n"
                       "ex : 15", pct_pt)
    b_sol = ask_float("Coefficient de reduction pour planchers sur terre-plein\n"
                      "ex : 0.45", b_sol)
    u_toit = ask_float("U de la toiture en W/(m2.K), utilise seulement si\n"
                       "aucune toiture n'est modelisee\nex : 0.25", u_toit)
    cfg_set("t_ext", t_ext)
    cfg_set("t_int", t_int)
    cfg_set("n_air", n_air)
    cfg_set("pct_pt", pct_pt)
    cfg_set("b_sol", b_sol)
    cfg_set("u_toit", u_toit)
    cfg_set("initialise", True)
    script.save_config()

delta_t = t_int - t_ext
if delta_t <= 0:
    forms.alert("La temperature interieure doit etre superieure a l'exterieure.")
    script.exit()

# ------------------------------------------------------------------- espaces

spaces = [s for s in DB.FilteredElementCollector(doc)
          .OfCategory(DB.BuiltInCategory.OST_MEPSpaces)
          .WhereElementIsNotElementType().ToElements()
          if s.Location is not None and s.Area > 0]

if not spaces:
    forms.alert("Aucun espace MEP place dans le projet.\n"
                "Cree d'abord les espaces (onglet Analyser).")
    script.exit()

# Niveau bas / haut pris PARMI LES NIVEAUX QUI ONT DES ESPACES
# (sinon un niveau RDJ / Fondations / Toiture sans espace fait sauter
# le plancher bas et la toiture du calcul)
_niv_espaces = {}
for _s in spaces:
    try:
        if _s.Level is not None:
            _niv_espaces[str(_s.Level.Id)] = _s.Level
    except Exception:
        pass
levels = sorted(_niv_espaces.values(), key=lambda l: l.Elevation)
lowest_level_id = levels[0].Id if levels else DB.ElementId.InvalidElementId
highest_level_id = levels[-1].Id if levels else DB.ElementId.InvalidElementId

phases = list(doc.Phases)
phase = phases[-1] if phases else None

# --------------------------------------------- classement des parois


def wall_is_exterior(host):
    """Parametre Fonction du type de mur : 1 = Exterieur, 2 = Fondation,
    0 = Interieur. Renvoie None si l'information est absente."""
    try:
        wt = doc.GetElement(host.GetTypeId())
        p = wt.get_Parameter(DB.BuiltInParameter.FUNCTION_PARAM)
        if p and p.HasValue:
            return p.AsInteger() in (1, 2)
    except Exception:
        pass
    return None


# ------------------------------------------ passe 1 : geometrie des parois

opts = DB.SpatialElementBoundaryOptions()
calc = DB.SpatialElementGeometryCalculator(doc, opts)

boundaries = {}
host_space_count = {}
errors = []

with forms.ProgressBar(title="Analyse des parois... {value}/{max_value}") as pb:
    idx = 0
    for sp in spaces:
        idx += 1
        pb.update_progress(idx, len(spaces))
        entries = []
        try:
            res = calc.CalculateSpatialElementGeometry(sp)
            solid = res.GetGeometry()
            for face in solid.Faces:
                for sub in res.GetBoundaryFaceInfo(face):
                    try:
                        host_id = sub.SpatialBoundaryElement.HostElementId
                        if host_id == DB.ElementId.InvalidElementId:
                            continue
                        host = doc.GetElement(host_id)
                        if host is None:
                            continue
                        sf = sub.GetSubface()
                        area = sf.Area if sf else 0.0
                        if area <= 0:
                            continue
                        cat_id = -1
                        try:
                            cat_id = host.Category.Id.Value
                        except Exception:
                            try:
                                cat_id = host.Category.Id.IntegerValue
                            except Exception:
                                cat_id = -1
                        entries.append([host_id, host.GetTypeId(), cat_id,
                                        to_m2(area)])
                        key = str(host_id)
                        s = host_space_count.get(key)
                        if s is None:
                            s = set()
                            host_space_count[key] = s
                        s.add(str(sp.Id))
                    except Exception:
                        continue
        except Exception as ex:
            errors.append(get_name(sp) + " : " + str(ex))
        boundaries[str(sp.Id)] = entries

# ------------------- fenetres et portes des murs exterieurs par espace


def insert_area(fi):
    sym = fi.Symbol
    pairs = [(DB.BuiltInParameter.WINDOW_HEIGHT, DB.BuiltInParameter.WINDOW_WIDTH),
             (DB.BuiltInParameter.DOOR_HEIGHT, DB.BuiltInParameter.DOOR_WIDTH),
             (DB.BuiltInParameter.FAMILY_HEIGHT_PARAM,
              DB.BuiltInParameter.FAMILY_WIDTH_PARAM)]
    for hp, wp in pairs:
        try:
            h = sym.get_Parameter(hp)
            w = sym.get_Parameter(wp)
            if h and w and h.AsDouble() > 0 and w.AsDouble() > 0:
                return to_m2(h.AsDouble() * w.AsDouble())
        except Exception:
            pass
    return 0.0


def space_of_insert(fi):
    for attr in ("Space", "FromSpace", "ToSpace"):
        try:
            prop = getattr(fi, attr)
            sp = prop[phase] if phase is not None else prop
            if sp is not None:
                return sp
        except Exception:
            continue
    return None


openings = {}
deduct = {}
orphan_area = 0.0

for bic in (DB.BuiltInCategory.OST_Windows, DB.BuiltInCategory.OST_Doors):
    for fi in (DB.FilteredElementCollector(doc).OfCategory(bic)
               .WhereElementIsNotElementType().ToElements()):
        try:
            host = fi.Host
        except Exception:
            host = None
        if host is None or not isinstance(host, DB.Wall):
            continue
        if wall_is_exterior(host) is not True:
            continue
        area = insert_area(fi)
        if area <= 0:
            continue
        sp = space_of_insert(fi)
        if sp is None:
            orphan_area += area
            continue
        skey = str(sp.Id)
        cat_id = -1
        try:
            cat_id = fi.Category.Id.Value
        except Exception:
            try:
                cat_id = fi.Category.Id.IntegerValue
            except Exception:
                cat_id = -1
        openings.setdefault(skey, []).append([fi.GetTypeId(), cat_id, area])
        dkey = skey + "|" + str(host.Id)
        deduct[dkey] = deduct.get(dkey, 0.0) + area

# --------------------------------------- valeurs U des types rencontres

used_types = {}
for sp in spaces:
    skey = str(sp.Id)
    sp_level_id = sp.Level.Id if sp.Level else DB.ElementId.InvalidElementId
    for host_id, type_id, cat_id, area in boundaries.get(skey, []):
        if cat_id not in ENVELOPE_CATS:
            continue
        if cat_id == CAT_WALLS:
            host = doc.GetElement(host_id)
            ext = wall_is_exterior(host)
            if ext is False:
                continue
            if ext is None and len(host_space_count.get(str(host_id), set())) > 1:
                continue
        elif cat_id == CAT_FLOORS and sp_level_id != lowest_level_id:
            continue
        elif cat_id in (CAT_ROOFS, CAT_CEIL) and sp_level_id != highest_level_id:
            continue
        used_types[str(type_id)] = (type_id, cat_id)
    for type_id, cat_id, area in openings.get(skey, []):
        used_types[str(type_id)] = (type_id, cat_id)

stored_u = {}
try:
    stored_u = dict(cfg_get("u_values", {}))
except Exception:
    stored_u = {}

u_by_type = {}
asked = []
for key, pair in used_types.items():
    type_id = pair[0]
    cat_id = pair[1]
    type_el = doc.GetElement(type_id)
    if type_el is None:
        continue
    tname = get_name(type_el)
    u = u_from_type(type_el)
    if u is None or u <= 0:
        if tname in stored_u:
            u = float(stored_u[tname])
        else:
            default_u = U_DEFAULTS.get(cat_id, 0.30)
            txt = forms.ask_for_string(
                default=str(default_u),
                prompt="Coefficient U manquant dans Revit pour :\n\n" + tname +
                       "\n\nSaisir U en W/(m2.K) :",
                title="Valeurs U")
            if txt is None:
                script.exit()
            try:
                u = float(str(txt).replace(",", "."))
            except Exception:
                u = default_u
            stored_u[tname] = u
            asked.append(tname)
    u_by_type[key] = (u, tname, cat_id)

if asked:
    cfg_set("u_values", stored_u)
    script.save_config()

# --------------------------------------------- passe 2 : calcul par espace

results = []
toit_estime = 0
surf_vitree_tot = 0.0

for sp in spaces:
    skey = str(sp.Id)
    surf_m2 = to_m2(sp.Area)
    vol_m3 = to_m3(sp.Volume) if sp.Volume and sp.Volume > 0 else 0.0
    if vol_m3 <= 0:
        try:
            h = to_m(sp.UnboundedHeight)
        except Exception:
            h = 2.5
        vol_m3 = surf_m2 * (h if h and h > 0 else 2.5)

    level_id = sp.Level.Id if sp.Level else DB.ElementId.InvalidElementId

    phi_t = 0.0
    a_opaque = 0.0
    a_vitree = 0.0
    has_top = False

    for host_id, type_id, cat_id, area in boundaries.get(skey, []):
        if cat_id not in ENVELOPE_CATS:
            continue
        info = u_by_type.get(str(type_id))
        if info is None:
            continue
        u = info[0]
        b = 1.0

        if cat_id == CAT_WALLS:
            host = doc.GetElement(host_id)
            ext = wall_is_exterior(host)
            if ext is False:
                continue
            if ext is None and len(host_space_count.get(str(host_id), set())) > 1:
                continue
            net = area - deduct.get(skey + "|" + str(host_id), 0.0)
            if net < 0:
                net = 0.0
            area = net
            a_opaque += area
        elif cat_id == CAT_FLOORS:
            if level_id == lowest_level_id:
                b = b_sol
            else:
                continue
            a_opaque += area
        elif cat_id in (CAT_ROOFS, CAT_CEIL):
            if level_id != highest_level_id:
                continue
            has_top = True
            a_opaque += area
        else:
            a_opaque += area

        phi_t += u * area * b * delta_t

    for type_id, cat_id, area in openings.get(skey, []):
        info = u_by_type.get(str(type_id))
        if info is None:
            continue
        phi_t += info[0] * area * delta_t
        a_vitree += area

    if (not has_top) and level_id == highest_level_id and u_toit > 0:
        phi_t += u_toit * surf_m2 * delta_t
        toit_estime += 1

    surf_vitree_tot += a_vitree

    phi_pt = phi_t * (pct_pt / 100.0)
    phi_v = 0.34 * (n_air * vol_m3) * delta_t
    phi_total = phi_t + phi_pt + phi_v
    ratio = (phi_total / surf_m2) if surf_m2 > 0 else 0.0

    results.append({
        "space": sp,
        "nom": get_name(sp),
        "niveau": sp.Level.Name if sp.Level else "",
        "surface": surf_m2,
        "volume": vol_m3,
        "opaque": a_opaque,
        "vitree": a_vitree,
        "transmission": phi_t,
        "ponts": phi_pt,
        "ventilation": phi_v,
        "total": phi_total,
        "ratio": ratio,
    })

# ------------------------------------- parametres de projet sur les espaces

PARAMS = [
    "TH_Transmission_W",
    "TH_PontsThermiques_W",
    "TH_Ventilation_W",
    "TH_Deperditions_W",
    "TH_Ratio_W_par_m2",
]


def ensure_project_params():
    """Remet toujours le fichier de parametres partages de l'utilisateur."""
    app = doc.Application
    previous = app.SharedParametersFilename
    try:
        return _ensure_project_params()
    finally:
        try:
            app.SharedParametersFilename = previous
        except Exception:
            pass


def _ensure_project_params():
    app = doc.Application
    sp_path = os.path.join(os.path.dirname(__file__), "params_thermique.txt")
    previous = app.SharedParametersFilename
    if not os.path.exists(sp_path):
        f = open(sp_path, "w")
        f.write("# This is a Revit shared parameter file.\n")
        f.write("# Do not edit manually.\n")
        f.write("*META\tVERSION\tMINVERSION\n")
        f.write("META\t2\t1\n")
        f.write("*GROUP\tID\tNAME\n")
        f.write("*PARAM\tGUID\tNAME\tDATATYPE\tDATACATEGORY\tGROUP\t"
                "VISIBLE\tDESCRIPTION\tUSERMODIFIABLE\tHIDEWHENNOVALUE\n")
        f.close()
    app.SharedParametersFilename = sp_path
    def_file = app.OpenSharedParameterFile()
    if def_file is None:
        app.SharedParametersFilename = previous
        return False

    group = None
    for g in def_file.Groups:
        if g.Name == "Thermique":
            group = g
            break
    if group is None:
        group = def_file.Groups.Create("Thermique")

    cat = doc.Settings.Categories.get_Item(DB.BuiltInCategory.OST_MEPSpaces)
    cat_set = app.Create.NewCategorySet()
    cat_set.Insert(cat)
    binding = app.Create.NewInstanceBinding(cat_set)
    bindings = doc.ParameterBindings

    existing = []
    it = bindings.ForwardIterator()
    it.Reset()
    while it.MoveNext():
        try:
            existing.append(it.Key.Name)
        except Exception:
            pass

    for name in PARAMS:
        if name in existing:
            continue
        definition = None
        for d in group.Definitions:
            if d.Name == name:
                definition = d
                break
        if definition is None:
            try:
                opt = DB.ExternalDefinitionCreationOptions(
                    name, DB.SpecTypeId.Number)
                definition = group.Definitions.Create(opt)
            except Exception:
                continue
        try:
            bindings.Insert(definition, binding)
        except Exception:
            try:
                bindings.Insert(definition, binding, DB.GroupTypeId.Energy)
            except Exception:
                pass

    app.SharedParametersFilename = previous
    return True


def write_value(el, pname, value):
    p = el.LookupParameter(pname)
    if p and not p.IsReadOnly:
        try:
            p.Set(float(value))
            return True
        except Exception:
            return False
    return False


t = DB.Transaction(doc, "Bilan thermique EN 12831")
t.Start()
written = 0
try:
    ensure_project_params()
    for r in results:
        sp = r["space"]
        ok = write_value(sp, "TH_Transmission_W", round(r["transmission"], 1))
        write_value(sp, "TH_PontsThermiques_W", round(r["ponts"], 1))
        write_value(sp, "TH_Ventilation_W", round(r["ventilation"], 1))
        write_value(sp, "TH_Deperditions_W", round(r["total"], 1))
        write_value(sp, "TH_Ratio_W_par_m2", round(r["ratio"], 1))
        if ok:
            written += 1
    t.Commit()
except Exception as ex:
    t.RollBack()
    forms.alert("Erreur pendant l'ecriture des resultats :\n" + str(ex))
    script.exit()

# ------------------------------------------------ nomenclature + feuille

SCHEDULE_NAME = "Bilan thermique - deperditions"
SHEET_NUMBER = "A-06"
SHEET_NAME = "Bilan thermique"


def find_schedule(name):
    for s in DB.FilteredElementCollector(doc).OfClass(DB.ViewSchedule).ToElements():
        if get_name(s) == name:
            return s
    return None


def find_sheet(number):
    for s in DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet).ToElements():
        if s.SheetNumber == number:
            return s
    return None


def build_schedule():
    cat = DB.Category.GetCategory(doc, DB.BuiltInCategory.OST_MEPSpaces)
    sched = DB.ViewSchedule.CreateSchedule(doc, cat.Id)
    sched.Name = SCHEDULE_NAME
    defn = sched.Definition
    defn.IsItemized = True

    wanted = ["Nom", "Niveau", "Surface", "Volume",
              "TH_Transmission_W", "TH_Ventilation_W",
              "TH_Deperditions_W", "TH_Ratio_W_par_m2"]
    # nom FR, nom EN ou parametre integre : marche quelle que soit la langue de Revit
    alias = {
        "Nom": (["Name"], ["ROOM_NAME"]),
        "Niveau": (["Level"], ["ROOM_LEVEL_ID", "SCHEDULE_LEVEL_PARAM"]),
        "Surface": (["Area"], ["ROOM_AREA"]),
        "Volume": (["Volume"], ["ROOM_VOLUME"]),
    }

    def bip_ids(noms):
        r = set()
        for n in noms:
            try:
                r.add(int(getattr(DB.BuiltInParameter, n)))
            except Exception:
                pass
        return r

    def correspond(sf, want):
        noms, bips = alias.get(want, ([], []))
        try:
            if sf.GetName(doc) in [want] + noms:
                return True
        except Exception:
            pass
        try:
            return int(sf.ParameterId.Value) in bip_ids(bips)
        except Exception:
            return False

    added = {}
    for want in wanted:
        for sf in defn.GetSchedulableFields():
            try:
                if correspond(sf, want):
                    f = defn.AddField(sf)
                    added[want] = f
                    break
            except Exception:
                continue

    for key in ("TH_Transmission_W", "TH_Ventilation_W", "TH_Deperditions_W"):
        f = added.get(key)
        if f is not None:
            try:
                f.DisplayType = DB.ScheduleFieldDisplayType.Totals
            except Exception:
                pass

    e_acc = unichr(0xe9)
    sup2 = unichr(0xb2)
    headings = {
        "Nom": u"Local",
        "TH_Transmission_W": u"Transmission (W)",
        "TH_Ventilation_W": u"Ventilation (W)",
        "TH_Deperditions_W": u"D" + e_acc + u"perditions (W)",
        "TH_Ratio_W_par_m2": u"Ratio (W/m" + sup2 + u")",
    }
    for key, label in headings.items():
        f = added.get(key)
        if f is not None:
            try:
                f.ColumnHeading = label
            except Exception:
                pass

    niveau_field = added.get("Niveau")
    nom_field = added.get("Nom")
    try:
        defn.ClearSortGroupFields()
        if niveau_field is not None:
            sg = DB.ScheduleSortGroupField(niveau_field.FieldId)
            sg.ShowHeader = True
            sg.ShowFooter = True
            sg.ShowBlankLine = False
            defn.AddSortGroupField(sg)
        if nom_field is not None:
            sg2 = DB.ScheduleSortGroupField(nom_field.FieldId)
            sg2.ShowHeader = False
            sg2.ShowFooter = False
            sg2.ShowBlankLine = False
            defn.AddSortGroupField(sg2)
    except Exception:
        pass

    try:
        defn.ShowGrandTotal = True
        defn.ShowGrandTotalTitle = True
    except Exception:
        pass

    try:
        body = sched.GetTableData().GetSectionData(DB.SectionType.Body)
        for c in range(body.NumberOfColumns):
            body.SetColumnWidth(c, 0.16)
    except Exception:
        pass

    return sched


t2 = DB.Transaction(doc, "Nomenclature bilan thermique")
t2.Start()
sheet_msg = ""
try:
    sched = find_schedule(SCHEDULE_NAME)
    if sched is None:
        sched = build_schedule()

    sheet = find_sheet(SHEET_NUMBER)
    if sheet is None:
        tb = None
        tb_types = (DB.FilteredElementCollector(doc)
                    .OfCategory(DB.BuiltInCategory.OST_TitleBlocks)
                    .WhereElementIsElementType().ToElements())
        for x in tb_types:
            if tb is None:
                tb = x
            if get_name(x) == "A1":
                tb = x
                break
        sheet = DB.ViewSheet.Create(doc, tb.Id if tb else DB.ElementId.InvalidElementId)
        sheet.SheetNumber = SHEET_NUMBER
        sheet.Name = SHEET_NAME

    already = False
    ssi_list = (DB.FilteredElementCollector(doc)
                .OfClass(DB.ScheduleSheetInstance).ToElements())
    for ssi in ssi_list:
        if ssi.ScheduleId == sched.Id and ssi.OwnerViewId == sheet.Id:
            already = True
            break
    if not already:
        DB.ScheduleSheetInstance.Create(doc, sheet.Id, sched.Id,
                                        DB.XYZ(1.45, 1.75, 0))
    sheet_msg = "Feuille " + SHEET_NUMBER + " - " + SHEET_NAME
    t2.Commit()
except Exception as ex:
    t2.RollBack()
    sheet_msg = "Nomenclature/feuille non creee : " + str(ex)

# ------------------------------------------------------------- rapport

total_bat = sum(r["total"] for r in results)
total_surf = sum(r["surface"] for r in results)

output.print_md("# Bilan thermique EN 12831 (simplifie)")
output.print_md(
    "**Hypotheses** : Text = {0} C, Tint = {1} C, DeltaT = {2} K, "
    "renouvellement = {3} vol/h, ponts thermiques = +{4} %, "
    "b plancher bas = {5}".format(t_ext, t_int, delta_t, n_air, pct_pt, b_sol))

rows = []
for r in sorted(results, key=lambda x: (x["niveau"], x["nom"])):
    rows.append([r["niveau"], r["nom"], round(r["surface"], 1),
                 round(r["volume"], 1), round(r["opaque"], 1),
                 round(r["vitree"], 1), int(round(r["transmission"])),
                 int(round(r["ventilation"])), int(round(r["total"])),
                 int(round(r["ratio"]))])

output.print_table(
    table_data=rows,
    title="Deperditions par local",
    columns=["Niveau", "Local", "S (m2)", "V (m3)", "Opaque (m2)",
             "Vitre (m2)", "Transmission (W)", "Ventilation (W)",
             "TOTAL (W)", "W/m2"])

output.print_md("## Total batiment")
output.print_md("- Deperditions totales : **{0} W** soit {1} kW".format(
    int(round(total_bat)), round(total_bat / 1000.0, 2)))
output.print_md("- Surface totale : {0} m2".format(round(total_surf, 1)))
if total_surf > 0:
    output.print_md("- Ratio moyen : **{0} W/m2**".format(
        int(round(total_bat / total_surf))))
output.print_md("- Surface vitree et portes exterieures prise en compte : "
                "{0} m2".format(round(surf_vitree_tot, 1)))
output.print_md("- Resultats ecrits sur {0} espaces".format(written))
output.print_md("- " + sheet_msg)

output.print_md("## Points de vigilance")
if toit_estime:
    output.print_md("- Aucune toiture modelisee au dernier niveau : "
                    "une toiture fictive a U = {0} W/(m2.K) a ete appliquee "
                    "sur {1} espaces. Modelise la toiture pour un resultat "
                    "reel.".format(u_toit, toit_estime))
if orphan_area > 0:
    output.print_md("- {0} m2 de menuiseries exterieures n'ont pas pu etre "
                    "rattachees a un espace et ne sont pas comptees.".format(
                        round(orphan_area, 1)))
if errors:
    for e in errors:
        output.print_md("- Espace non calcule : " + e)
output.print_md("- Les parois sont classees via le parametre Fonction des "
                "types de murs (Exterieur / Fondation deperditif).")

output.print_md("---")
output.print_md("_Methode EN 12831 simplifiee a usage pedagogique, "
                "sans valeur reglementaire._")
