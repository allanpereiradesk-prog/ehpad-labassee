# -*- coding: utf-8 -*-
"""Relier deux reseaux en choisissant parmi 3 solutions :
cliquer le 1er element puis le 2e. Un panneau montre la zone en 3D (ou en
coupe) et propose : liaison automatique, trace a angles droits, trace a
45 deg. Chaque solution est verifiee (raccords possibles, aucun element
traverse). Cocher une solution = apercu, puis "Creer cette liaison".
Echap pour arreter."""

__title__ = "Relier\n(3 solutions)"

import os
from pyrevit import revit, DB, forms, script
from Autodesk.Revit.UI import PreviewControl
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from System.Windows import Visibility
from System.Windows.Input import Mouse, Cursors
import allan_clash as ac
import allan_relier as rel
import allan_relier3 as r3

doc = revit.doc
uidoc = revit.uidoc
VERT = (60, 190, 90)


class Filtre(ISelectionFilter):
    def AllowElement(self, el):
        return bool(rel.connectors(el))

    def AllowReference(self, ref, pt):
        return False


class RelierWindow(forms.WPFWindow):
    def __init__(self, xaml, e1, e2, sols, zone, univ):
        self.maj = True
        forms.WPFWindow.__init__(self, xaml)
        self.e1, self.e2, self.sols, self.zone, self.univ = e1, e2, sols, zone, univ
        self.rbs = (self.rb1, self.rb2, self.rb3)
        self.txs = (self.tx1, self.tx2, self.tx3)
        self.pc = None
        self.grp = None
        self.vues = {}
        self.zoom = zone.zoom
        self.box = None
        self.fait = None
        self.maj = False
        self.Loaded += self._charge
        self.Closed += self._ferme

    # ---- outils
    def _attente(self, on):
        try:
            Mouse.OverrideCursor = Cursors.Wait if on else None
        except Exception:
            pass

    def _drop(self):
        try:
            self.host.Children.Clear()
            if self.pc is not None:
                self.pc.Dispose()
        except Exception:
            pass
        self.pc = None

    def _preview(self):
        self._drop()
        vid = self.vues.get("3d" if self.chk_3d.IsChecked else "coupe")
        if vid is None:
            return
        try:
            self.pc = PreviewControl(doc, vid)
            self.host.Children.Add(self.pc)
        except Exception as ex:
            self.info.Text = "Apercu impossible : %s" % ex

    def _annuler_apercu(self):
        if self.grp is not None:
            try:
                self.grp.RollBack()
            except Exception:
                pass
            self.grp = None

    def _choix(self):
        for i, rb in enumerate(self.rbs):
            if rb.IsChecked:
                return i
        return "base" if self.rbB.IsChecked else None

    # ---- affichage
    def _charge(self, s, a):
        z = self.zone
        self.leg_a.Text = "ROUGE = %s (id %s)" % (z.a.nom, ac.eid(z.a.id))
        self.leg_b.Text = "BLEU = %s (id %s)" % (z.b.nom, ac.eid(z.b.id))
        for i, v in enumerate(self.sols):
            self.txs[i].Text = "%s%s\n%s" % (v.titre, "   * RECOMMANDEE" if v.reco else "", v.texte())
            self.rbs[i].IsEnabled = v.ok
        self._montrer()
        for i, v in enumerate(self.sols):      # on montre tout de suite la solution recommandee
            if v.reco:
                self.rbs[i].IsChecked = True

    def _montrer(self, choix=None):
        self._attente(True)
        try:
            self._drop()
            self._annuler_apercu()
            self.maj = True
            for rb in self.rbs:
                rb.IsChecked = False
            self.rbB.IsChecked = True
            self.maj = False
            self.info.Text = "Distance entre les deux bouts : %.2f m" % (self.zone.portee * 0.3048)
            t = ac.tx_debut(doc, "Allan BIM - vues liaison")
            try:
                self.vues = ac.preparer_vues(doc, self.zone, self.zoom, self.box)
                self._sliders(self.vues["box"])
                ac.valider_tx(t)
            except Exception as ex:
                t.RollBack()
                self.vues = {}
                self.info.Text = "Vue impossible : %s" % ex
            self._preview()
        finally:
            self._attente(False)
        if choix in (0, 1, 2) and self.sols[choix].ok:
            self.rbs[choix].IsChecked = True

    def _zoom(self, f):
        self.zoom = min(12.0, max(0.5, self.zoom * f))
        if self.box is not None:
            self.box = tuple(v * f for v in self.box)
        self._montrer(self._choix())

    def on_plus(self, s, a):
        self._zoom(1.5)

    def on_moins(self, s, a):
        self._zoom(1 / 1.5)

    def on_3d(self, s, a):
        self.pan_3d.Visibility = Visibility.Visible if self.chk_3d.IsChecked else Visibility.Collapsed
        self._preview()

    # ---- cube de la vue 3D
    def _sliders(self, box):
        self.maj = True
        try:
            for sl, v in zip((self.sl_x, self.sl_y, self.sl_z), box):
                sl.Value = v * 0.3048
        finally:
            self.maj = False
        self.on_box_txt(None, None)

    def on_box_txt(self, s, a):
        try:
            self.lb_x.Text = "Longueur (le long du reseau) : %.1f m" % (2 * self.sl_x.Value)
            self.lb_y.Text = "Largeur (en travers) : %.1f m" % (2 * self.sl_y.Value)
            self.lb_z.Text = "Hauteur : %.1f m" % (2 * self.sl_z.Value)
        except Exception:
            pass

    def _boite(self):
        if self.box is None or "3d" not in self.vues:
            return
        t = ac.tx_debut(doc, "Allan BIM - cube 3D")
        try:
            ac.boite3d(doc, self.vues["3d"], self.vues["tr3"], self.box)
            t.Commit()
        except Exception:
            t.RollBack()

    def on_box(self, s, a):
        if self.maj:
            return
        self.box = tuple(sl.Value / 0.3048 for sl in (self.sl_x, self.sl_y, self.sl_z))
        self._attente(True)
        try:
            self._drop()
            self._boite()
            self._preview()
        finally:
            self._attente(False)

    # ---- solutions
    def on_variante(self, s, a):
        if self.maj:
            return
        self._attente(True)
        try:
            self._drop()
            self._annuler_apercu()
            k = self._choix()
            if k in (0, 1, 2) and self.sols[k].ok:
                self.grp = DB.TransactionGroup(doc, "Allan BIM - relier")
                self.grp.Start()
                t = ac.tx_debut(doc, "Allan BIM - relier")
                try:
                    e1, e2, c1, c2 = r3.bouts(self.e1, self.e2)
                    ids = r3.executer(doc, e1, e2, c1, c2, self.sols[k])
                    if "coupe" in self.vues:
                        ac.colorer(doc, [self.vues["coupe"], self.vues["3d"]], ids, VERT)
                    ac.valider_tx(t)
                except Exception as ex:
                    try:
                        t.RollBack()
                    except Exception:
                        pass
                    self._annuler_apercu()
                    self.maj = True
                    self.rbs[k].IsChecked = False
                    self.rbB.IsChecked = True
                    self.maj = False
                    forms.alert("Cette solution ne peut pas etre creee :\n%s" % ex, title="Relier")
            self._boite()
            self._preview()
        finally:
            self._attente(False)

    def on_valider(self, s, a):
        k = self._choix()
        if k not in (0, 1, 2) or self.grp is None:
            forms.alert("Coche une des 3 variantes.", title="Relier")
            return
        self._drop()
        self.grp.Assimilate()
        self.grp = None
        self.fait = self.sols[k].titre
        self.Close()

    def on_fermer(self, s, a):
        self.Close()

    def _ferme(self, s, a):
        self._drop()
        self._annuler_apercu()
        t = ac.tx_debut(doc, "Allan BIM - nettoyage vues")
        try:
            ac.supprimer_vues(doc)
            t.Commit()
        except Exception:
            t.RollBack()
        self._attente(False)


if ac.nom(doc.ActiveView) in (ac.VUE_COUPE, ac.VUE_3D):
    forms.alert("Ferme d'abord la vue '%s' (elle sera recreee par l'outil)." % ac.nom(doc.ActiveView),
                title="Relier", exitscript=True)

t0 = DB.Transaction(doc, "Raccords manquants")
t0.Start()
try:
    info_raccords = rel.ensure_fittings(doc)
    t0.Commit()
except Exception as ex:
    t0.RollBack()
    info_raccords = "Raccords par defaut non verifies :\n%s" % ex
if info_raccords:
    forms.alert(info_raccords, title="Relier")

xaml = os.path.join(os.path.dirname(__file__), "ui.xaml")
faits = []
while True:
    try:
        r1 = uidoc.Selection.PickObject(ObjectType.Element, Filtre(),
                                        "Relier (3 solutions) : cliquer le 1er reseau (Echap pour terminer)")
        r2 = uidoc.Selection.PickObject(ObjectType.Element, Filtre(), "Relier (3 solutions) : cliquer le 2e reseau")
    except Exception:
        break
    e1, e2 = doc.GetElement(r1.ElementId), doc.GetElement(r2.ElementId)
    if e1.Id == e2.Id:
        continue
    try:
        zone = r3.Zone(e1, e2)
        univ = ac.univers(doc)
        sols = r3.solutions(doc, e1, e2, univ)
    except Exception as ex:
        forms.alert("Impossible de relier ces deux elements :\n%s" % ex, title="Relier")
        continue
    if not [s for s in sols if s.ok]:
        forms.alert("Aucune des 3 solutions n'est possible :\n\n" +
                    "\n".join("- %s\n  %s" % (s.titre, s.raison) for s in sols), title="Relier")
        continue
    w = RelierWindow(xaml, e1, e2, sols, zone, univ)
    w.ShowDialog()
    if w.fait:
        faits.append(w.fait)

if faits:
    forms.alert("%d liaison(s) creee(s) :\n" % len(faits) + "\n".join("- " + f for f in faits), title="Relier")
