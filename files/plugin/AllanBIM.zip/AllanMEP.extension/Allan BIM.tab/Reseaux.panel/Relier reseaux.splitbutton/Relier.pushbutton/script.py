# -*- coding: utf-8 -*-
"""Raccorde deux reseaux : cliquer sur le 1er element (gaine, tuyau ou
equipement), puis sur le 2e. L'outil choisit tout seul : troncon droit,
coude, te/piquage, ou troncon de liaison avec 2 coudes.
Echap pour arreter."""

from pyrevit import revit, DB, forms, script
from Autodesk.Revit.UI.Selection import ObjectType
import allan_relier as rel

doc = revit.doc
uidoc = revit.uidoc

faits, erreurs = [], []
t0 = DB.Transaction(doc, "Raccords manquants")
t0.Start()
try:
    info_raccords = rel.ensure_fittings(doc)
    t0.Commit()
except Exception as ex:
    t0.RollBack()
    info_raccords = "Raccords par defaut non verifies :\n%s" % ex
if info_raccords:
    forms.alert(info_raccords, title="Relier")
while True:
    try:
        r1 = uidoc.Selection.PickObject(ObjectType.Element, "Relier : cliquer le 1er element (Echap pour terminer)")
        r2 = uidoc.Selection.PickObject(ObjectType.Element, "Relier : cliquer le 2e element")
    except Exception:
        break
    e1, e2 = doc.GetElement(r1.ElementId), doc.GetElement(r2.ElementId)
    if e1.Id == e2.Id:
        continue
    t = DB.Transaction(doc, "Relier deux reseaux")
    t.Start()
    try:
        msg = rel.relier(doc, e1, e2)
        t.Commit()
        faits.append(msg)
    except Exception as ex:
        t.RollBack()
        txt = str(ex)
        if "routing" in txt.lower() or "fitting" in txt.lower() or "raccord" in txt.lower():
            txt += ("\n-> Verifie les preferences de routage du type de gaine/tuyau "
                    "(coude, te, reduction doivent etre definis).")
        erreurs.append(txt)
        forms.alert("Impossible de relier ces deux elements :\n" + txt, title="Relier")

if faits or erreurs:
    lignes = ["%d liaison(s) faite(s)" % len(faits)] + ["- " + m for m in faits[:10]]
    if erreurs:
        lignes.append("%d echec(s)" % len(erreurs))
    forms.alert("\n".join(lignes), title="Relier")
