# -*- coding: utf-8 -*-
"""Couleurs reseaux : un filtre de vue par type de systeme (tuyaux, gaines,
raccords, accessoires, isolants, bouches...) avec une couleur, applique aux
vues ou gabarits choisis. Marche en plan, coupe, elevation et 3D."""

__title__ = "Couleurs\nréseaux"

import os
import clr
clr.AddReference("System.Windows.Forms")
from pyrevit import revit, DB, forms
from System.Windows import Thickness
from System.Windows.Controls import CheckBox, Button, StackPanel, Orientation, TextBlock
from System.Windows.Media import SolidColorBrush, Color
from System.Windows.Input import Mouse, Cursors
import System.Windows.Forms as WF
import allan_reseaux_outils as ro

doc = revit.doc


def brush(c):
    return SolidColorBrush(Color.FromRgb(c[0], c[1], c[2]))


class Fenetre(forms.WPFWindow):
    def __init__(self, xaml):
        forms.WPFWindow.__init__(self, xaml)
        self.systemes = ro.lister_systemes(doc)
        self.coches_sys = {}
        self.vues = ro.vues_possibles(doc)
        self.coches_vues = []
        self._remplir_sys()
        self._remplir_vues()

    def log(self, lignes):
        if isinstance(lignes, basestring):
            lignes = [lignes]
        self.journal.Text = (u"\n".join(l for l in lignes if l) + u"\n" + self.journal.Text).strip()

    # ---------------------------------------------------- systemes
    def _remplir_sys(self):
        self.sp_sys.Children.Clear()
        seul = bool(self.o_utilises.IsChecked)
        cat_prec = None
        for s in self.systemes:
            if seul and s.nb == 0:
                continue
            if s.cat != cat_prec:
                t = TextBlock()
                t.Text = s.cat
                t.FontWeight = System_Bold()
                t.Margin = Thickness(0, 6 if cat_prec else 0, 0, 2)
                self.sp_sys.Children.Add(t)
                cat_prec = s.cat
            ligne = StackPanel()
            ligne.Orientation = Orientation.Horizontal
            b = Button()
            b.Width = 34
            b.Height = 20
            b.Margin = Thickness(0, 2, 8, 2)
            b.Background = brush(s.couleur)
            b.Tag = s
            b.ToolTip = u"Changer la couleur"
            b.Click += self.on_couleur
            cb = CheckBox()
            cb.Content = u"%s   (%d)" % (s.nom, s.nb)
            prec = self.coches_sys.get(s.nom)
            cb.IsChecked = prec.IsChecked if prec is not None else (s.nb > 0)
            cb.VerticalAlignment = System_Center()
            self.coches_sys[s.nom] = cb
            ligne.Children.Add(b)
            ligne.Children.Add(cb)
            self.sp_sys.Children.Add(ligne)

    def on_filtre_sys(self, s, a):
        self._remplir_sys()

    def on_couleur(self, s, a):
        sy = s.Tag
        dlg = WF.ColorDialog()
        dlg.FullOpen = True
        dlg.Color = System_DrawingColor(sy.couleur)
        if dlg.ShowDialog() == WF.DialogResult.OK:
            sy.couleur = (dlg.Color.R, dlg.Color.G, dlg.Color.B)
            s.Background = brush(sy.couleur)

    # ---------------------------------------------------- vues
    def _remplir_vues(self):
        self.sp_vues.Children.Clear()
        self.coches_vues = []
        actif = doc.ActiveView.Id
        for lib, v in self.vues:
            cb = CheckBox()
            cb.Content = lib
            cb.Tag = v
            cb.IsChecked = (v.Id == actif)
            self.sp_vues.Children.Add(cb)
            self.coches_vues.append(cb)

    def on_cherche(self, s, a):
        t = (self.t_cherche.Text or u"").lower()
        from System.Windows import Visibility
        for cb in self.coches_vues:
            cb.Visibility = Visibility.Visible if t in unicode(cb.Content).lower() else Visibility.Collapsed

    def on_toutes(self, s, a):
        from System.Windows import Visibility
        for cb in self.coches_vues:
            if cb.Visibility == Visibility.Visible:
                cb.IsChecked = True

    def on_aucune(self, s, a):
        for cb in self.coches_vues:
            cb.IsChecked = False

    def _vues_cochees(self):
        return [cb.Tag for cb in self.coches_vues if cb.IsChecked]

    # ---------------------------------------------------- actions
    def on_appliquer(self, s, a):
        sys_ = [sy for sy in self.systemes if self.coches_sys.get(sy.nom) is not None and self.coches_sys[sy.nom].IsChecked]
        vues = self._vues_cochees()
        if not sys_ or not vues:
            self.log(u"Coche au moins un système et une vue.")
            return
        log = []
        Mouse.OverrideCursor = Cursors.Wait
        try:
            ro.appliquer_couleurs(doc, sys_, vues, bool(self.o_remplir.IsChecked), log, bool(self.o_prio.IsChecked))
        finally:
            Mouse.OverrideCursor = None
        self.log(log)

    def on_retirer(self, s, a):
        vues = self._vues_cochees()
        if not vues and not self.o_suppr.IsChecked:
            self.log(u"Coche les vues d'où retirer les couleurs.")
            return
        log = []
        ro.retirer_couleurs(doc, vues, bool(self.o_suppr.IsChecked), log)
        self.log(log)


def System_Bold():
    from System.Windows import FontWeights
    return FontWeights.Bold


def System_Center():
    from System.Windows import VerticalAlignment
    return VerticalAlignment.Center


def System_DrawingColor(c):
    clr.AddReference("System.Drawing")
    from System.Drawing import Color as DC
    return DC.FromArgb(c[0], c[1], c[2])


Fenetre(os.path.join(os.path.dirname(__file__), "ui.xaml")).show_dialog()
