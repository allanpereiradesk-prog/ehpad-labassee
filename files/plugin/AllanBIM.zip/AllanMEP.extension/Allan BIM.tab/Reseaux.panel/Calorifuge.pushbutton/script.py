# -*- coding: utf-8 -*-
"""Calorifuge auto : isole les canalisations et les gaines selon des regles
(systeme + plage de taille -> type d'isolant + epaisseur), raccords et
accessoires compris. On analyse d'abord, puis on applique."""

__title__ = "Calorifuge\nauto"

import os
from pyrevit import revit, DB, forms
from System.Windows.Controls import ListBoxItem
from System.Windows.Media import SolidColorBrush, Color
from System.Windows.Input import Mouse, Cursors
import allan_reseaux_outils as ro

doc = revit.doc
uidoc = revit.uidoc
def _dossier_extension(p):
    """Remonte jusqu'au dossier .extension (marche meme si le bouton
    est range dans un menu deroulant)."""
    while not p.lower().endswith(".extension") and os.path.dirname(p) != p:
        p = os.path.dirname(p)
    return p


ext_dir = _dossier_extension(os.path.abspath(__file__))


def num(t, d=0.0):
    try:
        return float(unicode(t).replace(u",", u".").strip())
    except Exception:
        return d


def brush(r, g, b):
    return SolidColorBrush(Color.FromRgb(r, g, b))


class Fenetre(forms.WPFWindow):
    def __init__(self, xaml):
        self.pret = False
        forms.WPFWindow.__init__(self, xaml)
        self.regles = ro.charger_regles(ext_dir, doc)
        self.actions = []
        self.r_cat.ItemsSource = [ro.CANA, ro.GAINE]
        self.r_cat.SelectedIndex = 0
        self._listes_cat()
        self._maj_types_bouton()
        self.pret = True
        self._liste()
        self.Closed += lambda s, a: ro.sauver_regles(ext_dir, self.regles)

    def log(self, lignes):
        if isinstance(lignes, basestring):
            lignes = [lignes]
        self.journal.Text = (u"\n".join(l for l in lignes if l) + u"\n" + self.journal.Text).strip()

    # ---------------------------------------------------- regles
    def _listes_cat(self):
        cat = self.r_cat.SelectedItem or ro.CANA
        self.r_sys.ItemsSource = ro.choix_systemes(doc, cat)
        self.r_sys.SelectedIndex = 0
        types = ro.types_isolant(doc, cat)
        self.r_type.ItemsSource = types
        self.r_type.SelectedIndex = 0 if types else -1

    def _maj_types_bouton(self):
        manque = not ro.types_isolant(doc, ro.CANA) or not ro.types_isolant(doc, ro.GAINE)
        self.b_types.IsEnabled = manque
        if manque:
            self.log(u"Le projet n'a pas (tous) les types d'isolant : bouton « Importer les types d'isolant » pour les récupérer.")

    def on_cat(self, s, a):
        if self.pret:
            self._listes_cat()

    def _texte(self, i, r):
        dmax = u"∞" if num(r.get("dmax"), 0) >= 9999 else u"%g" % num(r.get("dmax"))
        return u"%d.  %s - %s\n      %g à %s mm  →  %s, %g mm" % (
            i + 1, r.get("cat"), r.get("sys"), num(r.get("dmin")), dmax, r.get("type") or u"(aucun type)", num(r.get("ep")))

    def _liste(self, sel=None):
        self.lst.ItemsSource = [self._texte(i, r) for i, r in enumerate(self.regles)]
        if sel is not None and 0 <= sel < len(self.regles):
            self.lst.SelectedIndex = sel

    def on_sel(self, s, a):
        i = self.lst.SelectedIndex
        if not (0 <= i < len(self.regles)):
            return
        r = self.regles[i]
        self.pret = False
        self.r_cat.SelectedItem = r.get("cat")
        self._listes_cat()
        if r.get("sys") not in list(self.r_sys.ItemsSource):
            self.r_sys.ItemsSource = list(self.r_sys.ItemsSource) + [r.get("sys")]
        self.r_sys.SelectedItem = r.get("sys")
        self.r_dmin.Text = u"%g" % num(r.get("dmin"))
        self.r_dmax.Text = u"%g" % num(r.get("dmax"))
        if r.get("type") in list(self.r_type.ItemsSource or []):
            self.r_type.SelectedItem = r.get("type")
        self.r_ep.Text = u"%g" % num(r.get("ep"))
        self.pret = True

    def _regle(self):
        return {"cat": self.r_cat.SelectedItem, "sys": self.r_sys.SelectedItem or ro.TOUS,
                "dmin": num(self.r_dmin.Text, 0), "dmax": num(self.r_dmax.Text, 9999),
                "type": self.r_type.SelectedItem or u"", "ep": num(self.r_ep.Text, 25)}

    def on_add(self, s, a):
        self.regles.append(self._regle())
        self._liste(len(self.regles) - 1)
        self._invalider()

    def on_mod(self, s, a):
        i = self.lst.SelectedIndex
        if 0 <= i < len(self.regles):
            self.regles[i] = self._regle()
            self._liste(i)
            self._invalider()

    def on_del(self, s, a):
        i = self.lst.SelectedIndex
        if 0 <= i < len(self.regles):
            del self.regles[i]
            self._liste(min(i, len(self.regles) - 1))
            self._invalider()

    def _bouger(self, d):
        i = self.lst.SelectedIndex
        j = i + d
        if 0 <= i < len(self.regles) and 0 <= j < len(self.regles):
            self.regles[i], self.regles[j] = self.regles[j], self.regles[i]
            self._liste(j)
            self._invalider()

    def on_up(self, s, a):
        self._bouger(-1)

    def on_down(self, s, a):
        self._bouger(1)

    def on_defaut(self, s, a):
        if forms.alert(u"Remplacer les règles par les règles d'exemple ?", yes=True, no=True):
            self.regles = ro.regles_defaut(doc)
            self._liste()
            self._invalider()

    def on_types(self, s, a):
        log = []
        ro.importer_types_isolant(doc, log)
        self.log(log)
        self._listes_cat()
        self._maj_types_bouton()
        if not any(r.get("type") for r in self.regles):
            self.regles = ro.regles_defaut(doc)
            self._liste()

    # ---------------------------------------------------- analyse
    def _invalider(self):
        self.actions = []
        self.b_appliquer.IsEnabled = False

    def _portee(self):
        return "vue" if self.p_vue.IsChecked else ("selection" if self.p_sel.IsChecked else "projet")

    def on_analyser(self, s, a):
        Mouse.OverrideCursor = Cursors.Wait
        try:
            self.actions = ro.analyser(doc, self.regles, self._portee(), uidoc,
                                       bool(self.o_racc.IsChecked), bool(self.o_acc.IsChecked),
                                       bool(self.o_maj.IsChecked), bool(self.o_sup.IsChecked))
        except Exception as ex:
            self.actions = []
            self.log(u"Erreur d'analyse : %s" % ex)
        finally:
            Mouse.OverrideCursor = None
        cpt = {}
        for x in self.actions:
            cpt[x.quoi] = cpt.get(x.quoi, 0) + 1
        self.resume.Text = (u"%d élément(s) : %d à isoler, %d à modifier, %d à désisoler, %d déjà OK, %d sans règle"
                            % (len(self.actions), cpt.get("ajouter", 0), cpt.get("modifier", 0), cpt.get("supprimer", 0),
                               cpt.get("ok", 0), cpt.get("sans", 0)))
        coul = {"ajouter": brush(110, 220, 120), "modifier": brush(255, 190, 80), "supprimer": brush(255, 110, 110),
                "ok": brush(150, 150, 150), "sans": brush(110, 110, 110)}
        lib = {"ajouter": u"+ isoler", "modifier": u"~ modifier", "supprimer": u"- désisoler", "ok": u"= déjà OK",
               "sans": u"  sans règle"}
        items = []
        ordre = {"ajouter": 0, "modifier": 1, "supprimer": 2, "ok": 3, "sans": 4}
        for x in sorted(self.actions, key=lambda x: (ordre.get(x.quoi, 9), x.info)):
            it = ListBoxItem()
            cat = x.el.Category.Name if x.el.Category else u""
            det = (u"  →  %s, %g mm" % (ro.nom(x.type_nom), x.ep / ro.MM)) if x.type_nom is not None and x.ep else u""
            it.Content = u"%-12s %s : %s%s" % (lib.get(x.quoi, x.quoi), cat, x.info, det)
            it.Foreground = coul.get(x.quoi, brush(200, 200, 200))
            items.append(it)
        self.lst_res.ItemsSource = items
        self.b_appliquer.IsEnabled = any(x.quoi in ("ajouter", "modifier", "supprimer") for x in self.actions)

    def on_appliquer(self, s, a):
        a_faire = [x for x in self.actions if x.quoi in ("ajouter", "modifier", "supprimer")]
        if not a_faire:
            return
        log = []
        Mouse.OverrideCursor = Cursors.Wait
        try:
            ro.appliquer(doc, a_faire, log)
        finally:
            Mouse.OverrideCursor = None
        ro.sauver_regles(ext_dir, self.regles)
        self.log(log)
        self.on_analyser(None, None)


Fenetre(os.path.join(os.path.dirname(__file__), "ui.xaml")).show_dialog()
