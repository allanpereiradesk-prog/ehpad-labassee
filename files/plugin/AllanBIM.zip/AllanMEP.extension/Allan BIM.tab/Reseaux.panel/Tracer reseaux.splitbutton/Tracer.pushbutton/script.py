# -*- coding: utf-8 -*-
"""Tracer un reseau directement dans la vue (coupe ou plan) :
1. cliquer la 1re gaine / canalisation (pres du bout a prolonger)
2. cliquer la 2e gaine / canalisation / equipement (Echap = bout libre)
3. cliquer autant de points de passage que tu veux (apercu rouge),
   puis Echap : le reseau est modelise avec les coudes et raccorde.
Les traits presque horizontaux / verticaux sont redresses."""

__title__ = "Tracer\n(dans la vue)"

from pyrevit import revit, DB, forms, script
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from Autodesk.Revit.Exceptions import OperationCanceledException
import allan_trace as tr

doc = revit.doc
uidoc = revit.uidoc
view = doc.ActiveView

if view.ViewType not in (DB.ViewType.FloorPlan, DB.ViewType.CeilingPlan, DB.ViewType.Section,
                         DB.ViewType.Elevation, DB.ViewType.EngineeringPlan, DB.ViewType.Detail):
    forms.alert("Ouvre une vue en plan ou une coupe pour tracer.", exitscript=True)


class FiltreReseau(ISelectionFilter):
    def __init__(self, equip=False):
        self.equip = equip

    def AllowElement(self, el):
        if isinstance(el, (DB.Plumbing.Pipe, DB.Mechanical.Duct)):
            return True
        if self.equip:
            try:
                return el.MEPModel is not None and el.MEPModel.ConnectorManager is not None
            except Exception:
                return False
        return False

    def AllowReference(self, ref, pt):
        return False


# 1) depart
try:
    r1 = uidoc.Selection.PickObject(ObjectType.Element, FiltreReseau(),
                                    "1/3 - Cliquer la 1re gaine / canalisation, pres du bout a prolonger")
except OperationCanceledException:
    script.exit()
e1, pick1 = doc.GetElement(r1.ElementId), r1.GlobalPoint
c0 = tr.end_connector_near(e1, pick1)
origin = c0.Origin

# 2) arrivee
e2, pick2 = None, None
try:
    r2 = uidoc.Selection.PickObject(ObjectType.Element, FiltreReseau(True),
                                    "2/3 - Cliquer la 2e gaine / canalisation ou l'equipement (Echap = bout libre)")
    e2, pick2 = doc.GetElement(r2.ElementId), r2.GlobalPoint
except OperationCanceledException:
    pass

# plan de dessin + raccords
t = DB.Transaction(doc, "Tracer - preparation"); t.Start()
try:
    info = tr.rel.ensure_fittings(doc)
    tr.set_work_plane(doc, view, origin)
    t.Commit()
except Exception as ex:
    t.RollBack()
    forms.alert("Preparation impossible dans cette vue :\n%s" % ex, title="Tracer", exitscript=True)

# 3) points de passage
u, v, n = tr.view_axes(view)
points, apercu = [], []
prev = origin
while True:
    try:
        p = uidoc.Selection.PickPoint("3/3 - Point de passage n%d (Echap = terminer et modeliser)" % (len(points) + 1))
    except OperationCanceledException:
        break
    except Exception as ex:
        forms.alert("Impossible de cliquer un point dans cette vue :\n%s" % ex, title="Tracer")
        break
    p = tr.to_plane(p, origin, n)
    p = tr.ortho_snap(prev, p, u, v)
    points.append(p)
    t = DB.Transaction(doc, "Tracer - apercu"); t.Start()
    try:
        dl = doc.Create.NewDetailCurve(view, DB.Line.CreateBound(prev, p))
        gs = DB.OverrideGraphicSettings()
        gs.SetProjectionLineColor(DB.Color(230, 30, 30))
        gs.SetProjectionLineWeight(6)
        view.SetElementOverrides(dl.Id, gs)
        apercu.append(dl.Id)
        t.Commit()
    except Exception:
        t.RollBack()
    prev = p

# 4) modelisation
t = DB.Transaction(doc, "Tracer un reseau"); t.Start()
for i in apercu:
    try:
        doc.Delete(i)
    except Exception:
        pass
if not points and e2 is None:
    t.Commit()
    script.exit()
try:
    nseg, ncoudes, msg = tr.build_route(doc, e1, pick1, points, e2, pick2)
    t.Commit()
    forms.alert("%d troncon(s), %d coude(s)\n%s%s" % (nseg, ncoudes, msg,
                ("\n\n" + info) if info else ""), title="Tracer")
except Exception as ex:
    t.RollBack()
    t2 = DB.Transaction(doc, "Tracer - nettoyage"); t2.Start()
    for i in apercu:
        try:
            doc.Delete(i)
        except Exception:
            pass
    t2.Commit()
    forms.alert("Trace impossible :\n%s" % ex, title="Tracer")
