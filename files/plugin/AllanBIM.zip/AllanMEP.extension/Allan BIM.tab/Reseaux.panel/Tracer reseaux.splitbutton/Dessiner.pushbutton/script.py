# -*- coding: utf-8 -*-
"""Dessiner des traces dans une fenetre, entre plusieurs reseaux :
1. selectionner les gaines / canalisations / equipements concernes
   (Terminer / Annuler dans la barre d'options de Revit)
2. mode Dessiner ON : cliquer un reseau pour commencer, cliquer les points,
   finir en cliquant un autre reseau (bout = raccord / milieu = te)
3. mode Dessiner OFF : cliquer un trait pour modifier longueur / angle /
   chute, ou glisser un point
4. Modeliser : tous les traces sont crees avec coudes et raccords."""

__title__ = "Dessiner\n(fenetre)"

import os
from pyrevit import revit, DB, forms, script
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from Autodesk.Revit.Exceptions import OperationCanceledException
import allan_dessin as ad

doc = revit.doc
uidoc = revit.uidoc


class Filtre(ISelectionFilter):
    def AllowElement(self, el):
        return ad.mep_ok(el)

    def AllowReference(self, ref, pt):
        return False


sel = [doc.GetElement(i) for i in uidoc.Selection.GetElementIds()]
sel = [e for e in sel if e is not None and ad.mep_ok(e)]
if not sel:
    try:
        refs = uidoc.Selection.PickObjects(
            ObjectType.Element, Filtre(),
            u"Selectionner les reseaux a relier puis cliquer TERMINER (ou Annuler)")
        sel = [doc.GetElement(r.ElementId) for r in refs]
    except OperationCanceledException:
        script.exit()
if not sel:
    script.exit()

try:
    ctx = ad.Ctx(doc.ActiveView, sel)
except Exception as ex:
    forms.alert(str(ex), exitscript=True)

w = ad.DessinWindow(os.path.join(os.path.dirname(__file__), "ui.xaml"), ctx)
w.ShowDialog()
if not w.ok or not w.traces:
    script.exit()

t = DB.Transaction(doc, "Dessiner des reseaux"); t.Start()
try:
    info = ad.rel.ensure_fittings(doc)
    res, err = ad.modeliser(doc, ctx, w.traces)
    t.Commit()
except Exception as ex:
    t.RollBack()
    forms.alert("Modelisation annulee, rien n'a ete modifie :\n%s" % ex, title="Dessiner", exitscript=True)
lignes = res + ([""] + err if err else []) + (["", info] if info else [])
forms.alert("\n".join(lignes) or "Rien a modeliser.", title="Dessiner")
