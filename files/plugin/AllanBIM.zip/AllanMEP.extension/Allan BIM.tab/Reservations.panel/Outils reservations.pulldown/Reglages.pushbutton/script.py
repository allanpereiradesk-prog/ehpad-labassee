# -*- coding: utf-8 -*-
"""Reglages des reservations : jeu, arrondi et NGF.

Jeu / arrondi : enregistres pour l'utilisateur (pyRevit).
NGF :
Si le projet n'a pas son altitude NGF (point de topographie a 0),
on saisit ici le NGF d'un niveau (ex : RDC = 150,00 m NGF).
Le reglage est enregistre dans le projet (Informations sur le projet)."""

__title__ = "Reglages"

from pyrevit import revit, DB, forms, script
import allan_reservation_auto as auto

doc = revit.doc
FT = 0.3048

menu = forms.CommandSwitchWindow.show(
    ["Jeu et arrondi des reservations", "NGF du projet", "Renumeroter les reservations (1, 2, 3...)"],
    message="Quel reglage ?")
if not menu:
    script.exit()

if menu.startswith("Renumeroter"):
    if forms.alert(u"Renumeroter toutes les reservations du projet 1, 2, 3...\n"
                   u"(ordre : niveau, puis position en plan) ?", yes=True, no=True):
        with revit.Transaction("Renumeroter reservations"):
            n = auto.renumeroter(doc)
        forms.alert(u"%d reservation(s) renumerotee(s) de 1 a %d." % (n, n), title="Reglages")
    script.exit()

if menu == "Jeu et arrondi des reservations":
    r = auto.get_reglages()
    champs = [
        ("jeu_gaine_mm", "Jeu de chaque cote pour les GAINES (mm)"),
        ("jeu_canal_mm", "Jeu de chaque cote pour les CANALISATIONS (mm)"),
        ("pas_rect_mm", "Arrondi des reservations RECTANGULAIRES (mm)"),
        ("pas_circ_mm", "Arrondi des reservations CIRCULAIRES (mm)"),
    ]
    new = {}
    for k, prompt in champs:
        txt = forms.ask_for_string(default="%g" % r[k], prompt=prompt, title="Reglages reservations")
        if txt is None:
            script.exit()
        try:
            new[k] = float(str(txt).replace(",", "."))
        except Exception:
            new[k] = r[k]
    auto.save_reglages(new)
    forms.alert(u"Enregistre.\nExemple gaine 200x200 -> %s\n"
                u"(s'applique aux prochaines reservations posees)" % (
                    "%dx%d" % tuple([__import__("math").ceil((200 + 2 * new["jeu_gaine_mm"]) / new["pas_rect_mm"]) * new["pas_rect_mm"]] * 2)),
                title="Reglages reservations")
    script.exit()

reg = auto.get_ngf_setting(doc)
if reg:
    actuel = "%s = %.2f m NGF" % (reg[0], reg[1] * FT)
else:
    topo = auto._ngf_offset(doc) * FT
    actuel = "point topo (%.2f m NGF)" % topo

choix = forms.CommandSwitchWindow.show(
    ["Saisir le NGF d'un niveau",
     "Utiliser le point de topographie du projet",
     "Voir le reglage actuel"],
    message="Actuel : " + actuel)
if not choix:
    script.exit()

if choix == "Voir le reglage actuel":
    forms.alert(actuel, title="Reglage NGF")
    script.exit()

if choix == "Saisir le NGF d'un niveau":
    levels = sorted(DB.FilteredElementCollector(doc).OfClass(DB.Level),
                    key=lambda l: l.ProjectElevation)
    noms = ["%s  (%+.2f m)" % (l.Name, l.ProjectElevation * FT) for l in levels]
    defaut = [n for n, l in zip(noms, levels) if abs(l.ProjectElevation) < 1e-6]
    pick = forms.SelectFromList.show(noms, title="Niveau de reference du NGF",
                                     button_name="Choisir", multiselect=False)
    if not pick:
        script.exit()
    lvl = levels[noms.index(pick)]
    txt = forms.ask_for_string(
        default=("%.2f" % (reg[1] * FT)) if reg else "150.00",
        prompt="Altitude NGF de %s (en metres)" % lvl.Name, title="Reglage NGF")
    if txt is None:
        script.exit()
    try:
        ngf_m = float(str(txt).replace(",", ".").replace("m", "").strip())
    except Exception:
        forms.alert("Valeur non valide : " + str(txt), exitscript=True)
    with revit.Transaction("Reglage NGF reservations"):
        auto.set_ngf_setting(doc, lvl.Name, ngf_m / FT)
        n = auto.update_all(doc)
    forms.alert("%s = %.2f m NGF\n%d reservation(s) recalculee(s)." % (lvl.Name, ngf_m, n),
                title="Reglage NGF")
else:
    with revit.Transaction("Reglage NGF reservations"):
        if doc.ProjectInformation.LookupParameter("RES_NGF_Niveau_Ref"):
            auto.set_ngf_setting(doc, None, 0.0)
        n = auto.update_all(doc)
    forms.alert("NGF = point de topographie du projet.\n%d reservation(s) recalculee(s)." % n,
                title="Reglage NGF")
