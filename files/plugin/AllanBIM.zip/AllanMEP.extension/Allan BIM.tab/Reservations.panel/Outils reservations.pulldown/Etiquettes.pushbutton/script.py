# -*- coding: utf-8 -*-
"""Charge (ou recharge) les 2 familles d'etiquette de reservation
(horizontale / verticale) depuis le dossier Familles de l'extension."""

__title__ = "Familles\netiquette"

import os
from pyrevit import revit, forms
import allan_reservation_auto as auto

doc = revit.doc
def _dossier_extension(p):
    """Remonte jusqu'au dossier .extension (marche meme si le bouton
    est range dans un menu deroulant)."""
    while not p.lower().endswith(".extension") and os.path.dirname(p) != p:
        p = os.path.dirname(p)
    return p


ext_dir = _dossier_extension(os.path.abspath(__file__))
fam_dir = os.path.join(ext_dir, "Familles")

with revit.Transaction("Charger etiquettes reservation"):
    syms = auto.ensure_tags(doc, fam_dir)

noms = {"H": "RES_Etiquette_Horizontale", "V": "RES_Etiquette_Verticale"}
lignes = [noms[k] + (" : chargee" if k in syms else " : INTROUVABLE") for k in ("H", "V")]
lignes += ["", "Dossier : " + fam_dir]
forms.alert("\n".join(lignes), title="Familles d'etiquette")
