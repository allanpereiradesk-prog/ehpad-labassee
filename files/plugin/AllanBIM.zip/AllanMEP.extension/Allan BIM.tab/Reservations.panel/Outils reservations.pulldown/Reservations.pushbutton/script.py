# -*- coding: utf-8 -*-
"""Genere et charge les 4 familles de reservation
(horizontale / verticale, circulaire / rectangulaire).

Les .rfa et le fichier de parametres partages sont enregistres dans
le dossier Familles de l'extension AllanMEP."""

__title__ = "Familles\nreservation"

import os
from pyrevit import revit, forms, script
import allan_reservations as ar

def _dossier_extension(p):
    """Remonte jusqu'au dossier .extension (marche meme si le bouton
    est range dans un menu deroulant)."""
    while not p.lower().endswith(".extension") and os.path.dirname(p) != p:
        p = os.path.dirname(p)
    return p


ext_dir = _dossier_extension(os.path.abspath(__file__))
out_dir = os.path.join(ext_dir, "Familles")

if not forms.alert(u"Generer / mettre a jour les 4 familles de reservation "
                   u"et les charger dans le projet ?", yes=True, no=True):
    script.exit()

with revit.Transaction("Charger familles reservation"):
    res = ar.build_all(revit.doc, out_dir, load=True)
    import allan_reservation_auto as auto
    auto.apply_pas(auto.ensure_families(revit.doc, out_dir))

lignes = [n + (" : chargee" if ok else " : deja a jour") for n, p, ok in res]
lignes.append("")
lignes.append("Dossier : " + out_dir)
forms.alert("\n".join(lignes), title="Familles de reservation")
