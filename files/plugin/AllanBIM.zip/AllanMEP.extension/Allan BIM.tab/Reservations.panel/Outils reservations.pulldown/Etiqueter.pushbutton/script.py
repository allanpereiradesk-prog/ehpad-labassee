# -*- coding: utf-8 -*-
"""Met a jour les infos des reservations (dimensions, AI, NGF, niveau)
et pose l'etiquette horizontale ou verticale sur toutes les reservations
de la vue active qui n'en ont pas encore."""

__title__ = "Etiqueter\nreservations"

import os
from pyrevit import revit, forms, script
import allan_reservation_auto as auto

doc = revit.doc
view = doc.ActiveView
def _dossier_extension(p):
    """Remonte jusqu'au dossier .extension (marche meme si le bouton
    est range dans un menu deroulant)."""
    while not p.lower().endswith(".extension") and os.path.dirname(p) != p:
        p = os.path.dirname(p)
    return p


ext_dir = _dossier_extension(os.path.abspath(__file__))
fam_dir = os.path.join(ext_dir, "Familles")

with revit.Transaction("Etiqueter reservations"):
    syms = auto.ensure_tags(doc, fam_dir)
    if not syms:
        forms.alert("Familles d'etiquette introuvables dans :\n" + fam_dir, exitscript=True)
    nb, nt = auto.tag_view(doc, view, syms)

forms.alert("%d reservation(s) mise(s) a jour dans la vue\n%d etiquette(s) ajoutee(s)" % (nb, nt),
            title="Etiqueter reservations")
