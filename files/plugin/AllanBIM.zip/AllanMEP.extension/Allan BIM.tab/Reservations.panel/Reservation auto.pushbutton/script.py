# -*- coding: utf-8 -*-
"""Clique sur une canalisation ou une gaine : une reservation est posee
a chaque mur ou dalle traverse, avec la taille du reseau, l'isolant,
l'epaisseur de la paroi, le reseau, le lot et un repere automatique.
Chaque reservation est etiquetee dans la vue active.
Marche en plan, en coupe et en 3D. Echap pour arreter."""

__title__ = "Reservation\nauto"

import os
from pyrevit import revit, DB, forms, script
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
import allan_reservation_auto as auto

doc = revit.doc
uidoc = revit.uidoc

def _dossier_extension(p):
    """Remonte jusqu'au dossier .extension (marche meme si le bouton
    est range dans un menu deroulant)."""
    while not p.lower().endswith(".extension") and os.path.dirname(p) != p:
        p = os.path.dirname(p)
    return p


ext_dir = _dossier_extension(os.path.abspath(__file__))
fam_dir = os.path.join(ext_dir, "Familles")


class FiltreReseau(ISelectionFilter):
    def AllowElement(self, el):
        return isinstance(el, (DB.Plumbing.Pipe, DB.Mechanical.Duct))

    def AllowReference(self, ref, pt):
        return False


forme = auto.choose_forme()
if forme is None:
    script.exit()
reg = auto.get_reglages()

with revit.Transaction("Charger familles reservation"):
    syms = auto.ensure_families(doc, fam_dir)
    auto.apply_pas(syms, reg)
    tag_syms = auto.ensure_tags(doc, fam_dir)
nb_tags = 0

total = []
infos = []
while True:
    try:
        ref = uidoc.Selection.PickObject(
            ObjectType.Element, FiltreReseau(),
            "Cliquer une canalisation ou une gaine (Echap pour terminer)")
    except Exception:
        break
    c = doc.GetElement(ref.ElementId)
    with revit.Transaction("Reservation auto"):
        news = []
        codes, msgs = auto.place_for_curve(doc, c, syms, news, forme, reg)
        # etiquette automatique dans la vue active
        if news and tag_syms:
            nb_tags += auto.tag_elements(doc, doc.ActiveView, news, tag_syms)
    total += codes
    infos += msgs

lignes = [str(len(total)) + " reservation(s) posee(s), " + str(nb_tags) + " etiquette(s)"]
if total:
    lignes.append(", ".join(total))
if infos:
    lignes.append("")
    lignes += infos[:15]
forms.alert("\n".join(lignes), title="Reservation auto")
