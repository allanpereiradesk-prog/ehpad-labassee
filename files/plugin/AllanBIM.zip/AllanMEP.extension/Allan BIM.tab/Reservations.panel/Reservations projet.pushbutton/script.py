# -*- coding: utf-8 -*-
"""Parcourt les canalisations et les gaines (projet, vue active ou
selection) et pose automatiquement une reservation a chaque mur ou dalle
traverse. Les reservations deja presentes ne sont pas doublees.
Les nouvelles reservations visibles dans la vue active sont etiquetees."""

__title__ = "Reservations\nprojet"

import os
from pyrevit import revit, DB, forms, script
import allan_reservation_auto as auto

doc = revit.doc
uidoc = revit.uidoc
def _dossier_extension(p):
    """Remonte jusqu'au dossier .extension (marche meme si le bouton
    est range dans un menu deroulant)."""
    while not p.lower().endswith(".extension") and os.path.dirname(p) != p:
        p = os.path.dirname(p)
    return p


ext_dir = _dossier_extension(os.path.abspath(__file__))
fam_dir = os.path.join(ext_dir, "Familles")

ordre = [("Tout le projet", "projet"),
         ("Vue active uniquement", "vue"),
         ("Selection actuelle", "selection")]
portees = dict(ordre)
p = forms.CommandSwitchWindow.show([k for k, v in ordre],
                                   message="Quels reseaux traiter ?")
if not p:
    script.exit()
scope = portees[p]

forme = auto.choose_forme()
if forme is None:
    script.exit()
reg = auto.get_reglages()

curves = auto.curves_to_scan(doc, scope, uidoc)
if not curves:
    forms.alert("Aucune canalisation ou gaine droite trouvee.", exitscript=True)

if not forms.alert("%d troncon(s) a analyser. Lancer ?" % len(curves), yes=True, no=True):
    script.exit()

total, news, ignores, doublons = [], [], 0, 0
with revit.Transaction("Reservations automatiques projet"):
    syms = auto.ensure_families(doc, fam_dir)
    auto.apply_pas(syms, reg)
    tag_syms = auto.ensure_tags(doc, fam_dir)
    with forms.ProgressBar(title="Reservations : {value}/{max_value}", cancellable=True) as pb:
        for k, c in enumerate(curves):
            if pb.cancelled:
                break
            try:
                codes, msgs = auto.place_for_curve(doc, c, syms, news, forme, reg)
            except Exception as ex:
                codes, msgs = [], ["Erreur id %s : %s" % (c.Id, ex)]
            total += codes
            for m in msgs:
                if "deja presente" in m:
                    doublons += 1
                elif "biais" in m:
                    ignores += 1
            pb.update_progress(k + 1, len(curves))
    # etiquettes dans la vue active pour celles qui y sont visibles
    visibles = set(e.Id for e in DB.FilteredElementCollector(doc, doc.ActiveView.Id)
                   .OfClass(DB.FamilyInstance))
    nb_tags = auto.tag_elements(doc, doc.ActiveView,
                                [i for i in news if i.Id in visibles], tag_syms) if tag_syms else 0

forms.alert(u"%d troncon(s) analyse(s)\n%d reservation(s) creee(s)\n%d deja existante(s)\n"
            u"%d traversee(s) en biais ignoree(s)\n%d etiquette(s) posee(s) dans la vue active"
            % (len(curves), len(total), doublons, ignores, nb_tags),
            title="Reservations projet")
