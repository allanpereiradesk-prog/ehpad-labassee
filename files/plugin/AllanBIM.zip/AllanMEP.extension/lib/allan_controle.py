# -*- coding: utf-8 -*-
"""Allan BIM - controle qualite des reseaux.

controler(doc, pente_mini) -> liste de Defaut, 4 familles :
  - Bout non raccorde   : extremite de gaine / tuyau / raccord / bouche libre
  - Pente               : evacuation a plat, pente trop faible ou contre-pente
  - Sans systeme        : gaine / tuyau sans systeme (ou systeme non defini)
  - Calorifuge manquant : chauffage, eau glacee, ECS, soufflage sans isolant
Ne modifie rien dans le projet.
"""
import math
from Autodesk.Revit import DB
import allan_relier as rel
import allan_clash as ac

MM = 1.0 / 304.8
BOUT, PENTE, SYSTEME, CALO = "Bout non raccorde", "Pente", "Sans systeme", "Calorifuge manquant"
TYPES = [BOUT, PENTE, SYSTEME, CALO]
BIC = DB.BuiltInCategory
CATS_AUTRES = ac.CATS_RACC + [BIC.OST_DuctTerminal, BIC.OST_MechanicalEquipment, BIC.OST_PlumbingFixtures]
MOTS_EVAC = ("evac", "usee", "vanne", "pluvial", "condens", "sanitaire")
A_ISOLER = ("SupplyHydronic", "ReturnHydronic", "DomesticHotWater", "SupplyAir")


class Defaut(object):
    def __init__(self, type_, el, texte, pt=None):
        self.type, self.el, self.id, self.texte = type_, el, el.Id, texte
        bb = el.get_BoundingBox(None)
        self.pt = pt if pt is not None else (bb.Min + bb.Max) * 0.5
        self.nom = ac.Net(el).nom

    def ligne(self):
        return "[%s]  %s  (id %s)\n      %s" % (self.type, self.nom, ac.eid(self.id), self.texte)


class Zone(object):
    """Cadrage pour allan_clash.preparer_vues."""
    def __init__(self, d):
        self.a = self.b = ac.Net(d.el)
        self.pt = d.pt


def _systeme(doc, el):
    """(classification en texte, nom du type de systeme) ou (None, '')."""
    try:
        s = el.MEPSystem
        if s is None:
            return None, ""
        ty = doc.GetElement(s.GetTypeId())
        return str(ty.SystemClassification), ac.nom(ty)
    except Exception:
        return None, ""


def _sans_accent(t):
    for a, b in ((u"\xe9", "e"), (u"\xe8", "e"), (u"\xea", "e"), (u"\xe0", "a"), (u"\xf4", "o")):
        t = t.replace(a, b)
    return t.lower()


def controler(doc, pente_mini=1.0):
    out = []
    courbes = list(DB.FilteredElementCollector(doc).OfClass(DB.Mechanical.Duct)) + \
        list(DB.FilteredElementCollector(doc).OfClass(DB.Plumbing.Pipe))
    autres = list(DB.FilteredElementCollector(doc).WherePasses(ac._cats(CATS_AUTRES))
                  .WhereElementIsNotElementType())
    for el in courbes + autres:
        if el.get_BoundingBox(None) is None:
            continue
        courbe = rel.is_curve(el)
        try:
            # ---- bouts non raccordes
            libres = []
            for c in rel.connectors(el):
                if courbe and c.ConnectorType != DB.ConnectorType.End:
                    continue
                if not c.IsConnected:
                    libres.append(c)
            for c in libres:
                out.append(Defaut(BOUT, el, "Une extremite n'est raccordee a rien.", c.Origin))
            if not courbe:
                continue
            classif, nom_sys = _systeme(doc, el)
            # ---- systeme
            if classif is None or "Undefined" in classif:
                out.append(Defaut(SYSTEME, el, "Aucun systeme (ou systeme non defini) : pas de calcul ni de couleur de systeme."))
            # ---- pente des evacuations
            if isinstance(el, DB.Plumbing.Pipe):
                n = _sans_accent(nom_sys)
                if classif == "Sanitary" or any(m in n for m in MOTS_EVAC):
                    ln = el.Location.Curve
                    p0, p1 = ln.GetEndPoint(0), ln.GetEndPoint(1)
                    h = math.hypot(p1.X - p0.X, p1.Y - p0.Y)
                    if h > 10 * MM:
                        pente = abs(p1.Z - p0.Z) / h * 100.0
                        if pente <= 100.0:                   # au-dela : c'est une chute
                            contre = False
                            try:
                                cin = cout = None
                                for c in rel.connectors(el):
                                    if c.ConnectorType != DB.ConnectorType.End:
                                        continue
                                    if c.Direction == DB.FlowDirectionType.In:
                                        cin = c
                                    elif c.Direction == DB.FlowDirectionType.Out:
                                        cout = c
                                contre = cin is not None and cout is not None and \
                                    cout.Origin.Z > cin.Origin.Z + MM
                            except Exception:
                                pass
                            if contre:
                                out.append(Defaut(PENTE, el, "CONTRE-PENTE : l'eau doit remonter (%.1f %%)." % pente))
                            elif pente < 0.05:
                                out.append(Defaut(PENTE, el, "Evacuation a plat (0 %%), mini demande %.1f %%." % pente_mini))
                            elif pente < pente_mini - 1e-6:
                                out.append(Defaut(PENTE, el, "Pente de %.2f %%, mini demande %.1f %%." % (pente, pente_mini)))
            # ---- calorifuge
            if classif in A_ISOLER:
                if DB.InsulationLiningBase.GetInsulationIds(doc, el.Id).Count == 0:
                    quoi = {"SupplyHydronic": "depart chauffage / eau glacee", "ReturnHydronic": "retour chauffage / eau glacee",
                            "DomesticHotWater": "eau chaude sanitaire", "SupplyAir": "soufflage"}[classif]
                    out.append(Defaut(CALO, el, "Reseau de %s sans isolant." % quoi))
        except Exception:
            pass
    ordre = dict((t, i) for i, t in enumerate(TYPES))
    out.sort(key=lambda d: (ordre[d.type], ac.eid(d.id)))
    return out
