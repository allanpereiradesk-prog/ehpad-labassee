# -*- coding: utf-8 -*-
"""Allan BIM - raccordement automatique de deux reseaux (gaines ou tuyaux).

Cas geres (A = 1er element clique, B = 2e) :
  - bouts alignes (dans l'axe)      -> troncon droit (+ reduction si tailles differentes)
  - axes qui se croisent, A et B
    se terminent pres du croisement -> on prolonge les deux + COUDE
  - A arrive au milieu de B         -> on prolonge A + TE (ou piquage)
  - reseaux paralleles decales /
    axes qui ne se croisent pas     -> troncon de liaison + 2 COUDES
  - A ou B est un equipement / une
    bouche                          -> troncon + coude si besoin
A appeler dans une transaction.
"""

from Autodesk.Revit import DB

MM = 1.0 / 304.8
TOL = 5 * MM


# ------------------------------------------------------------ outils
def is_curve(e):
    return isinstance(e, (DB.Mechanical.Duct, DB.Plumbing.Pipe))


def connectors(el):
    cm = None
    try:
        if isinstance(el, DB.MEPCurve):
            cm = el.ConnectorManager
        elif isinstance(el, DB.FamilyInstance) and el.MEPModel:
            cm = el.MEPModel.ConnectorManager
    except Exception:
        cm = None
    out = []
    if cm is None:
        return out
    for c in cm.Connectors:
        try:
            if c.ConnectorType in (DB.ConnectorType.End, DB.ConnectorType.Curve,
                                   DB.ConnectorType.Physical):
                out.append(c)
        except Exception:
            pass
    return out


def free_end_connectors(el):
    cs = [c for c in connectors(el) if c.ConnectorType == DB.ConnectorType.End or not is_curve(el)]
    free = [c for c in cs if not c.IsConnected]
    return free or cs


def closest_pair(e1, e2):
    best = None
    for a in free_end_connectors(e1):
        for b in free_end_connectors(e2):
            try:
                if a.Domain != b.Domain:
                    continue
                d = a.Origin.DistanceTo(b.Origin)
            except Exception:
                continue
            if best is None or d < best[0]:
                best = (d, a, b)
    return best


def conn_at(el, pt, tol=TOL * 4):
    """Connecteur d'extremite de el le plus proche de pt."""
    best = None
    for c in connectors(el):
        d = c.Origin.DistanceTo(pt)
        if best is None or d < best[0]:
            best = (d, c)
    return best[1] if best and best[0] < tol else (best[1] if best else None)


def out_dir(c):
    """Direction sortante du connecteur."""
    return c.CoordinateSystem.BasisZ.Normalize()


def move_end(curve_el, old_pt, new_pt):
    """Deplace l'extremite de la gaine/tuyau situee en old_pt vers new_pt."""
    ln = curve_el.Location.Curve
    p0, p1 = ln.GetEndPoint(0), ln.GetEndPoint(1)
    if p0.DistanceTo(old_pt) < p1.DistanceTo(old_pt):
        p0 = new_pt
    else:
        p1 = new_pt
    if p0.DistanceTo(p1) < TOL:
        raise Exception("troncon trop court apres prolongement")
    curve_el.Location.Curve = DB.Line.CreateBound(p0, p1)


def lines_closest(p1, d1, p2, d2):
    """Points les plus proches entre deux droites infinies (p + t d)."""
    w0 = p1 - p2
    a, b, c = d1.DotProduct(d1), d1.DotProduct(d2), d2.DotProduct(d2)
    d, e = d1.DotProduct(w0), d2.DotProduct(w0)
    den = a * c - b * b
    if abs(den) < 1e-9:
        return None
    t = (b * e - c * d) / den
    s = (a * e - b * d) / den
    return p1 + d1 * t, p2 + d2 * s, t, s


def system_type_id(el):
    for bip in (DB.BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM,
                DB.BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM):
        try:
            p = el.get_Parameter(bip)
            if p and p.AsElementId() != DB.ElementId.InvalidElementId:
                return p.AsElementId()
        except Exception:
            pass
    try:
        if el.MEPSystem:
            return el.MEPSystem.GetTypeId()
    except Exception:
        pass
    return DB.ElementId.InvalidElementId


def copy_size(src, dst):
    for bip in (DB.BuiltInParameter.RBS_CURVE_WIDTH_PARAM,
                DB.BuiltInParameter.RBS_CURVE_HEIGHT_PARAM,
                DB.BuiltInParameter.RBS_CURVE_DIAMETER_PARAM,
                DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM):
        try:
            ps, pd = src.get_Parameter(bip), dst.get_Parameter(bip)
            if ps and pd and ps.HasValue and not pd.IsReadOnly:
                pd.Set(ps.AsDouble())
        except Exception:
            pass


def new_segment(doc, model, p_start, p_end, level_id, size_from=None):
    """Nouvelle gaine / tuyau du meme type et systeme que model."""
    size_from = size_from or model
    if p_start.DistanceTo(p_end) < TOL:
        return None
    sys_id = system_type_id(model)
    if isinstance(model, DB.Plumbing.Pipe):
        seg = DB.Plumbing.Pipe.Create(doc, sys_id, model.GetTypeId(), level_id, p_start, p_end)
    else:
        seg = DB.Mechanical.Duct.Create(doc, sys_id, model.GetTypeId(), level_id, p_start, p_end)
    copy_size(size_from, seg)
    doc.Regenerate()
    return seg


def same_size(a, b):
    try:
        return abs(a.Radius - b.Radius) < 1e-4 if a.Shape == DB.ConnectorProfileType.Round \
            else (abs(a.Width - b.Width) < 1e-4 and abs(a.Height - b.Height) < 1e-4)
    except Exception:
        return True


def join_straight(doc, ca, cb):
    """Deux connecteurs face a face au meme point : liaison directe ou reduction."""
    if same_size(ca, cb):
        try:
            ca.ConnectTo(cb)
            return "liaison directe"
        except Exception:
            pass
    doc.Create.NewTransitionFitting(ca, cb)
    return "reduction"


def join_angle(doc, ca, cb):
    """Coude entre deux connecteurs au meme point (ou droit si alignes)."""
    if abs(out_dir(ca).DotProduct(out_dir(cb)) + 1) < 1e-3:
        return join_straight(doc, ca, cb)
    doc.Create.NewElbowFitting(ca, cb)
    return "coude"


def level_of(el, doc):
    try:
        return el.ReferenceLevel.Id
    except Exception:
        pass
    try:
        return el.LevelId
    except Exception:
        return DB.ElementId.InvalidElementId


def break_curve(doc, curve_el, pt):
    if isinstance(curve_el, DB.Plumbing.Pipe):
        nid = DB.Plumbing.PlumbingUtils.BreakCurve(doc, curve_el.Id, pt)
    else:
        nid = DB.Mechanical.MechanicalUtils.BreakCurve(doc, curve_el.Id, pt)
    doc.Regenerate()
    return doc.GetElement(nid)


# ------------------------------------------------------------ relier
def relier(doc, e1, e2):
    """Raccorde e1 et e2. Retourne une phrase decrivant ce qui a ete fait."""
    pair = closest_pair(e1, e2)
    if pair is None:
        raise Exception("aucun connecteur compatible (gaine avec gaine, tuyau avec tuyau)")
    dist, ca, cb = pair
    pa, pb = ca.Origin, cb.Origin
    da, db_ = out_dir(ca), out_dir(cb)
    lvl = level_of(e1 if is_curve(e1) else e2, doc)

    # ---------- deux gaines / tuyaux
    if is_curve(e1) and is_curve(e2):
        par = abs(da.DotProduct(db_)) > 0.999
        if par:
            v = pb - pa
            lateral = (v - da * v.DotProduct(da)).GetLength()
            if lateral < TOL:
                # dans l'axe
                if dist < TOL:
                    return join_straight(doc, ca, cb)
                seg = new_segment(doc, e1, pa, pb, lvl)
                s0, s1 = conn_at(seg, pa), conn_at(seg, pb)
                r1 = join_straight(doc, ca, s0)
                r2 = join_straight(doc, s1, cb)
                return "troncon droit (%s / %s)" % (r1, r2)
            return _liaison_2_coudes(doc, e1, ca, cb, lvl)

        res = lines_closest(pa, da, pb, db_)
        if res is not None:
            q1, q2, t, s = res
            if q1.DistanceTo(q2) < TOL * 2 and t > -TOL:
                ip = (q1 + q2) * 0.5
                # position du croisement sur e2 : pres d'un bout -> coude, au milieu -> te
                crv2 = e2.Location.Curve
                proj = crv2.Project(ip)
                p0, p1 = crv2.GetEndPoint(0), crv2.GetEndPoint(1)
                milieu = proj is not None and proj.Distance < TOL * 2 and \
                    ip.DistanceTo(p0) > 150 * MM and ip.DistanceTo(p1) > 150 * MM
                if milieu:
                    return _te(doc, e1, ca, e2, ip)
                if s > -TOL:
                    if not same_size(ca, cb):
                        import allan_trace as _tr
                        r = _tr.build_route(doc, e1, pa, [ip], e2, pb)
                        return "coude + reduction (%d troncon(s))" % r[0]
                    move_end(e1, pa, ip)
                    move_end(e2, pb, ip)
                    doc.Regenerate()
                    return join_angle(doc, conn_at(e1, ip), conn_at(e2, ip))
        return _liaison_2_coudes(doc, e1, ca, cb, lvl)

    # ---------- avec un equipement / une bouche
    curve, cc, other_c = (e1, ca, cb) if is_curve(e1) else ((e2, cb, ca) if is_curve(e2) else (None, None, None))
    if curve is None:
        # deux equipements : troncon direct avec le 1er type trouve
        raise Exception("choisir au moins une gaine ou un tuyau")
    if abs(out_dir(cc).DotProduct(out_dir(other_c)) + 1) < 1e-3 and \
            ((other_c.Origin - cc.Origin) - out_dir(cc) * (other_c.Origin - cc.Origin).DotProduct(out_dir(cc))).GetLength() < TOL:
        seg = new_segment(doc, curve, cc.Origin, other_c.Origin, lvl)
        if seg:
            join_straight(doc, cc, conn_at(seg, cc.Origin))
            conn_at(seg, other_c.Origin).ConnectTo(other_c)
        else:
            cc.ConnectTo(other_c)
        return "troncon droit vers l'equipement"
    # coude : on sort de l'equipement dans l'axe de son connecteur
    res = lines_closest(cc.Origin, out_dir(cc), other_c.Origin, out_dir(other_c))
    if res is not None and res[0].DistanceTo(res[1]) < TOL * 2:
        ip = (res[0] + res[1]) * 0.5
        move_end(curve, cc.Origin, ip)
        seg = new_segment(doc, curve, other_c.Origin, ip, lvl)
        conn_at(seg, other_c.Origin).ConnectTo(other_c)
        doc.Regenerate()
        join_angle(doc, conn_at(curve, ip), conn_at(seg, ip))
        return "troncon + coude vers l'equipement"
    seg = new_segment(doc, curve, cc.Origin, other_c.Origin, lvl)
    join_angle(doc, cc, conn_at(seg, cc.Origin))
    conn_at(seg, other_c.Origin).ConnectTo(other_c)
    return "troncon de liaison vers l'equipement"


def _liaison_2_coudes(doc, e1, ca, cb, lvl):
    pa, pb = ca.Origin, cb.Origin
    if not same_size(ca, cb):
        import allan_trace as _tr
        r = _tr.build_route(doc, e1, pa, [], cb.Owner, pb)
        return "troncon de liaison + reduction (%d troncon(s), %d coude(s))" % (r[0], r[1])
    seg = new_segment(doc, e1, pa, pb, lvl)
    r1 = join_angle(doc, ca, conn_at(seg, pa))
    r2 = join_angle(doc, conn_at(seg, pb), cb)
    return "troncon de liaison (%s + %s)" % (r1, r2)


def _te(doc, e1, ca, e2, ip):
    pa = ca.Origin
    move_end(e1, pa, ip)
    doc.Regenerate()
    branch = conn_at(e1, ip)
    try:
        doc.Create.NewTakeoffFitting(branch, e2)
        return "piquage"
    except Exception:
        pass
    new2 = break_curve(doc, e2, ip)
    c1, c2 = conn_at(e2, ip), conn_at(new2, ip)
    doc.Create.NewTeeFitting(c1, c2, branch)
    return "te"


# ------------------------------------------------------------ raccords manquants
def _needs_fittings(doc):
    for ty in list(DB.FilteredElementCollector(doc).OfClass(DB.Mechanical.DuctType)) + \
            list(DB.FilteredElementCollector(doc).OfClass(DB.Plumbing.PipeType)):
        if ty.RoutingPreferenceManager.GetNumberOfRules(DB.RoutingPreferenceRuleGroupType.Elbows) == 0:
            return True
    return False


def ensure_fittings(doc):
    """Si des types de gaine / tuyau n'ont pas de coude, importe les raccords
    du gabarit Revit 'Systemes' et complete les preferences de routage.
    Retourne un texte (ou '' si rien a faire). A appeler dans une transaction."""
    import os
    from System.Collections.Generic import List
    if not _needs_fittings(doc):
        return ""
    app = doc.Application
    tdir = os.path.join(os.path.dirname(os.path.dirname(app.FamilyTemplatePath)), "Templates")
    cands = [os.path.join(tdir, "French", "Systems-DefaultFRAFRA.rte"),
             os.path.join(tdir, "English", "Systems-Default_Metric.rte")]
    path = next((p for p in cands if os.path.exists(p)), None)
    if path is None:
        return "Aucun gabarit 'Systemes' trouve pour importer les raccords."

    class Dup(DB.IDuplicateTypeNamesHandler):
        def OnDuplicateTypeNamesFound(self, args):
            return DB.DuplicateTypeAction.UseDestinationTypes

    src = app.OpenDocumentFile(path)
    try:
        ids = List[DB.ElementId]()
        for ty in list(DB.FilteredElementCollector(src).OfClass(DB.Mechanical.DuctType)) + \
                list(DB.FilteredElementCollector(src).OfClass(DB.Plumbing.PipeType)):
            if ty.RoutingPreferenceManager.GetNumberOfRules(DB.RoutingPreferenceRuleGroupType.Elbows) > 0:
                ids.Add(ty.Id)
        opt = DB.CopyPasteOptions()
        opt.SetDuplicateTypeNamesHandler(Dup())
        DB.ElementTransformUtils.CopyElements(src, ids, doc, DB.Transform.Identity, opt)
    finally:
        src.Close(False)
    doc.Regenerate()

    groups = [DB.RoutingPreferenceRuleGroupType.Elbows, DB.RoutingPreferenceRuleGroupType.Junctions,
              DB.RoutingPreferenceRuleGroupType.Transitions, DB.RoutingPreferenceRuleGroupType.Unions,
              DB.RoutingPreferenceRuleGroupType.Crosses, DB.RoutingPreferenceRuleGroupType.Caps,
              DB.RoutingPreferenceRuleGroupType.MechanicalJoints,
              DB.RoutingPreferenceRuleGroupType.TransitionsRectangularToRound,
              DB.RoutingPreferenceRuleGroupType.TransitionsRectangularToOval,
              DB.RoutingPreferenceRuleGroupType.TransitionsOvalToRound]

    def copy_rules(s, d):
        rs, rd = s.RoutingPreferenceManager, d.RoutingPreferenceManager
        for g in groups:
            try:
                if rd.GetNumberOfRules(g) > 0:
                    continue
                for k in range(rs.GetNumberOfRules(g)):
                    r = rs.GetRule(g, k)
                    rd.AddRule(g, DB.RoutingPreferenceRule(r.MEPPartId, r.Description))
            except Exception:
                pass
        try:
            rd.PreferredJunctionType = rs.PreferredJunctionType
        except Exception:
            pass

    fixed = 0
    dts = list(DB.FilteredElementCollector(doc).OfClass(DB.Mechanical.DuctType))
    for d in dts:
        if d.RoutingPreferenceManager.GetNumberOfRules(DB.RoutingPreferenceRuleGroupType.Elbows) == 0:
            s = [x for x in dts if x.Shape == d.Shape and
                 x.RoutingPreferenceManager.GetNumberOfRules(DB.RoutingPreferenceRuleGroupType.Elbows) > 0]
            if s:
                copy_rules(s[0], d)
                fixed += 1
    pts = list(DB.FilteredElementCollector(doc).OfClass(DB.Plumbing.PipeType))
    good = [x for x in pts if x.RoutingPreferenceManager.GetNumberOfRules(DB.RoutingPreferenceRuleGroupType.Elbows) > 0]
    good.sort(key=lambda x: 0 if DB.Element.Name.GetValue(x) == "Standard" else 1)
    for p in pts:
        if p.RoutingPreferenceManager.GetNumberOfRules(DB.RoutingPreferenceRuleGroupType.Elbows) == 0 and good:
            copy_rules(good[0], p)
            fixed += 1
    doc.Regenerate()
    return ("Raccords (coudes, tes, reductions) importes dans le projet "
            "et ajoutes a %d type(s). Pense a enregistrer le projet." % fixed)
