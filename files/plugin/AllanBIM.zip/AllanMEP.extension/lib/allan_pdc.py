# -*- coding: utf-8 -*-
"""Allan BIM - Pertes de charge (ENF117 TD1 / TD2).

TD1 : pertes de charge lineaires. Lecture des canalisations dans la maquette
      (Dint, debit, Re, facteur de frottement, frottement), recalcul Colebrook,
      ecarts. Un "cas" = un fluide / une temperature / un segment.
TD2 : pertes de charge singulieres. Lecture des raccords (coudes, reductions),
      coefficient k interpole dans PipeKFactors.xml, comparaison avec Revit.
Export : un vrai classeur .xlsx avec formules (une feuille par cas).
"""

import os
import io
import re
import math
import json
import zipfile
import datetime
import System
from Autodesk.Revit import DB
from Autodesk.Revit.DB import Plumbing as P

# ------------------------------------------------------------------ constantes
THERMEXCEL = [(40.0, 992.25, 0.000653), (54.0, 986.14, 0.000512), (70.0, 977.63, 0.000404)]
POUCE = 0.0393701
SERVEUR_KTABLE = u"51dd5e98-a9dd-464b-b286-4a37953610bf"
SERVEUR_TYPE = u"3bf616f9-6b98-4a21-80ff-da1120c8f6d6"   # "Utiliser la definition du type"
TABLE_COUDE = u"Long Radius Elbow"
TABLE_REDUC = u"Reducer/Coupling/Union/Increaser"

# valeurs par defaut (PipeKFactors.xml Revit 2026) si le fichier est introuvable
KF_DEFAUT = {
    TABLE_COUDE: ([0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 2.5, 3.0, 4.0, 6.0, 8.0, 10.0, 12.0, 14.0, 16.0, 18.0, 20.0, 24.0],
                  [0.43, 0.40, 0.37, 0.35, 0.34, 0.30, 0.29, 0.29, 0.27, 0.24, 0.22, 0.22, 0.21, 0.21, 0.21, 0.19, 0.19, 0.19]),
    TABLE_REDUC: ([1.0, 1.25, 1.5, 1.75, 2.0, 2.25, 2.5, 2.75, 3.0, 3.25, 3.5, 3.75, 4.0],
                  [0.0, 0.2, 0.28, 0.33, 0.37, 0.39, 0.40, 0.41, 0.42, 0.43, 0.43, 0.44, 0.44]),
}
DN_COUDES = [20, 25, 32, 40, 50, 65, 80, 100, 125, 150, 200, 250, 300, 350, 400]

U = DB.UnitTypeId


def _id(e):
    i = e if isinstance(e, DB.ElementId) else e.Id
    return i.Value if hasattr(i, "Value") else i.IntegerValue


def eid(n):
    return DB.ElementId(System.Int64(int(n)))


def nom_el(e):
    try:
        return DB.Element.Name.GetValue(e)
    except Exception:
        return u""


def conv(v, unite):
    return DB.UnitUtils.ConvertFromInternalUnits(v, unite)


def vers_interne(v, unite):
    return DB.UnitUtils.ConvertToInternalUnits(v, unite)


# ------------------------------------------------------------------ calculs
def interp(x, X, Y):
    """Interpolation lineaire, meme logique que la formule Excel (bornee aux extremites)."""
    n = len(X)
    i = 0
    for k in range(n - 1):
        if x >= X[k]:
            i = k
    i = min(i, n - 2)
    return Y[i] + (Y[i + 1] - Y[i]) * (x - X[i]) / (X[i + 1] - X[i])


def thermexcel(theta):
    X = [t[0] for t in THERMEXCEL]
    return interp(theta, X, [t[1] for t in THERMEXCEL]), interp(theta, X, [t[2] for t in THERMEXCEL])


def colebrook(re_, eps, dint, kc=3.7, n=8):
    lam = 0.02
    for _ in range(n):
        lam = 1.0 / (-2.0 * math.log10(2.51 / (re_ * math.sqrt(lam)) + eps / (kc * dint))) ** 2
    return lam


def calc(qv, rho, mu, eps, kc, dint):
    """qv L/s, rho kg/m3, mu Pa.s, eps mm, dint mm -> v, Re, lambda, j (Pa/m)"""
    D = dint / 1000.0
    if D <= 0 or qv <= 0 or mu <= 0:
        return None
    v = qv / 1000.0 / (math.pi * D * D / 4.0)
    re_ = rho * v * D / mu
    lam = 64.0 / re_ if re_ < 2000 else colebrook(re_, eps, dint, kc)
    j = lam / D * v * v / 2.0 * rho
    return {"v": v, "re": re_, "lam": lam, "j": j,
            "regime": u"Laminaire" if re_ < 2000 else (u"Transitoire" if re_ < 4000 else u"Turbulent")}


def ecart(a, b):
    if a is None or b in (None, 0):
        return None
    return (a - b) / b


def k_coude(dn, kf):
    X, Y = kf[TABLE_COUDE]
    return interp(dn * POUCE, X, Y)


def k_reduc(d1, d2, kf):
    X, Y = kf[TABLE_REDUC]
    r = max(d1, d2) / float(min(d1, d2))
    return interp(min(r, 4.0), X, Y)


def ratio_depuis_k(k, kf):
    """D1/D2 qui donnerait ce k dans la table des reductions (pour comprendre Revit)."""
    X, Y = kf[TABLE_REDUC]
    for i in range(len(X) - 1):
        if Y[i] <= k <= Y[i + 1] and Y[i + 1] != Y[i]:
            return X[i] + (k - Y[i]) * (X[i + 1] - X[i]) / (Y[i + 1] - Y[i])
    return None


# ------------------------------------------------------------------ PipeKFactors.xml
def chemin_kfactors(app):
    try:
        v = app.VersionNumber
    except Exception:
        v = u"2026"
    for p in [os.path.join(os.environ.get("ProgramFiles", u"C:\\Program Files"), u"Autodesk", u"Revit %s" % v, u"PipeKFactors.xml")]:
        if os.path.exists(p):
            return p
    return None


def charger_kfactors(chemin):
    """Lit les tables Long Radius Elbow et Reducer dans PipeKFactors.xml."""
    kf = dict(KF_DEFAUT)
    if not chemin or not os.path.exists(chemin):
        return kf, u"PipeKFactors.xml introuvable : tables par défaut (Revit 2026)."
    t = io.open(chemin, encoding="utf-8-sig").read()
    for bloc in re.findall(r"<Table[^>]*>(.*?)</Table>", t, re.S):
        nom = bloc.split(u"<", 1)[0].strip()
        if nom not in (TABLE_COUDE, TABLE_REDUC):
            continue
        sub = re.search(r"<SubTable[^>]*>(.*?)</SubTable>", bloc, re.S)
        if not sub:
            continue
        s = sub.group(1)
        if nom == TABLE_COUDE:
            ax = re.search(r"<Y1Axis>(.*?)</Y1Axis>", s, re.S)
        else:
            ax = re.search(r"<XAxis>(.*?)</XAxis>", s, re.S)
        da = re.search(r"<Data>(.*?)</Data>", s, re.S)
        if ax and da:
            X = [float(x) for x in ax.group(1).split()]
            Y = [float(y) for y in da.group(1).split()][:len(X)]
            if len(X) == len(Y) and len(X) > 1:
                kf[nom] = (X, Y)
    return kf, u"Tables k lues dans %s" % chemin


# ------------------------------------------------------------------ cas (sauvegarde json)
def nouveau_cas(nom, fluide=u"", theta=20.0, rho=998.2, mu=0.001, eps=0.04572, qv=10.2, kc=3.7, segment=u"", source=u""):
    return {"nom": nom, "fluide": fluide, "theta": theta, "rho": rho, "mu": mu, "eps": eps, "qv": qv, "kc": kc,
            "segment": segment, "source": source, "lignes": []}


def chemin_sauvegarde(doc):
    d = os.path.dirname(doc.PathName) if doc.PathName else os.path.join(os.path.expanduser("~"), "Documents")
    if not os.path.isdir(d):
        d = os.path.expanduser("~")
    base = os.path.splitext(os.path.basename(doc.PathName or doc.Title))[0] or u"projet"
    return os.path.join(d, u"%s - pertes de charge.json" % base)


def charger_etat(chemin):
    if os.path.exists(chemin):
        try:
            with io.open(chemin, encoding="utf-8") as f:
                return json.loads(f.read())
        except Exception:
            pass
    return {"cas": [], "td2": []}


def sauver_etat(chemin, etat):
    with io.open(chemin, "w", encoding="utf-8") as f:
        f.write(unicode(json.dumps(etat, ensure_ascii=False, indent=1)))


# ------------------------------------------------------------------ lecture maquette
def systemes(doc):
    """Systemes de canalisation (reseaux) de la maquette : [(nom, element)]"""
    res = []
    for s in DB.FilteredElementCollector(doc).OfClass(P.PipingSystem):
        res.append((nom_el(s), s))
    res.sort(key=lambda x: x[0].lower())
    return res


def types_systeme(doc):
    res = [(nom_el(s), s) for s in DB.FilteredElementCollector(doc).OfClass(P.PipingSystemType)]
    res.sort(key=lambda x: x[0].lower())
    return res


def fluides(doc):
    res = [(nom_el(f), f) for f in DB.FilteredElementCollector(doc).OfClass(P.FluidType)]
    res.sort(key=lambda x: x[0].lower())
    return res


def elements(doc, bic, portee, uidoc=None, systeme=None):
    if portee == "selection" and uidoc is not None:
        res = []
        for i in uidoc.Selection.GetElementIds():
            e = doc.GetElement(i)
            if e is not None and e.Category is not None and _id(e.Category) == int(bic):
                res.append(e)
        return res
    if portee == "systeme" and systeme is not None:
        res = []
        try:
            for e in systeme.PipingNetwork:
                if e.Category is not None and _id(e.Category) == int(bic):
                    res.append(e)
        except Exception:
            pass
        return res
    return list(DB.FilteredElementCollector(doc).OfCategory(bic).WhereElementIsNotElementType())


def _d(e, bip, unite=None):
    p = e.get_Parameter(bip)
    if p is None or not p.HasValue:
        return None
    v = p.AsDouble()
    return conv(v, unite) if unite is not None else v


def proprietes_fluide(fluide, theta):
    """(rho, mu) d'un FluidType Revit a theta (deg C), interpole entre ses temperatures."""
    pts = []
    for t in fluide.GetFluidTemperatureSetIterator():
        pts.append((conv(t.Temperature, U.Celsius), conv(t.Density, U.KilogramsPerCubicMeter),
                    conv(t.Viscosity, U.PascalSeconds)))
    if not pts:
        return None, None
    pts.sort()
    for T, r, m in pts:
        if abs(T - theta) < 0.01:
            return r, m
    X = [p[0] for p in pts]
    if len(X) == 1:
        return pts[0][1], pts[0][2]
    return interp(theta, X, [p[1] for p in pts]), interp(theta, X, [p[2] for p in pts])


def fluide_du_type_systeme(doc, st):
    """Nom du fluide, temperature (C), rho, mu du type de systeme."""
    f = doc.GetElement(st.FluidType)
    if f is None:
        return None
    theta = conv(st.FluidTemperature, U.Celsius)
    rho, mu = proprietes_fluide(f, theta)
    return {"fluide": nom_el(f), "theta": round(theta, 4), "rho": rho, "mu": mu, "systeme": nom_el(st)}


def lire_canalisations(doc, pipes, log):
    """Regroupe les canalisations par DN. Retourne (lignes, infos)."""
    par_dn = {}
    infos = {"eps": None, "segment": None, "qv": None, "type_systeme": None}
    debits = {}
    for e in pipes:
        try:
            dn = _d(e, DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM, U.Millimeters)
            if dn is None:
                continue
            dn = int(round(dn))
            qv = _d(e, DB.BuiltInParameter.RBS_PIPE_FLOW_PARAM, U.LitersPerSecond) or 0.0
            ligne = {
                "dn": dn,
                "dint": round(_d(e, DB.BuiltInParameter.RBS_PIPE_INNER_DIAM_PARAM, U.Millimeters), 4),
                "dext": round(_d(e, DB.BuiltInParameter.RBS_PIPE_OUTER_DIAMETER, U.Millimeters), 4),
                "revit": {
                    "qv": qv,
                    "re": _d(e, DB.BuiltInParameter.RBS_PIPE_REYNOLDS_NUMBER_PARAM),
                    "lam": _d(e, DB.BuiltInParameter.FRICTION_FACTOR),
                    "j": _d(e, DB.BuiltInParameter.RBS_PIPE_FRICTION_PARAM, U.PascalsPerMeter),
                    "v": _d(e, DB.BuiltInParameter.RBS_PIPE_VELOCITY_PARAM, U.MetersPerSecond),
                },
            }
            if dn not in par_dn:
                par_dn[dn] = ligne
            debits[round(qv, 4)] = debits.get(round(qv, 4), 0) + 1
            if infos["eps"] is None:
                infos["eps"] = _d(e, DB.BuiltInParameter.PIPE_ROUGHNESS, U.Millimeters)
                p = e.get_Parameter(DB.BuiltInParameter.RBS_PIPE_SEGMENT_PARAM)
                infos["segment"] = p.AsValueString() if p else u""
                p = e.get_Parameter(DB.BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM)
                if p is not None:
                    infos["type_systeme"] = p.AsElementId()
        except Exception as ex:
            log.append(u"Canalisation %s ignorée : %s" % (_id(e), ex))
    if debits:
        infos["qv"] = max(debits.items(), key=lambda x: x[1])[0]
    if infos["eps"] is not None:
        infos["eps"] = round(infos["eps"], 6)
        if infos["eps"] > 1.0:
            log.append(u"Attention : rugosité ε = %.4f mm, valeur anormale (acier ≈ 0,04572 mm). Vérifie le segment "
                       u"(Gérer › Paramètres de génie climatique › Segments et tailles) et l'unité de rugosité." % infos["eps"])
    lignes = [par_dn[k] for k in sorted(par_dn)]
    if lignes and all((l["revit"]["qv"] or 0) == 0 for l in lignes):
        log.append(u"Attention : débit nul dans Revit. Vérifie que le système a des équipements avec débit, ou que le calcul est activé.")
    return lignes, infos


def creer_fluide(doc, nom, points, log):
    """Cree (ou met a jour) un FluidType avec des points (theta C, rho, mu). A appeler dans une transaction."""
    f = None
    for n, fl in fluides(doc):
        if n == nom:
            f = fl
    if f is None:
        f = P.FluidType.Create(doc, nom)
        log.append(u"Fluide « %s » créé dans Revit." % nom)
    else:
        try:
            f.ClearAllTemperatures()
        except Exception:
            pass
        log.append(u"Fluide « %s » mis à jour." % nom)
    for th, rho, mu in points:
        f.AddTemperature(P.FluidTemperature(vers_interne(th, U.Celsius), vers_interne(mu, U.PascalSeconds),
                                            vers_interne(rho, U.KilogramsPerCubicMeter)))
    return f


def affecter_fluide(doc, st, fluide, theta, log):
    st.FluidType = fluide.Id
    st.FluidTemperature = vers_interne(theta, U.Celsius)
    log.append(u"Système « %s » : fluide « %s » à %s °C." % (nom_el(st), nom_el(fluide), theta))


# ------------------------------------------------------------------ TD2 : raccords
def _part_type(doc, e):
    try:
        fam = doc.GetElement(e.GetTypeId()).Family
        pt = fam.get_Parameter(DB.BuiltInParameter.FAMILY_CONTENT_PART_TYPE).AsInteger()
        if pt == int(DB.PartType.Elbow):
            return u"Coude"
        if pt == int(DB.PartType.Transition):
            return u"Réduction"
        if pt in (int(DB.PartType.Tee), int(DB.PartType.Cross)):
            return u"Té"
        return u"Autre"
    except Exception:
        return u"Autre"


def _cote(doc, fit, c):
    """DN, Dint, vitesse du cote d'un connecteur (via la canalisation connectee)."""
    for r in c.AllRefs:
        o = r.Owner
        if o is None or o.Id == fit.Id:
            continue
        if isinstance(o, P.Pipe):
            return (int(round(_d(o, DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM, U.Millimeters))),
                    _d(o, DB.BuiltInParameter.RBS_PIPE_INNER_DIAM_PARAM, U.Millimeters),
                    _d(o, DB.BuiltInParameter.RBS_PIPE_VELOCITY_PARAM, U.MetersPerSecond), _id(o))
    # raccord colle a un raccord : on prend le connecteur lui-meme
    try:
        d = conv(c.Radius * 2.0, U.Millimeters)
        q = conv(c.Flow, U.CubicMetersPerSecond)
        v = q / (math.pi * (d / 1000.0) ** 2 / 4.0) if d > 0 else None
        return int(round(d)), d, v, None
    except Exception:
        return None, None, None, None


def lire_raccords(doc, fits, kf, log):
    res = []
    for f in fits:
        try:
            mm = f.MEPModel
            if mm is None or mm.ConnectorManager is None:
                continue
            cons = [c for c in mm.ConnectorManager.Connectors]
            if len(cons) != 2:
                continue  # les tes ne sont pas dans le TD
            entree = [c for c in cons if c.Direction == DB.FlowDirectionType.In]
            if entree:
                cons = entree + [c for c in cons if c not in entree]
            dn1, di1, v1, _ = _cote(doc, f, cons[0])
            dn2, di2, v2, _ = _cote(doc, f, cons[1])
            typ = doc.GetElement(f.GetTypeId())
            table = u""
            methode = u""
            if typ is not None:
                p = typ.get_Parameter(DB.BuiltInParameter.RBS_PIPE_TYPE_FITTING_LOSS_TABLE_PARAM)
                table = p.AsString() if p else u""
                p = typ.get_Parameter(DB.BuiltInParameter.RBS_PIPE_TYPE_FITTING_LOSS_METHOD_PARAM)
                methode = p.AsValueString() if p else u""
            p = f.get_Parameter(DB.BuiltInParameter.RBS_PIPE_FITTING_LOSS_METHOD_SERVER_PARAM)
            if p is not None and p.AsString() and p.AsString().lower() not in (SERVEUR_TYPE, u""):
                methode = p.AsValueString() or methode
            pt = _part_type(doc, f)
            r = {
                "id": int(_id(f)), "famille": getattr(typ, "FamilyName", u"") if typ else u"",
                "taille": (f.get_Parameter(DB.BuiltInParameter.RBS_CALCULATED_SIZE).AsString() or u"") if
                f.get_Parameter(DB.BuiltInParameter.RBS_CALCULATED_SIZE) else u"",
                "piece": pt, "table": table or u"", "methode": methode or u"",
                "dn1": dn1, "dn2": dn2, "ve": v1, "vs": v2,
                "dp": _d(f, DB.BuiltInParameter.RBS_PIPE_PRESSUREDROP_PARAM, U.Pascals),
                "k_revit": None,
            }
            res.append(r)
        except Exception as ex:
            log.append(u"Raccord %s ignoré : %s" % (_id(f), ex))
    res.sort(key=lambda r: (r["piece"], -(r["dn1"] or 0), r["id"]))
    return res


def k_calcule(r, kf):
    if r["piece"] == u"Coude" and r["dn1"]:
        return k_coude(r["dn1"], kf)
    if r["piece"] == u"Réduction" and r["dn1"] and r["dn2"]:
        return k_reduc(r["dn1"], r["dn2"], kf)
    return None


def parametrer_raccords(doc, fits, log):
    """Etape du TD2 : coudes -> Long Radius Elbow, reductions -> Reducer/Coupling/Union/Increaser,
    methode 'Coefficient K a partir du tableau'. A appeler dans une transaction."""
    faits = set()
    n_inst = 0
    for f in fits:
        pt = _part_type(doc, f)
        if pt not in (u"Coude", u"Réduction"):
            continue
        p = f.get_Parameter(DB.BuiltInParameter.RBS_PIPE_FITTING_LOSS_METHOD_SERVER_PARAM)
        if p is not None and not p.IsReadOnly and (p.AsString() or u"").lower() != SERVEUR_TYPE:
            p.Set(SERVEUR_TYPE)
            n_inst += 1
        tid = _id(f.GetTypeId())
        if tid in faits:
            continue
        faits.add(tid)
        typ = doc.GetElement(f.GetTypeId())
        m = typ.get_Parameter(DB.BuiltInParameter.RBS_PIPE_TYPE_FITTING_LOSS_METHOD_PARAM)
        if m is not None and not m.IsReadOnly and u"tableau" not in (m.AsValueString() or u"").lower():
            ok = False
            for v in range(0, 8):
                try:
                    m.Set(v)
                    if u"tableau" in (m.AsValueString() or u"").lower():
                        ok = True
                        break
                except Exception:
                    pass
            if not ok:
                log.append(u"Type %s : méthode « Coefficient K à partir du tableau » à choisir à la main." % nom_el(typ))
        t = typ.get_Parameter(DB.BuiltInParameter.RBS_PIPE_TYPE_FITTING_LOSS_TABLE_PARAM)
        cible = TABLE_COUDE if pt == u"Coude" else TABLE_REDUC
        if t is not None and not t.IsReadOnly:
            t.Set(cible)
            log.append(u"%s : %s → %s" % (pt, getattr(typ, "FamilyName", u"") + u" : " + nom_el(typ), cible))
    if n_inst:
        log.append(u"%d raccord(s) remis sur « Utiliser la définition du type »." % n_inst)
    return len(faits)


def lire_rapport_html(chemin):
    """Resume 'coefficient de perte de charge des raccords' du rapport HTML Revit -> {id: {k, dp}}"""
    t = io.open(chemin, encoding="utf-8", errors="replace").read()
    res = {}
    entete = None

    def txt(c):
        c = re.sub(r"<[^>]+>", u"", c)
        return c.replace(u"&nbsp;", u" ").replace(u"&amp;", u"&").strip()

    def nombre(s):
        m = re.search(r"-?\d+(?:[.,]\d+)?(?:[eE]-?\d+)?", s or u"")
        return float(m.group(0).replace(u",", u".")) if m else None
    for tr in re.findall(r"<tr[^>]*>(.*?)</tr>", t, re.S | re.I):
        cells = [txt(c) for c in re.findall(r"<t[hd][^>]*>(.*?)</t[hd]>", tr, re.S | re.I)]
        if not cells:
            continue
        low = [c.lower() for c in cells]
        if any(u"coefficient k" in c for c in low) and any(c.startswith(u"id") for c in low):
            entete = low
            continue
        if entete is None:
            continue
        try:
            iid = [i for i, c in enumerate(entete) if c.startswith(u"id")][0]
            ik = [i for i, c in enumerate(entete) if u"coefficient k" in c and u"tableau" not in c][0]
            idp = [i for i, c in enumerate(entete) if u"perte" in c]
            el = int(nombre(cells[iid]))
            res[el] = {"k": nombre(cells[ik]), "dp": nombre(cells[idp[0]]) if idp else None}
        except Exception:
            continue
    return res


# ================================================================== EXPORT XLSX
NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NSR = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"


def col(i):
    """0 -> A"""
    s = u""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _x(t):
    t = u"%s" % t
    t = u"".join(c for c in t if c in u"\t\n\r" or ord(c) >= 32)
    return t.replace(u"&", u"&amp;").replace(u"<", u"&lt;").replace(u">", u"&gt;").replace(u'"', u"&quot;")


class Styles(object):
    """Registre de styles : style(police, fond, format, bordure, alignement) -> index cellXfs"""

    def __init__(self):
        self.fonts = [u'<font><sz val="10"/><name val="Arial"/></font>']
        self.fills = [u'<fill><patternFill patternType="none"/></fill>', u'<fill><patternFill patternType="gray125"/></fill>']
        self.borders = [u'<border><left/><right/><top/><bottom/><diagonal/></border>',
                        u'<border><left style="thin"><color rgb="FFC9D3DC"/></left><right style="thin"><color rgb="FFC9D3DC"/></right>'
                        u'<top style="thin"><color rgb="FFC9D3DC"/></top><bottom style="thin"><color rgb="FFC9D3DC"/></bottom><diagonal/></border>']
        self.numfmts = {}
        self.xfs = [u'<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>']
        self.cache = {}

    def _font(self, bold=False, italic=False, color=None, size=10):
        x = u"<font>%s%s<sz val=\"%s\"/>%s<name val=\"Arial\"/></font>" % (
            u"<b/>" if bold else u"", u"<i/>" if italic else u"", size, (u'<color rgb="FF%s"/>' % color) if color else u"")
        if x not in self.fonts:
            self.fonts.append(x)
        return self.fonts.index(x)

    def _fill(self, color):
        if not color:
            return 0
        x = u'<fill><patternFill patternType="solid"><fgColor rgb="FF%s"/><bgColor indexed="64"/></patternFill></fill>' % color
        if x not in self.fills:
            self.fills.append(x)
        return self.fills.index(x)

    def _fmt(self, f):
        builtin = {None: 0, u"General": 0, u"0": 1, u"0.00": 2, u"0%": 9, u"0.00%": 10}
        if f in builtin:
            return builtin[f]
        if f not in self.numfmts:
            self.numfmts[f] = 164 + len(self.numfmts)
        return self.numfmts[f]

    def get(self, bold=False, italic=False, color=None, size=10, fill=None, fmt=None, border=True, h=None, wrap=False):
        key = (bold, italic, color, size, fill, fmt, border, h, wrap)
        if key in self.cache:
            return self.cache[key]
        al = u""
        if h or wrap:
            al = u'<alignment%s%s vertical="center"/>' % ((u' horizontal="%s"' % h) if h else u"",
                                                           u' wrapText="1"' if wrap else u"")
        x = (u'<xf numFmtId="%d" fontId="%d" fillId="%d" borderId="%d" xfId="0" applyNumberFormat="1" applyFont="1" '
             u'applyFill="1" applyBorder="1"%s>%s</xf>') % (
            self._fmt(fmt), self._font(bold, italic, color, size), self._fill(fill), 1 if border else 0,
            u' applyAlignment="1"' if al else u"", al)
        self.xfs.append(x)
        self.cache[key] = len(self.xfs) - 1
        return self.cache[key]

    def xml(self):
        nf = u"".join(u'<numFmt numFmtId="%d" formatCode="%s"/>' % (i, _x(f)) for f, i in sorted(self.numfmts.items(), key=lambda x: x[1]))
        dxf = (u'<dxfs count="3">'
               u'<dxf><font><color rgb="FF1E6B3A"/></font><fill><patternFill><bgColor rgb="FFD9F2E2"/></patternFill></fill></dxf>'
               u'<dxf><font><color rgb="FF8A5A00"/></font><fill><patternFill><bgColor rgb="FFFCEBC4"/></patternFill></fill></dxf>'
               u'<dxf><font><color rgb="FF9C2A22"/></font><fill><patternFill><bgColor rgb="FFF8D7D4"/></patternFill></fill></dxf>'
               u'</dxfs>')
        return (u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="%s">'
                u'<numFmts count="%d">%s</numFmts>'
                u'<fonts count="%d">%s</fonts><fills count="%d">%s</fills><borders count="%d">%s</borders>'
                u'<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
                u'<cellXfs count="%d">%s</cellXfs>'
                u'<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>%s</styleSheet>') % (
            NS, len(self.numfmts), nf, len(self.fonts), u"".join(self.fonts), len(self.fills), u"".join(self.fills),
            len(self.borders), u"".join(self.borders), len(self.xfs), u"".join(self.xfs), dxf)


# couleurs du classeur
NAVY = u"1F3A5F"
TEAL = u"2E7D8C"
GRIS = u"EEF2F6"
JAUNE = u"FFF2CC"
BLEU = u"0000FF"
VERT_F = u"E2EFDA"
VERT_T = u"008000"
MUTED = u"5B6B78"


class Feuille(object):
    def __init__(self, nom, tab=None):
        self.nom = nom
        self.cells = {}      # (r, c) -> (valeur, style) ; valeur = nombre | texte | ("f", formule, resultat)
        self.largeurs = {}
        self.fusions = []
        self.liens = []
        self.cf = []
        self.figer = None
        self.tab = tab
        self.hauteurs = {}

    def set(self, r, c, v, s=0):
        self.cells[(r, c)] = (v, s)

    def f(self, r, c, formule, resultat=None, s=0):
        self.cells[(r, c)] = (("f", formule, resultat), s)

    def _cell(self, r, c, v, s):
        ref = u"%s%d" % (col(c), r)
        st = u' s="%d"' % s if s else u""
        if isinstance(v, tuple) and v and v[0] == "f":
            fo, res = v[1], v[2]
            if res is None or (isinstance(res, float) and (math.isnan(res) or math.isinf(res))):
                return u'<c r="%s"%s><f>%s</f></c>' % (ref, st, _x(fo))
            if isinstance(res, basestring):
                return u'<c r="%s"%s t="str"><f>%s</f><v>%s</v></c>' % (ref, st, _x(fo), _x(res))
            return u'<c r="%s"%s><f>%s</f><v>%s</v></c>' % (ref, st, _x(fo), repr(float(res)))
        if v is None or v == u"":
            return u'<c r="%s"%s/>' % (ref, st)
        if isinstance(v, bool):
            v = u"Oui" if v else u"Non"
        if isinstance(v, (int, long, float)):
            return u'<c r="%s"%s><v>%s</v></c>' % (ref, st, repr(float(v)) if isinstance(v, float) else v)
        return u'<c r="%s"%s t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (ref, st, _x(v))

    def xml(self):
        x = [u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="%s" xmlns:r="%s">' % (NS, NSR)]
        if self.tab:
            x.append(u'<sheetPr><tabColor rgb="FF%s"/></sheetPr>' % self.tab)
        x.append(u'<sheetViews><sheetView workbookViewId="0" showGridLines="0">')
        if self.figer:
            r, c = self.figer
            x.append(u'<pane%s%s topLeftCell="%s%d" activePane="bottomRight" state="frozen"/>' % (
                (u' xSplit="%d"' % c) if c else u"", (u' ySplit="%d"' % (r - 1)) if r > 1 else u"", col(c), r))
        x.append(u'</sheetView></sheetViews><sheetFormatPr defaultRowHeight="15"/>')
        if self.largeurs:
            x.append(u"<cols>")
            for c in sorted(self.largeurs):
                x.append(u'<col min="%d" max="%d" width="%.1f" customWidth="1"/>' % (c + 1, c + 1, self.largeurs[c]))
            x.append(u"</cols>")
        x.append(u"<sheetData>")
        lignes = {}
        for (r, c) in self.cells:
            lignes.setdefault(r, []).append(c)
        for r in sorted(lignes):
            ht = (u' ht="%s" customHeight="1"' % self.hauteurs[r]) if r in self.hauteurs else u""
            x.append(u'<row r="%d"%s>' % (r, ht))
            for c in sorted(lignes[r]):
                v, s = self.cells[(r, c)]
                x.append(self._cell(r, c, v, s))
            x.append(u"</row>")
        x.append(u"</sheetData>")
        if self.fusions:
            x.append(u'<mergeCells count="%d">%s</mergeCells>' % (len(self.fusions), u"".join(u'<mergeCell ref="%s"/>' % m for m in self.fusions)))
        prio = 1
        for ref, premier in self.cf:
            x.append(u'<conditionalFormatting sqref="%s">' % ref)
            for dxf, cond in ((0, u"ABS(%s)&lt;=0.001"), (1, u"ABS(%s)&lt;=0.01"), (2, u"ABS(%s)&gt;0.01")):
                x.append(u'<cfRule type="expression" dxfId="%d" priority="%d" stopIfTrue="1"><formula>AND(ISNUMBER(%s),%s)</formula></cfRule>'
                         % (dxf, prio, premier, cond % premier))
                prio += 1
            x.append(u"</conditionalFormatting>")
        if self.liens:
            x.append(u"<hyperlinks>%s</hyperlinks>" % u"".join(
                u'<hyperlink ref="%s" location="%s" display="%s"/>' % (ref, _x(loc), _x(disp)) for ref, loc, disp in self.liens))
        x.append(u'<pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/>')
        x.append(u"</worksheet>")
        return u"".join(x)


def nom_feuille(nom, pris):
    n = re.sub(u"[\\[\\]\\*\\?/\\\\:]", u"-", nom).strip()[:31] or u"Feuille"
    base, k = n, 2
    while n.lower() in pris:
        suf = u" (%d)" % k
        n = base[:31 - len(suf)] + suf
        k += 1
    pris.add(n.lower())
    return n


def q(nom):
    return u"'%s'" % nom.replace(u"'", u"''")


def _interp_formule(x, X, Y, n):
    i = u"MAX(1,MIN(IFERROR(MATCH(%s,%s,1),1),%d))" % (x, X, n - 1)
    return (u"INDEX({Y},{i})+(INDEX({Y},{i}+1)-INDEX({Y},{i}))*({x}-INDEX({X},{i}))/(INDEX({X},{i}+1)-INDEX({X},{i}))"
            .format(Y=Y, X=X, i=i, x=x))


def _colebrook_formule(re_, eps, kc, dint, n=8):
    g = u"0.02"
    for _ in range(n):
        g = u"1/(-2*LOG10(2.51/(%s*SQRT(%s))+%s/(%s*%s)))^2" % (re_, g, eps, kc, dint)
    return g


def feuille_cas(S, cas, nom, conclusion):
    fe = Feuille(nom, tab=TEAL)
    titre = S.get(bold=True, size=16, color=NAVY, border=False)
    sous = S.get(italic=True, color=MUTED, border=False)
    section = S.get(bold=True, color=u"FFFFFF", fill=TEAL, border=False)
    lab = S.get(bold=True, fill=GRIS)
    head = S.get(bold=True, color=u"FFFFFF", fill=NAVY, h=u"center")
    unite = S.get(italic=True, color=MUTED, border=False)
    lignes = cas["lignes"]
    n = len(lignes)
    last = max(n, 6)
    fe.largeurs[0] = 34
    for c in range(1, last + 1):
        fe.largeurs[c] = 12.5
    fe.set(1, 0, u"TD1 – Pertes de charge linéaires : %s" % cas["nom"], titre)
    fe.hauteurs[1] = 24
    fe.set(2, 0, u"Segment : %s   ·   Fluide : %s   ·   Source : %s" % (cas.get("segment") or u"-", cas.get("fluide") or u"-",
                                                                         cas.get("source") or u"-"), sous)

    def entree(r, label, v, fmt, note):
        fe.set(r, 0, label, lab)
        fe.set(r, 1, v, S.get(color=BLEU, fill=JAUNE, fmt=fmt))
        fe.set(r, 2, note, unite)
    fe.set(4, 0, u"  DONNÉES D'ENTRÉE (cases jaunes = modifiables)", section)
    for c in range(1, last + 1):
        fe.set(4, c, None, section)
    entree(5, u"Qv (l/s)", cas["qv"], u"0.000", u"débit du tronçon")
    entree(6, u"θ (°C)", cas["theta"], u"0.00", u"température du fluide")
    entree(7, u"ε (mm)", cas["eps"], u"0.00000", u"rugosité du segment")
    entree(8, u"ρ (kg/m³)", cas["rho"], u"0.0000", u"masse volumique")
    entree(9, u"µ (Pa.s)", cas["mu"], u"0.000000000", u"viscosité dynamique")
    entree(10, u"Constante Colebrook", cas["kc"], u"0.00", u"3,7 (Revit) ou 3,71 (cours)")

    fe.set(12, 0, u"  CALCUL (Darcy-Weisbach + Colebrook)", section)
    for c in range(1, last + 1):
        fe.set(12, c, None, section)
    noms = [(13, u"DN"), (14, u"Qv (l/s)"), (15, u"θ (°C)"), (16, u"ε (mm)"), (17, u"ρ (kg/m³)"), (18, u"µ (Pa.s)"),
            (19, u"Dext (mm)"), (20, u"Dint (mm)"), (21, u"v (m/s)"), (22, u"Re"), (23, u"Régime"),
            (24, u"λ (Colebrook)"), (25, u"j (Pa/m)")]
    for r, t in noms:
        fe.set(r, 0, t, head if r == 13 else (S.get(bold=True, fill=VERT_F) if r in (24, 25) else lab))
    fe.set(27, 0, u"  VALEURS REVIT (lues dans la maquette)", section)
    for c in range(1, last + 1):
        fe.set(27, c, None, section)
    for r, t in [(28, u"λ Revit (facteur de frottement)"), (29, u"j Revit (frottement, Pa/m)"), (30, u"Re Revit"),
                 (31, u"v Revit (m/s)"), (32, u"Écart λ"), (33, u"Écart j"), (34, u"Écart Re")]:
        fe.set(r, 0, t, S.get(bold=True, fill=GRIS) if r < 32 else S.get(bold=True, fill=u"DDE7F0"))
    for k, l in enumerate(lignes):
        c = k + 1
        L = col(c)
        rv = l.get("revit") or {}
        res = calc(cas["qv"] if not rv.get("qv") else rv["qv"], cas["rho"], cas["mu"], cas["eps"], cas["kc"], l["dint"]) or {}
        fe.set(13, c, l["dn"], head)
        qrev = rv.get("qv")
        if qrev and abs(qrev - cas["qv"]) / max(cas["qv"], 1e-9) > 0.001:
            fe.set(14, c, qrev, S.get(color=BLEU, fill=JAUNE, fmt=u"0.000"))
        else:
            fe.f(14, c, u"$B$5", cas["qv"], S.get(fmt=u"0.000"))
        fe.f(15, c, u"$B$6", cas["theta"], S.get(fmt=u"0.00"))
        fe.f(16, c, u"$B$7", cas["eps"], S.get(fmt=u"0.00000"))
        fe.f(17, c, u"$B$8", cas["rho"], S.get(fmt=u"0.0000"))
        fe.f(18, c, u"$B$9", cas["mu"], S.get(fmt=u"0.000000000"))
        fe.set(19, c, l.get("dext"), S.get(color=BLEU, fill=JAUNE, fmt=u"0.0"))
        fe.set(20, c, l["dint"], S.get(color=BLEU, fill=JAUNE, fmt=u"0.0"))
        fe.f(21, c, u"({L}14/1000)/(PI()*({L}20/1000)^2/4)".format(L=L), res.get("v"), S.get(fmt=u"0.000"))
        fe.f(22, c, u"{L}17*{L}21*({L}20/1000)/{L}18".format(L=L), res.get("re"), S.get(fmt=u"#,##0"))
        fe.f(23, c, u'IF({L}22<2000,"Laminaire",IF({L}22<4000,"Transitoire","Turbulent"))'.format(L=L), res.get("regime"),
             S.get(h=u"center", color=MUTED))
        fe.f(24, c, u"IF({L}22<2000,64/{L}22,{F})".format(L=L, F=_colebrook_formule(L + u"22", L + u"16", u"$B$10", L + u"20")),
             res.get("lam"), S.get(bold=True, fill=VERT_F, fmt=u"0.000000"))
        fe.f(25, c, u"{L}24/({L}20/1000)*{L}21^2/2*{L}17".format(L=L), res.get("j"), S.get(bold=True, fill=VERT_F, fmt=u"0.000"))
        fe.set(28, c, rv.get("lam"), S.get(color=BLEU, fill=JAUNE, fmt=u"0.000000"))
        fe.set(29, c, rv.get("j"), S.get(color=BLEU, fill=JAUNE, fmt=u"0.000"))
        fe.set(30, c, rv.get("re"), S.get(color=BLEU, fill=JAUNE, fmt=u"#,##0"))
        fe.set(31, c, rv.get("v"), S.get(color=BLEU, fill=JAUNE, fmt=u"0.000"))
        for r, a, b in [(32, 24, 28), (33, 25, 29), (34, 22, 30)]:
            ra = {24: res.get("lam"), 25: res.get("j"), 22: res.get("re")}[a]
            rb = {28: rv.get("lam"), 29: rv.get("j"), 30: rv.get("re")}[b]
            fe.f(r, c, u'IF(OR({L}{b}="",{L}{b}=0),"",({L}{a}-{L}{b})/{L}{b})'.format(L=L, a=a, b=b),
                 ecart(ra, rb) if ecart(ra, rb) is not None else u"", S.get(fmt=u"0.000%", h=u"center"))
    if n:
        fe.cf.append((u"B32:%s34" % col(n), u"B32"))
    r = 36
    fe.set(r, 0, u"  CONCLUSION", section)
    for c in range(1, last + 1):
        fe.set(r, c, None, section)
    for i, t in enumerate(conclusion):
        fe.set(r + 1 + i, 0, t, S.get(border=False))
    fe.set(r + 2 + len(conclusion), 0, u"Écarts : vert ≤ 0,1 %  ·  orange ≤ 1 %  ·  rouge > 1 %.  λ par Colebrook (8 itérations depuis λ = 0,02) : "
           u"pas besoin d'activer le calcul itératif.", S.get(italic=True, color=MUTED, border=False))
    fe.figer = (14, 1)
    return fe


def conclusion_cas(cas):
    lig = []
    el = [(l["dn"], calc(l["revit"].get("qv") or cas["qv"], cas["rho"], cas["mu"], cas["eps"], cas["kc"], l["dint"]), l["revit"])
          for l in cas["lignes"] if l.get("revit")]
    el = [(dn, r, rv) for dn, r, rv in el if r and rv.get("lam")]
    if not el:
        return [u"Pas encore de valeurs Revit : clique sur « Lire les canalisations » dans Revit."]
    def mx(cle_calc, cle_rev):
        best = (0, None)
        for dn, r, rv in el:
            e = ecart(r[cle_calc], rv.get(cle_rev))
            if e is not None and abs(e) > abs(best[0]):
                best = (e, dn)
        return best
    el_lam, dn_lam = mx("lam", "lam")
    el_j, dn_j = mx("j", "j")
    el_re, dn_re = mx("re", "re")
    lig.append(u"Écart max sur λ : %.4f %% (DN%s)  ·  sur Re : %.4f %% (DN%s)  ·  sur j : %.3f %% (DN%s)." % (
        el_lam * 100, dn_lam, el_re * 100, dn_re, el_j * 100, dn_j))
    if abs(el_lam) < 0.001 and abs(el_re) < 0.001:
        lig.append(u"Revit applique bien Darcy-Weisbach avec Colebrook : les écarts sur λ et Re sont négligeables.")
    else:
        lig.append(u"Écart notable : vérifier ρ, µ, la température du système et la rugosité ε lues dans Revit.")
    petits = [dn for dn, r, rv in el if rv.get("j") is not None and rv["j"] < 10 and abs(ecart(r["j"], rv["j"]) or 0) > 0.001]
    if petits:
        lig.append(u"Les écarts sur j en DN%s viennent de l'arrondi d'affichage de Revit (0,01 Pa/m) sur de très petites valeurs."
                   % u", DN".join(str(d) for d in petits))
    return lig


def exporter(chemin, etat, kf, projet, log):
    S = Styles()
    pris = set()
    feuilles = []
    titre = S.get(bold=True, size=18, color=NAVY, border=False)
    sous = S.get(italic=True, color=MUTED, border=False)
    section = S.get(bold=True, color=u"FFFFFF", fill=TEAL, border=False)
    head = S.get(bold=True, color=u"FFFFFF", fill=NAVY, h=u"center", wrap=True)
    lab = S.get(bold=True, fill=GRIS)
    txt = S.get(border=False)
    lien = S.get(color=u"0563C1", border=False)

    # ---------------- accueil
    acc = Feuille(nom_feuille(u"Accueil", pris), tab=NAVY)
    feuilles.append(acc)
    acc.largeurs = {0: 4, 1: 46, 2: 60}
    acc.set(1, 1, u"Pertes de charge – ENF117 TD1 / TD2", titre)
    acc.hauteurs[1] = 28
    acc.set(2, 1, u"Projet : %s   ·   généré par Allan BIM le %s" % (projet, datetime.datetime.now().strftime(u"%d/%m/%Y %H:%M")), sous)
    acc.set(4, 1, u"  LÉGENDE", section)
    acc.set(4, 2, None, section)
    acc.set(5, 1, u"Valeur saisie ou lue dans Revit (modifiable)", S.get(color=BLEU, fill=JAUNE))
    acc.set(5, 2, u"Change-la : tout se recalcule.", txt)
    acc.set(6, 1, u"Résultat (λ, j, k…)", S.get(bold=True, fill=VERT_F))
    acc.set(6, 2, u"Formule : ne pas écraser.", txt)
    acc.set(7, 1, u"Lien vers une autre feuille", S.get(color=VERT_T))
    acc.set(7, 2, u"Valeur reprise d'une autre feuille.", txt)
    acc.set(8, 1, u"Écart  ≤ 0,1 %  /  ≤ 1 %  /  > 1 %", lab)
    acc.set(8, 2, u"vert / orange / rouge", txt)
    acc.set(10, 1, u"  SOMMAIRE", section)
    acc.set(10, 2, None, section)

    # ---------------- fluide Thermexcel
    th = Feuille(nom_feuille(u"Eau TD 1 (Thermexcel)", pris), tab=u"7A9CB8")
    feuilles.append(th)
    th.largeurs = {0: 14, 1: 14, 2: 14, 3: 4, 4: 60}
    th.set(1, 0, u"Eau TD 1 – valeurs Thermexcel (TD p.31)", S.get(bold=True, size=14, color=NAVY, border=False))
    for c, h in enumerate([u"θ (°C)", u"ρ (kg/m³)", u"µ (Pa.s)"]):
        th.set(3, c, h, head)
    for i, (t, r, m) in enumerate(THERMEXCEL):
        th.set(4 + i, 0, t, S.get(color=BLEU, fill=JAUNE, fmt=u"0"))
        th.set(4 + i, 1, r, S.get(color=BLEU, fill=JAUNE, fmt=u"0.00"))
        th.set(4 + i, 2, m, S.get(color=BLEU, fill=JAUNE, fmt=u"0.000000"))
    th.set(8, 0, u"Interpolation pour une autre température :", S.get(bold=True, border=False))
    th.set(9, 0, u"θ (°C)", lab)
    th.set(9, 1, 54.0, S.get(color=BLEU, fill=JAUNE, fmt=u"0.00"))
    r_, m_ = thermexcel(54.0)
    th.set(10, 0, u"ρ (kg/m³)", lab)
    th.f(10, 1, _interp_formule(u"B9", u"$A$4:$A$6", u"$B$4:$B$6", 3), r_, S.get(bold=True, fill=VERT_F, fmt=u"0.00"))
    th.set(11, 0, u"µ (Pa.s)", lab)
    th.f(11, 1, _interp_formule(u"B9", u"$A$4:$A$6", u"$C$4:$C$6", 3), m_, S.get(bold=True, fill=VERT_F, fmt=u"0.000000"))

    # ---------------- un onglet par cas
    noms_cas = []
    for cas in etat.get("cas", []):
        nom = nom_feuille(u"TD1 - " + cas["nom"], pris)
        noms_cas.append((nom, cas))
        feuilles.append(feuille_cas(S, cas, nom, conclusion_cas(cas)))

    # ---------------- synthese TD1
    if noms_cas:
        sy = Feuille(nom_feuille(u"TD1 Synthèse", pris), tab=TEAL)
        feuilles.append(sy)
        sy.set(1, 0, u"TD1 – Synthèse : λ et j selon le fluide / la température / le segment", S.get(bold=True, size=14, color=NAVY, border=False))
        sy.largeurs[0] = 10
        dns = sorted(set(l["dn"] for _, c in noms_cas for l in c["lignes"]))
        sy.set(3, 0, u"DN", head)
        sy.set(4, 0, None, head)
        for k, (nom, cas) in enumerate(noms_cas):
            c1 = 1 + 2 * k
            sy.set(3, c1, cas["nom"], head)
            sy.set(3, c1 + 1, None, head)
            sy.fusions.append(u"%s3:%s3" % (col(c1), col(c1 + 1)))
            sy.set(4, c1, u"λ", head)
            sy.set(4, c1 + 1, u"j (Pa/m)", head)
            sy.largeurs[c1] = 14
            sy.largeurs[c1 + 1] = 14
            par = dict((l["dn"], l) for l in cas["lignes"])
            for i, dn in enumerate(dns):
                r = 5 + i
                sy.set(r, 0, dn, lab)
                l = par.get(dn)
                res = calc(l["revit"].get("qv") or cas["qv"], cas["rho"], cas["mu"], cas["eps"], cas["kc"], l["dint"]) if l else None
                for cc, row, cle, fmt in ((c1, 24, "lam", u"0.000000"), (c1 + 1, 25, "j", u"0.000")):
                    sy.f(r, cc, u'IFERROR(INDEX({S}!$B${row}:$ZZ${row},MATCH($A{r},{S}!$B$13:$ZZ$13,0)),"")'.format(S=q(nom), row=row, r=r),
                         res[cle] if res else u"", S.get(color=VERT_T, fmt=fmt))
        sy.set(6 + len(dns), 0, u"Valeurs reprises des feuilles TD1 (formules INDEX/EQUIV) : modifie un cas, la synthèse suit.",
               S.get(italic=True, color=MUTED, border=False))
        sy.figer = (5, 1)

    # ---------------- TD2 tables k
    tk = Feuille(nom_feuille(u"TD2 Tables k", pris), tab=u"B8642E")
    feuilles.append(tk)
    tk.set(1, 0, u"TD2 – Tables des coefficients k (PipeKFactors.xml)", S.get(bold=True, size=14, color=NAVY, border=False))
    tk.largeurs = {0: 16, 1: 12, 2: 4, 3: 12, 4: 12, 5: 4, 6: 10, 7: 14, 8: 14}
    tk.set(3, 0, TABLE_COUDE, S.get(bold=True, border=False))
    tk.set(4, 0, u"Y1Axis (pouces)", head)
    tk.set(4, 1, u"Data (k)", head)
    Xe, Ye = kf[TABLE_COUDE]
    for i, (x, y) in enumerate(zip(Xe, Ye)):
        tk.set(5 + i, 0, x, S.get(color=BLEU, fill=JAUNE, fmt=u"0.00"))
        tk.set(5 + i, 1, y, S.get(color=BLEU, fill=JAUNE, fmt=u"0.00"))
    tk.set(3, 3, TABLE_REDUC, S.get(bold=True, border=False))
    tk.set(4, 3, u"D1/D2", head)
    tk.set(4, 4, u"k", head)
    Xr, Yr = kf[TABLE_REDUC]
    for i, (x, y) in enumerate(zip(Xr, Yr)):
        tk.set(5 + i, 3, x, S.get(color=BLEU, fill=JAUNE, fmt=u"0.00"))
        tk.set(5 + i, 4, y, S.get(color=BLEU, fill=JAUNE, fmt=u"0.00"))
    XE = u"%s!$A$5:$A$%d" % (q(tk.nom), 4 + len(Xe))
    YE = u"%s!$B$5:$B$%d" % (q(tk.nom), 4 + len(Xe))
    XR = u"%s!$D$5:$D$%d" % (q(tk.nom), 4 + len(Xr))
    YR = u"%s!$E$5:$E$%d" % (q(tk.nom), 4 + len(Xr))
    tk.set(3, 6, u"k des coudes Long Radius Elbow (interpolation)", S.get(bold=True, border=False))
    tk.set(4, 6, u"DN", head)
    tk.set(4, 7, u"Pouces", head)
    tk.set(4, 8, u"k", head)
    tk.set(2, 6, u"1 mm =", S.get(border=False, h=u"right"))
    tk.set(2, 7, POUCE, S.get(color=BLEU, fill=JAUNE, fmt=u"0.0000000"))
    tk.set(2, 8, u"pouce", S.get(border=False))
    for i, dn in enumerate(DN_COUDES):
        r = 5 + i
        tk.set(r, 6, dn, S.get(color=BLEU, fill=JAUNE))
        tk.f(r, 7, u"G%d*$H$2" % r, dn * POUCE, S.get(fmt=u"0.000000"))
        tk.f(r, 8, _interp_formule(u"H%d" % r, u"$A$5:$A$%d" % (4 + len(Xe)), u"$B$5:$B$%d" % (4 + len(Xe)), len(Xe)),
             k_coude(dn, kf), S.get(bold=True, fill=VERT_F, fmt=u"0.00000000"))
    tk.set(6 + len(DN_COUDES), 6, u"Contrôle TD p.33 : DN20 → 0,787402 pouce → k = 0,39551176", S.get(italic=True, color=MUTED, border=False))

    # ---------------- TD2 raccords
    td2 = etat.get("td2") or []
    if td2:
        tr = Feuille(nom_feuille(u"TD2 Raccords", pris), tab=u"B8642E")
        feuilles.append(tr)
        tr.set(1, 0, u"TD2 – Pertes de charge singulières : Revit / calcul", S.get(bold=True, size=14, color=NAVY, border=False))
        tr.set(2, 0, u"ρ (kg/m³)", lab)
        rho2 = etat.get("td2_rho") or 985.9364
        tr.set(2, 1, rho2, S.get(color=BLEU, fill=JAUNE, fmt=u"0.0000"))
        tr.set(2, 2, u"ΔP = k × v²/2 × ρ", S.get(italic=True, color=MUTED, border=False))
        hd = [u"ID", u"Famille", u"Taille", u"Pièce", u"Tableau K (Revit)", u"DN entrée", u"DN sortie", u"Ve (m/s)", u"Vs (m/s)",
              u"ΔP Revit (Pa)", u"K Revit (rapport)", u"k calculé", u"ΔP calc. avec Ve", u"ΔP calc. avec Vs",
              u"Écart k", u"Écart ΔP (Ve)", u"Écart ΔP (Vs)"]
        larg = [10, 26, 22, 11, 28, 9, 9, 10, 10, 12, 12, 11, 13, 13, 10, 12, 12]
        for c, h in enumerate(hd):
            tr.set(4, c, h, head)
            tr.largeurs[c] = larg[c]
        tr.hauteurs[4] = 32
        for i, r0 in enumerate(td2):
            r = 5 + i
            kc_ = k_calcule(r0, kf)
            tr.set(r, 0, r0["id"], S.get(color=BLEU, fill=JAUNE))
            tr.set(r, 1, r0["famille"], S.get())
            tr.set(r, 2, r0["taille"], S.get())
            tr.set(r, 3, r0["piece"], S.get(h=u"center"))
            tr.set(r, 4, r0["table"], S.get())
            tr.set(r, 5, r0["dn1"], S.get(color=BLEU, fill=JAUNE))
            tr.set(r, 6, r0["dn2"], S.get(color=BLEU, fill=JAUNE))
            tr.set(r, 7, r0["ve"], S.get(color=BLEU, fill=JAUNE, fmt=u"0.000"))
            tr.set(r, 8, r0["vs"], S.get(color=BLEU, fill=JAUNE, fmt=u"0.000"))
            tr.set(r, 9, r0["dp"], S.get(color=BLEU, fill=JAUNE, fmt=u"0.000"))
            tr.set(r, 10, r0.get("k_revit"), S.get(color=BLEU, fill=JAUNE, fmt=u"0.000000"))
            fk = (u'IF(D{r}="Coude",{E},IF(D{r}="Réduction",{R},""))').format(
                r=r, E=_interp_formule(u"(F%d*%s!$H$2)" % (r, q(tk.nom)), XE, YE, len(Xe)),
                R=_interp_formule(u"MIN(4,MAX(F{r},G{r})/MIN(F{r},G{r}))".format(r=r), XR, YR, len(Xr)))
            tr.f(r, 11, fk, kc_ if kc_ is not None else u"", S.get(bold=True, fill=VERT_F, fmt=u"0.00000"))
            dpe = kc_ * r0["ve"] ** 2 / 2 * rho2 if kc_ is not None and r0["ve"] else None
            dps = kc_ * r0["vs"] ** 2 / 2 * rho2 if kc_ is not None and r0["vs"] else None
            tr.f(r, 12, u'IF(OR(L{r}="",H{r}=""),"",L{r}*H{r}^2/2*$B$2)'.format(r=r), dpe if dpe is not None else u"",
                 S.get(bold=True, fill=VERT_F, fmt=u"0.000"))
            tr.f(r, 13, u'IF(OR(L{r}="",I{r}=""),"",L{r}*I{r}^2/2*$B$2)'.format(r=r), dps if dps is not None else u"",
                 S.get(bold=True, fill=VERT_F, fmt=u"0.000"))
            for c, a, b, va, vb in ((14, u"L", u"K", kc_, r0.get("k_revit")), (15, u"M", u"J", dpe, r0["dp"]), (16, u"N", u"J", dps, r0["dp"])):
                e = ecart(va, vb)
                tr.f(r, c, u'IF(OR({a}{r}="",{b}{r}="",{b}{r}=0),"",({a}{r}-{b}{r})/{b}{r})'.format(a=a, b=b, r=r),
                     e if e is not None else u"", S.get(fmt=u"0.0%", h=u"center"))
        tr.cf.append((u"O5:Q%d" % (4 + len(td2)), u"O5"))
        rn = 6 + len(td2)
        for i, t in enumerate([
                u"DN entrée/sortie et vitesses lues sur les canalisations raccordées (Revit ne les affiche pas dans le rapport).",
                u"k calculé : coude → interpolation sur le DN en pouces ; réduction → interpolation sur D1/D2 (grand DN / petit DN).",
                u"Compare « ΔP calc. avec Ve » et « avec Vs » à la valeur Revit pour savoir quelle vitesse Revit utilise.",
                u"K Revit : importé du rapport HTML (Analyser > Rapport sur la perte de charge dans les canalisations)."]):
            tr.set(rn + i, 0, t, S.get(italic=True, color=MUTED, border=False))
        tr.figer = (5, 1)

    # sommaire
    for i, fe in enumerate(feuilles[1:]):
        r = 11 + i
        acc.set(r, 1, fe.nom, lien)
        acc.liens.append((u"B%d" % r, u"%s!A1" % q(fe.nom), fe.nom))
        desc = u""
        if fe.nom.startswith(u"TD1 - "):
            desc = u"Calcul λ et j + comparaison avec Revit"
        elif fe.nom.startswith(u"TD1 Synth"):
            desc = u"Tous les cas côte à côte"
        elif u"Thermexcel" in fe.nom:
            desc = u"Propriétés de l'eau (ρ, µ) et interpolation"
        elif u"Tables k" in fe.nom:
            desc = u"Tables PipeKFactors + k des coudes interpolés"
        elif u"Raccords" in fe.nom:
            desc = u"k calculé, ΔP et écarts pour chaque raccord"
        acc.set(r, 2, desc, txt)

    # ---------------- ecriture du zip
    n = len(feuilles)
    ct = [u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          u'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          u'<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
          u'<Default Extension="xml" ContentType="application/xml"/>'
          u'<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
          u'<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>']
    for i in range(n):
        ct.append(u'<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % (i + 1))
    ct.append(u"</Types>")
    wb = [u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="%s" xmlns:r="%s"><sheets>' % (NS, NSR)]
    rels = [u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            u'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
    for i, fe in enumerate(feuilles):
        wb.append(u'<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (_x(fe.nom), i + 1, i + 1))
        rels.append(u'<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
                    u'Target="worksheets/sheet%d.xml"/>' % (i + 1, i + 1))
    wb.append(u'</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>')
    rels.append(u'<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' % (n + 1))
    rels.append(u"</Relationships>")
    fichiers = [("[Content_Types].xml", u"".join(ct)),
                ("_rels/.rels", u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                 u'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                 u'<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
                 u'</Relationships>'),
                ("xl/workbook.xml", u"".join(wb)),
                ("xl/_rels/workbook.xml.rels", u"".join(rels))]
    for i, fe in enumerate(feuilles):
        fichiers.append(("xl/worksheets/sheet%d.xml" % (i + 1), fe.xml()))
    fichiers.append(("xl/styles.xml", S.xml()))
    d = os.path.dirname(chemin)
    if d and not os.path.isdir(d):
        os.makedirs(d)
    z = zipfile.ZipFile(chemin, "w", zipfile.ZIP_DEFLATED)
    try:
        for nomf, contenu in fichiers:
            z.writestr(nomf, contenu.encode("utf-8"))
    finally:
        z.close()
    log.append(u"Excel créé : %d feuille(s) → %s" % (n, chemin))
    return chemin
