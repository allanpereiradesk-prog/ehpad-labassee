# -*- coding: utf-8 -*-
"""Allan BIM - Lien Excel : export de parametres vers un vrai .xlsx et
reimport des valeurs modifiees.

Feuille "Donnees" : ID | Categorie | Famille | Type | parametres...
  - colonnes grises = lecture seule (ignorees au reimport)
  - "[T]" dans l'en-tete = parametre de type (modifie le type entier)
  - nombres exportes dans les unites du projet (mm, m3/h, Pa...)
Feuille cachee "_meta" : correspondance colonne -> parametre.
"""

import os
import io
import zipfile
import clr
clr.AddReference("System.Xml")
from System.Xml import XmlDocument, XmlNamespaceManager
from Autodesk.Revit import DB

NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NSR = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

CATEGORIES_MEP = [
    (u"Gaines", DB.BuiltInCategory.OST_DuctCurves),
    (u"Raccords de gaine", DB.BuiltInCategory.OST_DuctFitting),
    (u"Accessoires de gaine", DB.BuiltInCategory.OST_DuctAccessory),
    (u"Bouches d'air", DB.BuiltInCategory.OST_DuctTerminal),
    (u"Canalisations", DB.BuiltInCategory.OST_PipeCurves),
    (u"Raccords de canalisation", DB.BuiltInCategory.OST_PipeFitting),
    (u"Accessoires de canalisation", DB.BuiltInCategory.OST_PipeAccessory),
    (u"Équipements de génie climatique", DB.BuiltInCategory.OST_MechanicalEquipment),
    (u"Appareils sanitaires", DB.BuiltInCategory.OST_PlumbingFixtures),
    (u"Espaces", DB.BuiltInCategory.OST_MEPSpaces),
    (u"Pièces", DB.BuiltInCategory.OST_Rooms),
    (u"Systèmes de gaines", DB.BuiltInCategory.OST_DuctSystem),
    (u"Systèmes de canalisation", DB.BuiltInCategory.OST_PipingSystem),
    (u"Modèles génériques", DB.BuiltInCategory.OST_GenericModel),
]


def _id(e):
    i = e if isinstance(e, DB.ElementId) else e.Id
    return i.Value if hasattr(i, "Value") else i.IntegerValue


def nom_el(e):
    try:
        return DB.Element.Name.GetValue(e)
    except Exception:
        return u""


# ------------------------------------------------------------------ elements
def categories(doc):
    """Categories MEP (en premier) puis toutes les autres categories de modele qui ont des elements."""
    res, vus = [], set()
    for lbl, bic in CATEGORIES_MEP:
        n = DB.FilteredElementCollector(doc).OfCategory(bic).WhereElementIsNotElementType().GetElementCount()
        if n:
            res.append((u"%s (%d)" % (lbl, n), int(bic)))
            vus.add(int(bic))
    autres = []
    for c in doc.Settings.Categories:
        try:
            if c.CategoryType != DB.CategoryType.Model or _id(c) in vus or _id(c) > 0:
                continue
            n = DB.FilteredElementCollector(doc).OfCategoryId(c.Id).WhereElementIsNotElementType().GetElementCount()
            if n:
                autres.append((u"%s (%d)" % (c.Name, n), _id(c)))
        except Exception:
            pass
    autres.sort(key=lambda x: x[0].lower())
    return res + autres


def elements(doc, cat_id, portee, uidoc=None):
    import System
    cid = DB.ElementId(System.Int64(cat_id))
    if portee == "selection" and uidoc is not None:
        res = []
        for i in uidoc.Selection.GetElementIds():
            e = doc.GetElement(i)
            if e is not None and e.Category is not None and e.Category.Id == cid:
                res.append(e)
        return res
    col = DB.FilteredElementCollector(doc, doc.ActiveView.Id) if portee == "vue" else DB.FilteredElementCollector(doc)
    return list(col.OfCategoryId(cid).WhereElementIsNotElementType())


class Info(object):
    """Description d'un parametre exportable."""

    def __init__(self, p, est_type):
        d = p.Definition
        self.nom = d.Name
        self.type = est_type
        self.stockage = p.StorageType
        try:
            self.spec = d.GetDataType()
        except Exception:
            self.spec = None
        self.lecture = p.IsReadOnly or p.StorageType == DB.StorageType.ElementId or p.StorageType == getattr(DB.StorageType, "None")
        self.oui_non = False
        try:
            self.oui_non = self.spec == DB.SpecTypeId.Boolean.YesNo
        except Exception:
            pass

    def libelle(self):
        return self.nom + (u" [T]" if self.type else u"")


def parametres(doc, els, limite=300):
    """Parametres (occurrence puis type) presents sur les elements, sans doublon de nom."""
    vus = {}
    ordre = []
    types_vus = set()
    for e in els[:limite]:
        for p in e.Parameters:
            try:
                n = p.Definition.Name
            except Exception:
                continue
            if n and n not in vus:
                vus[n] = Info(p, False)
                ordre.append(n)
        try:
            tid = e.GetTypeId()
            if tid is not None and tid != DB.ElementId.InvalidElementId and _id(tid) not in types_vus:
                types_vus.add(_id(tid))
                t = doc.GetElement(tid)
                for p in t.Parameters:
                    n = p.Definition.Name
                    if n and n not in vus:
                        vus[n] = Info(p, True)
                        ordre.append(n)
        except Exception:
            pass
    res = [vus[n] for n in ordre]
    res.sort(key=lambda i: (i.lecture, i.type, i.nom.lower()))
    return res


def _unite(doc, info):
    try:
        if info.stockage == DB.StorageType.Double and info.spec is not None and DB.UnitUtils.IsMeasurableSpec(info.spec):
            return doc.GetUnits().GetFormatOptions(info.spec).GetUnitTypeId()
    except Exception:
        pass
    return None


def _symbole(doc, info):
    try:
        fo = doc.GetUnits().GetFormatOptions(info.spec)
        sid = fo.GetSymbolTypeId()
        if sid is not None and not sid.Empty():
            return DB.LabelUtils.GetLabelForSymbol(sid)
        for s in DB.FormatOptions.GetValidSymbols(fo.GetUnitTypeId()):
            if s is not None and not s.Empty():
                return DB.LabelUtils.GetLabelForSymbol(s)
        return DB.LabelUtils.GetLabelForUnit(fo.GetUnitTypeId())
    except Exception:
        return u""


def _param(doc, e, info):
    if info.type:
        tid = e.GetTypeId()
        if tid is None or tid == DB.ElementId.InvalidElementId:
            return None, None
        t = doc.GetElement(tid)
        return t.LookupParameter(info.nom), t
    return e.LookupParameter(info.nom), e


def valeur(doc, p, info):
    """Valeur 'Excel' d'un parametre : float, int, ou texte."""
    if p is None or not p.HasValue:
        return None
    st = p.StorageType
    if st == DB.StorageType.String:
        return p.AsString() or u""
    if st == DB.StorageType.Integer:
        if info.oui_non:
            return u"Oui" if p.AsInteger() == 1 else u"Non"
        return p.AsInteger()
    if st == DB.StorageType.Double:
        u = _unite(doc, info)
        v = p.AsDouble()
        if u is not None:
            v = DB.UnitUtils.ConvertFromInternalUnits(v, u)
        return round(v, 6)
    if st == DB.StorageType.ElementId:
        return p.AsValueString() or u""
    return None


# ------------------------------------------------------------------ ecriture xlsx
def _xml(t):
    t = u"%s" % t
    t = u"".join(c for c in t if c in u"\t\n\r" or ord(c) >= 32)
    return t.replace(u"&", u"&amp;").replace(u"<", u"&lt;").replace(u">", u"&gt;").replace(u'"', u"&quot;")


def _col(i):
    s = u""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _cellule(r, c, v, style=0):
    ref = u"%s%d" % (_col(c), r)
    st = u' s="%d"' % style if style else u""
    if v is None or v == u"":
        return u'<c r="%s"%s/>' % (ref, st)
    if isinstance(v, bool):
        v = u"Oui" if v else u"Non"
    if isinstance(v, (int, long, float)):
        return u'<c r="%s"%s><v>%s</v></c>' % (ref, st, repr(v) if isinstance(v, float) else v)
    return u'<c r="%s"%s t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (ref, st, _xml(v))


def _feuille(lignes, styles_lignes=None, largeurs=None, figer=False, filtre=False):
    x = [u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
         u'<worksheet xmlns="%s" xmlns:r="%s">' % (NS, NSR)]
    if figer:
        x.append(u'<sheetViews><sheetView workbookViewId="0"><pane xSplit="1" ySplit="1" topLeftCell="B2" '
                 u'activePane="bottomRight" state="frozen"/></sheetView></sheetViews>')
    if largeurs:
        x.append(u"<cols>")
        for i, w in enumerate(largeurs):
            x.append(u'<col min="%d" max="%d" width="%.1f" customWidth="1"/>' % (i + 1, i + 1, w))
        x.append(u"</cols>")
    x.append(u"<sheetData>")
    for r, ligne in enumerate(lignes):
        x.append(u'<row r="%d">' % (r + 1))
        for c, v in enumerate(ligne):
            s = styles_lignes(r, c) if styles_lignes else 0
            x.append(_cellule(r + 1, c, v, s))
        x.append(u"</row>")
    x.append(u"</sheetData>")
    if filtre and lignes:
        x.append(u'<autoFilter ref="A1:%s%d"/>' % (_col(len(lignes[0]) - 1), len(lignes)))
    x.append(u"</worksheet>")
    return u"".join(x)


STYLES = (u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          u'<styleSheet xmlns="%s">'
          u'<fonts count="3"><font><sz val="11"/><name val="Calibri"/></font>'
          u'<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>'
          u'<font><b/><sz val="11"/><color rgb="FF404040"/><name val="Calibri"/></font></fonts>'
          u'<fills count="5"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
          u'<fill><patternFill patternType="solid"><fgColor rgb="FF2D5A88"/><bgColor indexed="64"/></patternFill></fill>'
          u'<fill><patternFill patternType="solid"><fgColor rgb="FFE4E4E4"/><bgColor indexed="64"/></patternFill></fill>'
          u'<fill><patternFill patternType="solid"><fgColor rgb="FFB8B8B8"/><bgColor indexed="64"/></patternFill></fill></fills>'
          u'<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
          u'<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
          u'<cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
          u'<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>'
          u'<xf numFmtId="0" fontId="0" fillId="3" borderId="0" xfId="0" applyFill="1"/>'
          u'<xf numFmtId="0" fontId="2" fillId="4" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs>'
          u'<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
          u'</styleSheet>') % NS

LISEZMOI = [
    [u"Allan BIM - Lien Excel"],
    [u""],
    [u"1. Modifie les valeurs dans la feuille « Données » (colonnes à en-tête bleu)."],
    [u"2. Les colonnes grises sont en lecture seule : elles sont ignorées au réimport."],
    [u"3. [T] = paramètre de type : la valeur s'applique à tous les éléments de ce type."],
    [u"4. Les nombres sont dans les unités du projet (voir l'en-tête de colonne)."],
    [u"5. Ne modifie pas la colonne ID, ni la feuille cachée _meta."],
    [u"6. Enregistre, puis dans Revit : Lien Excel > Réimporter."],
]


def exporter(doc, els, infos, chemin, log):
    entete = [u"ID", u"Catégorie", u"Famille", u"Type"]
    for i in infos:
        sym = _symbole(doc, i) if i.stockage == DB.StorageType.Double and _unite(doc, i) is not None else u""
        entete.append(i.libelle() + (u" (%s)" % sym if sym else u""))
    lignes = [entete]
    for e in els:
        try:
            typ = doc.GetElement(e.GetTypeId()) if e.GetTypeId() != DB.ElementId.InvalidElementId else None
            fam = u""
            if typ is not None:
                fam = getattr(typ, "FamilyName", u"") or u""
            ligne = [int(_id(e)), e.Category.Name if e.Category else u"", fam, nom_el(typ) if typ else nom_el(e)]
            for i in infos:
                p, _ = _param(doc, e, i)
                ligne.append(valeur(doc, p, i))
            lignes.append(ligne)
        except Exception as ex:
            log.append(u"Élément %s ignoré : %s" % (_id(e), ex))
    ro = [True] * 4 + [i.lecture for i in infos]

    def style(r, c):
        if r == 0:
            return 3 if ro[c] else 1
        return 2 if ro[c] else 0
    larg = [10, 22, 26, 26] + [max(12, min(40, len(h) * 1.1 + 2)) for h in entete[4:]]
    meta = [[u"colonne", u"parametre", u"type", u"stockage", u"unite", u"lecture_seule", u"oui_non"]]
    for k, i in enumerate(infos):
        u = _unite(doc, i)
        meta.append([k + 4, i.nom, 1 if i.type else 0, u"%s" % i.stockage, u.TypeId if u is not None else u"",
                     1 if i.lecture else 0, 1 if i.oui_non else 0])
    fichiers = {
        "[Content_Types].xml": u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        u'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        u'<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        u'<Default Extension="xml" ContentType="application/xml"/>'
        u'<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        u'<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        u'<Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        u'<Override PartName="/xl/worksheets/sheet3.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        u'<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        u'</Types>',
        "_rels/.rels": u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        u'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        u'<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        u'</Relationships>',
        "xl/workbook.xml": u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        u'<workbook xmlns="%s" xmlns:r="%s"><sheets>'
        u'<sheet name="Données" sheetId="1" r:id="rId1"/>'
        u'<sheet name="Lisez-moi" sheetId="2" r:id="rId2"/>'
        u'<sheet name="_meta" sheetId="3" state="hidden" r:id="rId3"/>'
        u'</sheets></workbook>' % (NS, NSR),
        "xl/_rels/workbook.xml.rels": u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        u'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        u'<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
        u'<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>'
        u'<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet3.xml"/>'
        u'<Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
        u'</Relationships>',
        "xl/styles.xml": STYLES,
        "xl/worksheets/sheet1.xml": _feuille(lignes, style, larg, figer=True, filtre=True),
        "xl/worksheets/sheet2.xml": _feuille(LISEZMOI, lambda r, c: 1 if r == 0 else 0, [95]),
        "xl/worksheets/sheet3.xml": _feuille(meta),
    }
    d = os.path.dirname(chemin)
    if d and not os.path.isdir(d):
        os.makedirs(d)
    z = zipfile.ZipFile(chemin, "w", zipfile.ZIP_DEFLATED)
    try:
        for nomf in ["[Content_Types].xml", "_rels/.rels", "xl/workbook.xml", "xl/_rels/workbook.xml.rels",
                     "xl/styles.xml", "xl/worksheets/sheet1.xml", "xl/worksheets/sheet2.xml", "xl/worksheets/sheet3.xml"]:
            z.writestr(nomf, fichiers[nomf].encode("utf-8"))
    finally:
        z.close()
    log.append(u"Exporté : %d élément(s), %d paramètre(s) -> %s" % (len(lignes) - 1, len(infos), chemin))
    return len(lignes) - 1


# ------------------------------------------------------------------ lecture xlsx
def _xmldoc(z, nomf):
    import System
    data = z.read(nomf)
    if isinstance(data, basestring):
        b = System.Array[System.Byte]([ord(ch) & 0xFF for ch in data])
    else:
        b = System.Array[System.Byte](list(bytearray(data)))
    x = XmlDocument()
    x.Load(System.IO.MemoryStream(b))
    ns = XmlNamespaceManager(x.NameTable)
    ns.AddNamespace("m", NS)
    ns.AddNamespace("r", NSR)
    ns.AddNamespace("pr", "http://schemas.openxmlformats.org/package/2006/relationships")
    return x, ns


def _col_index(ref):
    n = 0
    for ch in ref:
        if ch.isalpha():
            n = n * 26 + (ord(ch.upper()) - 64)
        else:
            break
    return n - 1


def _lire_feuille(z, chemin_feuille, partages):
    x, ns = _xmldoc(z, chemin_feuille)
    lignes = []
    for row in x.SelectNodes("//m:sheetData/m:row", ns):
        r = int(row.GetAttribute("r")) - 1 if row.GetAttribute("r") else len(lignes)
        while len(lignes) <= r:
            lignes.append([])
        ligne = lignes[r]
        for c in row.SelectNodes("m:c", ns):
            ci = _col_index(c.GetAttribute("r")) if c.GetAttribute("r") else len(ligne)
            t = c.GetAttribute("t")
            v = None
            if t == "inlineStr":
                v = u"".join(n.InnerText for n in c.SelectNodes(".//m:t", ns))
            else:
                vn = c.SelectSingleNode("m:v", ns)
                if vn is not None:
                    txt = vn.InnerText
                    if t == "s":
                        v = partages[int(txt)]
                    elif t == "b":
                        v = u"Oui" if txt == "1" else u"Non"
                    elif t in ("str", "e"):
                        v = txt
                    else:
                        try:
                            f = float(txt)
                            v = int(f) if f == int(f) and abs(f) < 1e15 and "." not in txt and "E" not in txt.upper() else f
                        except ValueError:
                            v = txt
            while len(ligne) <= ci:
                ligne.append(None)
            ligne[ci] = v
    return lignes


def lire(chemin):
    """Renvoie (lignes de la feuille Donnees, lignes de _meta)."""
    z = zipfile.ZipFile(chemin, "r")
    try:
        noms = z.namelist()
        partages = []
        if "xl/sharedStrings.xml" in noms:
            x, ns = _xmldoc(z, "xl/sharedStrings.xml")
            for si in x.SelectNodes("//m:si", ns):
                partages.append(u"".join(n.InnerText for n in si.SelectNodes(".//m:t", ns)))
        wb, ns = _xmldoc(z, "xl/workbook.xml")
        rels, nsr = _xmldoc(z, "xl/_rels/workbook.xml.rels")
        cibles = {}
        for rel in rels.SelectNodes("//pr:Relationship", nsr):
            tgt = rel.GetAttribute("Target").lstrip("/")
            cibles[rel.GetAttribute("Id")] = tgt if tgt.startswith("xl/") else "xl/" + tgt
        feuilles = {}
        for s in wb.SelectNodes("//m:sheets/m:sheet", ns):
            feuilles[s.GetAttribute("name")] = cibles.get(s.GetAttribute("id", NSR))
        f_data = feuilles.get(u"Données") or feuilles.get(u"Donnees")
        f_meta = feuilles.get(u"_meta")
        if not f_data or not f_meta:
            raise Exception(u"Ce fichier n'a pas été créé par le Lien Excel Allan BIM (feuilles Données / _meta absentes).")
        return _lire_feuille(z, f_data, partages), _lire_feuille(z, f_meta, partages)
    finally:
        z.close()


# ------------------------------------------------------------------ comparaison / reimport
class Changement(object):
    def __init__(self, cible, param, ancien, nouveau, interne, nom_param, libelle, est_type):
        self.cible, self.param, self.ancien, self.nouveau = cible, param, ancien, nouveau
        self.interne, self.nom_param, self.libelle, self.est_type = interne, nom_param, libelle, est_type


def _txt(v):
    if v is None:
        return u""
    if isinstance(v, float):
        s = (u"%.6f" % v).rstrip(u"0").rstrip(u".")
        return s.replace(u".", u",")
    return u"%s" % v


def comparer(doc, lignes, meta, log):
    """Renvoie la liste des Changement a appliquer."""
    cols = []
    for m in meta[1:]:
        if not m or m[0] is None:
            continue
        try:
            cols.append({"col": int(m[0]), "nom": m[1], "type": int(m[2] or 0) == 1, "stockage": m[3],
                         "unite": m[4] or u"", "lecture": int(m[5] or 0) == 1, "oui_non": int(m[6] or 0) == 1})
        except Exception:
            pass
    changements = []
    par_type = {}
    conflits = set()
    introuvables = 0
    for ligne in lignes[1:]:
        if not ligne or ligne[0] in (None, u""):
            continue
        try:
            eid = int(float(ligne[0]))
        except Exception:
            continue
        e = doc.GetElement(DB.ElementId(System_Int64(eid)))
        if e is None:
            introuvables += 1
            continue
        for c in cols:
            if c["lecture"] or c["col"] >= len(ligne):
                continue
            nv = ligne[c["col"]]
            if c["type"]:
                tid = e.GetTypeId()
                if tid == DB.ElementId.InvalidElementId:
                    continue
                cible = doc.GetElement(tid)
            else:
                cible = e
            p = cible.LookupParameter(c["nom"])
            if p is None or p.IsReadOnly:
                continue
            try:
                ch = _changement(doc, cible, p, c, nv)
            except Exception as ex:
                log.append(u"ID %s, %s : valeur « %s » refusée (%s)" % (eid, c["nom"], nv, ex))
                continue
            if ch is None:
                continue
            if c["type"]:
                # parametre de type present sur plusieurs lignes : la ligne modifiee
                # l'emporte ; si plusieurs lignes donnent des valeurs differentes, on previent
                k = (_id(cible), c["nom"])
                if k in par_type:
                    if _txt(par_type[k].nouveau) != _txt(ch.nouveau):
                        conflits.add(k)
                    continue
                par_type[k] = ch
            changements.append(ch)
    for k in conflits:
        ch = par_type[k]
        log.append(u"Type « %s », %s : plusieurs valeurs différentes dans le fichier, « %s » gardée."
                   % (ch.libelle, ch.nom_param, _txt(ch.nouveau)))
    if introuvables:
        log.append(u"%d ligne(s) ignorée(s) : élément introuvable dans le projet (supprimé ?)." % introuvables)
    return changements


def System_Int64(v):
    import System
    return System.Int64(v)


def _changement(doc, cible, p, c, nv):
    st = p.StorageType
    lib = u"%s" % (nom_el(cible) if c["type"] else u"ID %s" % _id(cible))
    if st == DB.StorageType.String:
        if c["type"] and (nv is None or nv == u""):
            return None        # case vide sur un parametre de type = pas de changement
        nouveau = u"" if nv is None else (_txt(nv) if isinstance(nv, float) else u"%s" % nv)
        ancien = p.AsString() or u""
        if nouveau == ancien:
            return None
        return Changement(cible, p, ancien, nouveau, nouveau, c["nom"], lib, c["type"])
    if st == DB.StorageType.Integer:
        if nv is None or nv == u"":
            return None
        if c["oui_non"]:
            n = 1 if (u"%s" % nv).strip().lower() in (u"oui", u"1", u"vrai", u"true", u"x", u"yes") else 0
        else:
            n = int(round(float((u"%s" % nv).replace(u",", u".").replace(u" ", u""))))
        if n == p.AsInteger():
            return None
        aff = (u"Oui" if n else u"Non") if c["oui_non"] else n
        anc = (u"Oui" if p.AsInteger() else u"Non") if c["oui_non"] else p.AsInteger()
        return Changement(cible, p, anc, aff, n, c["nom"], lib, c["type"])
    if st == DB.StorageType.Double:
        if nv is None or nv == u"":
            return None
        f = float((u"%s" % nv).replace(u",", u".").replace(u" ", u"").replace(u" ", u""))
        interne = f
        anc = p.AsDouble()
        if c["unite"]:
            u = DB.ForgeTypeId(c["unite"])
            interne = DB.UnitUtils.ConvertToInternalUnits(f, u)
            anc_aff = DB.UnitUtils.ConvertFromInternalUnits(anc, u)
        else:
            anc_aff = anc
        if abs(interne - anc) <= max(1e-9, abs(anc) * 1e-6):
            return None
        return Changement(cible, p, round(anc_aff, 4), f, interne, c["nom"], lib, c["type"])
    return None


def appliquer(doc, changements, log):
    t = DB.Transaction(doc, u"Allan BIM - Réimport Excel")
    t.Start()
    ok = err = 0
    try:
        for ch in changements:
            try:
                ch.param.Set(ch.interne)
                ok += 1
            except Exception as ex:
                err += 1
                if err <= 10:
                    log.append(u"%s, %s : %s" % (ch.libelle, ch.nom_param, ex))
        t.Commit()
    except Exception as ex:
        if t.HasStarted() and not t.HasEnded():
            t.RollBack()
        log.append(u"Réimport annulé : %s" % ex)
        return 0
    log.append(u"Réimport : %d valeur(s) modifiée(s), %d erreur(s)." % (ok, err))
    return ok
