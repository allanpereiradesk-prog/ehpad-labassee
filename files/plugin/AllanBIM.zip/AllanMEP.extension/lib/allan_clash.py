# -*- coding: utf-8 -*-
"""Allan BIM - detection et resolution des clashs entre reseaux.

- detecter(doc)            -> liste de Clash (gaines / canalisations / raccords
                              qui se traversent sans etre raccordes)
- variantes(doc, clash...) -> 3 solutions : dessus, dessous, proposition
                              Chaque solution est simulee dans Revit puis
                              annulee : elle n'est gardee que si elle ne cree
                              AUCUN nouveau clash (sinon on augmente le
                              decalage et on recommence).
- preparer_vues(doc, clash)-> coupe + vue 3D (zone de coupe) sur le clash
- ClashWindow              -> le panneau
"""
from Autodesk.Revit import DB
from System import Int64
from System.Collections.Generic import List
import allan_relier as rel

MM = 1.0 / 304.8
TOL = 5 * MM
VOL_MIN = 2e-5                      # pi3 (~0.5 cm3) : en dessous = simple contact
PAS = [0, 50, 100, 200, 300, 500]   # mm ajoutes au decalage si nouveau clash
VUE_COUPE = "Allan BIM - Clash coupe"
VUE_3D = "Allan BIM - Clash 3D"
SENS = ("dessus", "dessous", "gauche", "droite")
TXT_SENS = {"dessus": "AU-DESSUS", "dessous": "EN DESSOUS",
            "gauche": "A GAUCHE (contournement lateral)",
            "droite": "A DROITE (contournement lateral)"}

BIC = DB.BuiltInCategory
CATS_RACC = [BIC.OST_DuctFitting, BIC.OST_PipeFitting, BIC.OST_DuctAccessory, BIC.OST_PipeAccessory]
CATS_OBST = CATS_RACC + [
    BIC.OST_DuctCurves, BIC.OST_PipeCurves, BIC.OST_FlexDuctCurves, BIC.OST_FlexPipeCurves,
    BIC.OST_CableTray, BIC.OST_CableTrayFitting, BIC.OST_Conduit, BIC.OST_ConduitFitting,
    BIC.OST_MechanicalEquipment, BIC.OST_DuctTerminal, BIC.OST_PlumbingFixtures, BIC.OST_Sprinklers,
    BIC.OST_StructuralFraming, BIC.OST_StructuralColumns, BIC.OST_Columns, BIC.OST_Floors,
    BIC.OST_Ceilings, BIC.OST_Walls, BIC.OST_Roofs, BIC.OST_Stairs]


# ------------------------------------------------------------ outils
def eid(i):
    if isinstance(i, tuple):          # element de maquette liee ("lien", id lien, id element)
        return i[2]
    try:
        return i.Value
    except Exception:
        return i.IntegerValue


def nom(el):
    try:
        return el.Name
    except Exception:
        try:
            return DB.Element.Name.GetValue(el)
        except Exception:
            return ""


def _dbl(el, bip):
    try:
        p = el.get_Parameter(bip)
        if p and p.HasValue:
            return p.AsDouble()
    except Exception:
        pass
    return 0.0


def _cats(lst):
    return DB.ElementMulticategoryFilter(List[BIC](lst))


class Net(object):
    """Un reseau (troncon ou raccord) avec ses dimensions."""

    def __init__(self, el):
        self.el, self.id = el, el.Id
        self.curve = rel.is_curve(el)
        self.rond = True
        self.ins = _dbl(el, DB.BuiltInParameter.RBS_REFERENCE_INSULATION_THICKNESS)
        bb = el.get_BoundingBox(None)
        self.centre = (bb.Min + bb.Max) * 0.5
        self.demi = (bb.Max - bb.Min) * 0.5
        self.pipe = isinstance(el, DB.Plumbing.Pipe)
        if self.curve:
            ln = el.Location.Curve
            self.p0, self.p1 = ln.GetEndPoint(0), ln.GetEndPoint(1)
            self.L = self.p0.DistanceTo(self.p1)
            self.d = (self.p1 - self.p0).Normalize()
            c = [x for x in rel.connectors(el) if x.ConnectorType == DB.ConnectorType.End][0]
            cs = c.CoordinateSystem
            self.bx, self.by = cs.BasisX, cs.BasisY
            if c.Shape == DB.ConnectorProfileType.Round:
                dia = _dbl(el, DB.BuiltInParameter.RBS_PIPE_OUTER_DIAMETER) or 2 * c.Radius
                self.w = self.h = dia
            else:
                self.rond = False
                self.w, self.h = c.Width, c.Height
        try:
            cat = el.Category.Name
        except Exception:
            cat = "Element"
        taille = ""
        try:
            p = el.get_Parameter(DB.BuiltInParameter.RBS_CALCULATED_SIZE)
            taille = p.AsString() or ""
        except Exception:
            pass
        if self.curve:
            cat = "Canalisation" if self.pipe else "Gaine"
        self.nom = ("%s %s" % (cat, taille)).strip()

    def ext(self, n):
        """Demi-encombrement dans la direction n (isolant compris)."""
        if not self.curve:
            return abs(n.X) * self.demi.X + abs(n.Y) * self.demi.Y + abs(n.Z) * self.demi.Z
        if self.rond:
            k = max(0.0, 1.0 - n.DotProduct(self.d) ** 2) ** 0.5
            return (self.w / 2.0 + self.ins) * k
        return abs(n.DotProduct(self.bx)) * self.w / 2.0 + abs(n.DotProduct(self.by)) * self.h / 2.0 + self.ins

    def gros(self):
        return (max(self.w, self.h) / 2.0 + self.ins) if self.curve else max(self.demi.X, self.demi.Y, self.demi.Z)

    def section(self):
        return self.w * self.h if self.curve else 1e9

    def vertical(self):
        return self.curve and abs(self.d.Z) > 0.9

    def libre(self):
        cs = [c for c in rel.connectors(self.el) if c.ConnectorType == DB.ConnectorType.End]
        return all(not c.IsConnected for c in cs)


def voisins(el):
    """Ids des elements raccordes a el."""
    out = set()
    for c in rel.connectors(el):
        try:
            for r in c.AllRefs:
                o = r.Owner
                if o is None or o.Id == el.Id or isinstance(o, DB.MEPSystem):
                    continue
                out.add(eid(o.Id))
        except Exception:
            pass
    return out


def _solides(el):
    out = []
    opt = DB.Options()
    opt.DetailLevel = DB.ViewDetailLevel.Fine

    def walk(g):
        for o in g:
            if isinstance(o, DB.Solid):
                if o.Volume > 1e-9:
                    out.append(o)
            elif isinstance(o, DB.GeometryInstance):
                walk(o.GetInstanceGeometry())
    try:
        g = el.get_Geometry(opt)
        if g:
            walk(g)
    except Exception:
        pass
    return out


def _intersection(e1, e2):
    """(volume, centre) de l'intersection, ou (None, centre des boites)."""
    vol, cx, ok = 0.0, DB.XYZ.Zero, False
    for a in _solides(e1):
        for b in _solides(e2):
            try:
                s = DB.BooleanOperationsUtils.ExecuteBooleanOperation(
                    a, b, DB.BooleanOperationsType.Intersect)
                ok = True
                if s and s.Volume > 1e-9:
                    cx = cx + s.ComputeCentroid() * s.Volume
                    vol += s.Volume
            except Exception:
                pass
    if ok and vol > 1e-9:
        return vol, cx * (1.0 / vol)
    b1, b2 = e1.get_BoundingBox(None), e2.get_BoundingBox(None)
    mn = DB.XYZ(max(b1.Min.X, b2.Min.X), max(b1.Min.Y, b2.Min.Y), max(b1.Min.Z, b2.Min.Z))
    mx = DB.XYZ(min(b1.Max.X, b2.Max.X), min(b1.Max.Y, b2.Max.Y), min(b1.Max.Z, b2.Max.Z))
    return (0.0 if ok else None), (mn + mx) * 0.5


def touches(doc, el, univ):
    """Ids des elements de univ dont le volume traverse celui de el."""
    out = set()
    if el is None or univ is None:
        return out
    if univ.Count > 0:
        try:
            col = DB.FilteredElementCollector(doc, univ).WherePasses(DB.ElementIntersectsElementFilter(el))
            for i in col.ToElementIds():
                out.add(eid(i))
        except Exception:
            pass
    out.discard(eid(el.Id))
    if univ is _LIENS["univ"]:        # univers complet : on ajoute les maquettes liees
        out |= touches_liens(el)
    return out


def univers(doc):
    """Tout ce qu'une solution ne doit pas venir percuter
    (projet + maquettes liees chargees : archi, structure, autres lots)."""
    u = DB.FilteredElementCollector(doc).WherePasses(_cats(CATS_OBST)) \
        .WhereElementIsNotElementType().ToElementIds()
    _LIENS["univ"] = u
    _LIENS["liens"] = liens(doc)
    return u


# ------------------------------------------------------------ maquettes liees
# Un element d'une maquette liee est repere par la cle ("lien", id du lien, id dans le lien).
_LIENS = {"univ": None, "liens": []}


def liens(doc):
    """[(instance de lien, document lie, transformation, inverse)] des liens charges."""
    out = []
    for li in DB.FilteredElementCollector(doc).OfClass(DB.RevitLinkInstance):
        try:
            ld = li.GetLinkDocument()
            if ld is None:
                continue
            T = li.GetTotalTransform()
            out.append((li, ld, T, T.Inverse))
        except Exception:
            pass
    return out


def _outline(bb, tr, marge=0.0):
    pts = [tr.OfPoint(DB.XYZ(x, y, z)) for x in (bb.Min.X, bb.Max.X)
           for y in (bb.Min.Y, bb.Max.Y) for z in (bb.Min.Z, bb.Max.Z)]
    m = DB.XYZ(marge, marge, marge)
    return DB.Outline(DB.XYZ(min(p.X for p in pts), min(p.Y for p in pts), min(p.Z for p in pts)) - m,
                      DB.XYZ(max(p.X for p in pts), max(p.Y for p in pts), max(p.Z for p in pts)) + m)


def touches_liens(el, lst=None, cats=None):
    """Cles des elements des maquettes liees dont le volume traverse celui de el."""
    out = set()
    lst = _LIENS["liens"] if lst is None else lst
    if el is None or not lst:
        return out
    bb = el.get_BoundingBox(None)
    sols = _solides(el)
    if bb is None or not sols:
        return out
    filtre = _cats(cats or CATS_OBST)
    for li, ld, T, inv in lst:
        try:
            cand = list(DB.FilteredElementCollector(ld).WherePasses(filtre)
                        .WhereElementIsNotElementType()
                        .WherePasses(DB.BoundingBoxIntersectsFilter(_outline(bb, inv)))
                        .ToElementIds())
        except Exception:
            continue
        if not cand:
            continue
        for s in sols:
            try:
                sl = DB.SolidUtils.CreateTransformed(s, inv)
                col = DB.FilteredElementCollector(ld, List[DB.ElementId](cand)) \
                    .WherePasses(DB.ElementIntersectsSolidFilter(sl))
                for i in col.ToElementIds():
                    out.add(("lien", eid(li.Id), eid(i)))
            except Exception:
                pass
    return out


def element(doc, k):
    """Element correspondant a une cle de touches() (projet ou maquette liee)."""
    try:
        if isinstance(k, tuple):
            li = doc.GetElement(DB.ElementId(Int64(k[1])))
            return li.GetLinkDocument().GetElement(DB.ElementId(Int64(k[2])))
        return doc.GetElement(DB.ElementId(Int64(k)))
    except Exception:
        return None


# ------------------------------------------------------------ detection
class Clash(object):
    def __init__(self, e1, e2, vol, pt):
        self.a, self.b = Net(e1), Net(e2)
        self.volume, self.pt = vol, pt
        self.key = (min(eid(e1.Id), eid(e2.Id)), max(eid(e1.Id), eid(e2.Id)))
        self.etat = "A traiter"
        self.vars = None

    def titre(self):
        return "%s  x  %s" % (self.a.nom, self.b.nom)


# Dans une maquette liee, seuls ces elements font un clash (un mur ou une dalle
# traverses = une reservation, c'est l'outil Reservations qui s'en occupe).
CATS_CLASH_LIEN = [BIC.OST_StructuralFraming, BIC.OST_StructuralColumns, BIC.OST_Columns]


class ObstacleLie(Net):
    """Element d'une maquette liee (poutre, poteau...). Il ne bouge jamais :
    c'est toujours le reseau du projet qui est devie."""

    def __init__(self, li, ld, T, el):
        self.el, self.lien = el, li
        self.id = ("lien", eid(li.Id), eid(el.Id))
        self.curve = self.pipe = self.rond = False
        self.ins = 0.0
        self.w = self.h = 0.0
        o = _outline(el.get_BoundingBox(None), T)
        self.centre = (o.MinimumPoint + o.MaximumPoint) * 0.5
        self.demi = (o.MaximumPoint - o.MinimumPoint) * 0.5
        try:
            cat = el.Category.Name
        except Exception:
            cat = "Element"
        try:
            src = ld.Title
        except Exception:
            src = "lien"
        self.nom = "%s [maquette liee %s]" % (cat, src)

    def libre(self):
        return False


class ClashLien(Clash):
    def __init__(self, e, obs, vol, pt):
        self.a, self.b = Net(e), obs
        self.volume, self.pt = vol, pt
        self.key = (eid(e.Id),) + obs.id
        self.etat = "A traiter"
        self.vars = None


def _intersection_lien(e, lel, T):
    vol, cx = 0.0, DB.XYZ.Zero
    for a in _solides(e):
        for b in _solides(lel):
            try:
                s = DB.BooleanOperationsUtils.ExecuteBooleanOperation(
                    a, DB.SolidUtils.CreateTransformed(b, T), DB.BooleanOperationsType.Intersect)
                if s and s.Volume > 1e-9:
                    cx = cx + s.ComputeCentroid() * s.Volume
                    vol += s.Volume
            except Exception:
                pass
    if vol > 1e-9:
        return vol, cx * (1.0 / vol)
    bb = e.get_BoundingBox(None)
    return None, (bb.Min + bb.Max) * 0.5


def detecter_liens(doc, els):
    """Clashs entre les gaines / canalisations du projet et les poutres /
    poteaux des maquettes liees."""
    out = []
    lst = liens(doc)
    if not lst:
        return out
    par_lien = dict((eid(li.Id), (li, ld, T)) for li, ld, T, inv in lst)
    for e in els:
        if not rel.is_curve(e):
            continue
        for k in touches_liens(e, lst, CATS_CLASH_LIEN):
            li, ld, T = par_lien[k[1]]
            lel = ld.GetElement(DB.ElementId(Int64(k[2])))
            if lel is None or lel.get_BoundingBox(None) is None:
                continue
            vol, pt = _intersection_lien(e, lel, T)
            if vol is not None and vol < VOL_MIN:
                continue
            try:
                out.append(ClashLien(e, ObstacleLie(li, ld, T, lel), vol, pt))
            except Exception:
                pass
    return out


def detecter(doc):
    els = list(DB.FilteredElementCollector(doc).OfClass(DB.Mechanical.Duct)) + \
        list(DB.FilteredElementCollector(doc).OfClass(DB.Plumbing.Pipe)) + \
        list(DB.FilteredElementCollector(doc).WherePasses(_cats(CATS_RACC)).WhereElementIsNotElementType())
    els = [e for e in els if e.get_BoundingBox(None) is not None]
    if not els:
        return []
    try:
        out_liens = detecter_liens(doc, els)
    except Exception:
        out_liens = []
    if len(els) < 2:
        return out_liens
    ids = List[DB.ElementId]([e.Id for e in els])
    vois, vus, out = {}, set(), []

    def vz(e):
        k = eid(e.Id)
        if k not in vois:
            vois[k] = voisins(e)
        return vois[k]

    for e in els:
        k = eid(e.Id)
        for kh in touches(doc, e, ids):
            pair = (min(k, kh), max(k, kh))
            if pair in vus:
                continue
            vus.add(pair)
            o = doc.GetElement(DB.ElementId(Int64(kh)))
            if o is None or not (rel.is_curve(e) or rel.is_curve(o)):
                continue
            v1, v2 = vz(e), vz(o)
            if kh in v1 or k in v2 or (v1 & v2):
                continue            # raccordes ensemble (direct ou meme raccord)
            vol, pt = _intersection(e, o)
            if vol is not None and vol < VOL_MIN:
                continue
            try:
                out.append(Clash(e, o, vol, pt))
            except Exception:
                pass
    out += out_liens
    out.sort(key=lambda c: -(c.volume or 0))
    return out


# ------------------------------------------------------------ solutions
def _proj(p, a, d):
    return a + d * (p - a).DotProduct(d)


def direction(mv, sens):
    """Vecteur unitaire du decalage (perpendiculaire au reseau a devier)."""
    d = mv.d
    if mv.vertical():
        raise Exception("le reseau a devier est vertical")
    up = (DB.XYZ.BasisZ - d * d.DotProduct(DB.XYZ.BasisZ)).Normalize()
    cote = up.CrossProduct(d).Normalize()
    return {"dessus": up, "dessous": up.Negate(), "gauche": cote, "droite": cote.Negate()}[sens]


_COUDES = {}


def mesurer_coude(doc, mv, n):
    """Place prise par un coude a 45 deg de ce reseau (de chaque cote de
    l'angle). Mesuree une fois sur un coude d'essai, cree loin puis annule."""
    key = (eid(mv.el.GetTypeId()), round(mv.w, 4), round(mv.h, 4), abs(n.Z) < 0.5)
    if key in _COUDES:
        return _COUDES[key]
    L = max(3000 * MM, 12 * mv.gros())
    o = mv.p0 + DB.XYZ.BasisZ * 100.0
    pa, pb = o - mv.d * L, o + (mv.d + n).Normalize() * L
    sid, tid, lvl = _sys_id(doc, mv.el), mv.el.GetTypeId(), rel.level_of(mv.el, doc)
    t = tx_debut(doc, "Allan BIM - mesure coude")
    try:
        segs = []
        for a, b in ((pa, o), (o, pb)):
            if mv.pipe:
                x = DB.Plumbing.Pipe.Create(doc, sid, tid, lvl, a, b)
            else:
                x = DB.Mechanical.Duct.Create(doc, sid, tid, lvl, a, b)
            rel.copy_size(mv.el, x)
            segs.append(x)
        doc.Regenerate()
        f = doc.Create.NewElbowFitting(rel.conn_at(segs[0], o), rel.conn_at(segs[1], o))
        doc.Regenerate()
        leg = max(c.Origin.DistanceTo(o) for c in rel.connectors(f))
    except Exception as ex:
        raise Exception("coude a 45 deg impossible pour ce type (%s)" % str(ex).split("\n")[0][:60])
    finally:
        t.RollBack()
    _COUDES[key] = leg
    return leg


def plan(mv, ot, pt, sens, jeu, extra, mode, coude=0.0):
    """Geometrie d'une solution. Leve une Exception si impossible."""
    if not mv.curve:
        raise Exception("ce n'est pas un troncon")
    d = mv.d
    n = direction(mv, sens)
    sin, cos = 1.0, 0.0
    if ot.curve:
        if abs(ot.d.DotProduct(n)) > 0.7:
            raise Exception("l'autre reseau part dans cette direction")
        sin = d.CrossProduct(ot.d).GetLength()
        cos = abs(d.DotProduct(ot.d))
        r = rel.lines_closest(mv.p0, d, ot.p0, ot.d) if sin > 0.25 else None
        if r:
            cm, co = r[0], r[1]
        else:
            cm, co = _proj(pt, mv.p0, d), _proj(pt, ot.p0, ot.d)
    else:
        co = ot.centre
        cm = _proj(co, mv.p0, d)
    delta = (co - cm).DotProduct(n) + ot.ext(n) + mv.ext(n) + jeu + extra
    if delta < TOL:
        raise Exception("decalage nul")
    if mode == "decalage":
        if not mv.libre():
            raise Exception("troncon raccorde : decalage complet impossible")
        return {"mode": mode, "sens": sens, "delta": delta, "vec": n * delta, "long": mv.L}
    if sin < 0.25:
        raise Exception("reseaux paralleles : pas de baionnette possible")
    if ot.curve:
        dp = (d - ot.d * d.DotProduct(ot.d)).Normalize()
        demi = (ot.ext(dp) + jeu + mv.gros() * cos) / sin
    else:
        demi = ot.ext(d) + jeu
    demi += mv.gros()
    marge = max(2 * mv.gros(), 100 * MM)
    if coude > 0:
        # il faut la place des coudes : sur le plat, sur les pentes a 45 deg, aux bouts
        delta = max(delta, (2 * coude + 50 * MM) / 2 ** 0.5)
        demi = max(demi, coude + 25 * MM)
        marge = max(marge, coude + 50 * MM)
    tc = (cm - mv.p0).DotProduct(d)
    t1, t4 = tc - demi - delta, tc + demi + delta
    if t1 < marge or t4 > mv.L - marge:
        raise Exception("trop pres d'une extremite du troncon")
    return {"mode": mode, "sens": sens, "delta": delta, "long": 2 * (demi + delta),
            "bouts": min(t1, mv.L - t4),
            "q1": mv.p0 + d * t1, "q2": mv.p0 + d * (tc - demi) + n * delta,
            "q3": mv.p0 + d * (tc + demi) + n * delta, "q4": mv.p0 + d * t4}


def _bout(el, p):
    ln = el.Location.Curve
    return min(ln.GetEndPoint(0).DistanceTo(p), ln.GetEndPoint(1).DistanceTo(p)) < TOL


def _dedans(el, p):
    ln = el.Location.Curve
    a, b = ln.GetEndPoint(0), ln.GetEndPoint(1)
    return abs(a.DistanceTo(p) + b.DistanceTo(p) - a.DistanceTo(b)) < 1e-4 and not _bout(el, p)


def _copier_isolant(doc, src, cibles):
    try:
        ids = DB.InsulationLiningBase.GetInsulationIds(doc, src.Id)
        if not ids or ids.Count == 0:
            return
        iso = doc.GetElement(list(ids)[0])
        for c in cibles:
            try:
                if DB.InsulationLiningBase.GetInsulationIds(doc, c.Id).Count:
                    continue
                if isinstance(src, DB.Plumbing.Pipe):
                    DB.Plumbing.PipeInsulation.Create(doc, c.Id, iso.GetTypeId(), iso.Thickness)
                else:
                    DB.Mechanical.DuctInsulation.Create(doc, c.Id, iso.GetTypeId(), iso.Thickness)
            except Exception:
                pass
    except Exception:
        pass


def _sys_id(doc, el):
    sid = rel.system_type_id(el)
    if sid is not None and sid != DB.ElementId.InvalidElementId and doc.GetElement(sid) is not None:
        return sid
    cls = DB.Plumbing.PipingSystemType if isinstance(el, DB.Plumbing.Pipe) else DB.Mechanical.MechanicalSystemType
    return DB.FilteredElementCollector(doc).OfClass(cls).FirstElementId()


def executer(doc, el, pl):
    """Applique une solution (dans une transaction ouverte).
    Retourne les ids de tous les elements concernes."""
    if pl["mode"] == "decalage":
        DB.ElementTransformUtils.MoveElement(doc, el.Id, pl["vec"])
        doc.Regenerate()
        return [el.Id]
    q1, q2, q3, q4 = pl["q1"], pl["q2"], pl["q3"], pl["q4"]
    lvl = rel.level_of(el, doc)
    sid, tid, est_tuyau = _sys_id(doc, el), el.GetTypeId(), isinstance(el, DB.Plumbing.Pipe)

    def seg(pa, pb):
        if est_tuyau:
            s = DB.Plumbing.Pipe.Create(doc, sid, tid, lvl, pa, pb)
        else:
            s = DB.Mechanical.Duct.Create(doc, sid, tid, lvl, pa, pb)
        rel.copy_size(el, s)
        doc.Regenerate()
        return s
    pieces = [el, rel.break_curve(doc, el, q1)]
    cible = [p for p in pieces if _dedans(p, q4)][0]
    pieces.append(rel.break_curve(doc, cible, q4))
    mid = [p for p in pieces if _bout(p, q1) and _bout(p, q4)][0]
    a = [p for p in pieces if p.Id != mid.Id and _bout(p, q1)][0]
    b = [p for p in pieces if p.Id != mid.Id and _bout(p, q4)][0]
    pids = set(eid(p.Id) for p in pieces)
    for c in rel.connectors(mid):
        try:
            for r in list(c.AllRefs):
                if eid(r.Owner.Id) in pids and r.Owner.Id != mid.Id:
                    c.DisconnectFrom(r)
        except Exception:
            pass
    ln = mid.Location.Curve
    if ln.GetEndPoint(0).DistanceTo(q1) < ln.GetEndPoint(1).DistanceTo(q1):
        mid.Location.Curve = DB.Line.CreateBound(q2, q3)
    else:
        mid.Location.Curve = DB.Line.CreateBound(q3, q2)
    doc.Regenerate()
    s1, s2 = seg(q1, q2), seg(q3, q4)
    out = [a.Id, mid.Id, b.Id, s1.Id, s2.Id]
    coudes = []
    for x, p, y in ((a, q1, s1), (s1, q2, mid), (mid, q3, s2), (s2, q4, b)):
        f = doc.Create.NewElbowFitting(rel.conn_at(x, p), rel.conn_at(y, p))
        coudes.append(f)
        out.append(f.Id)
    doc.Regenerate()
    pl["coudes"] = [f.Id for f in coudes]
    _copier_isolant(doc, mid, [s1, s2] + coudes)
    doc.Regenerate()
    return out


class _Silence(DB.IFailuresPreprocessor):
    """Pas de fenetre d'erreur Revit : avertissements ignores, et s'il y a
    une vraie erreur la transaction est annulee sans rien afficher."""

    def PreprocessFailures(self, fa):
        try:
            for f in list(fa.GetFailureMessages()):
                if f.GetSeverity() != DB.FailureSeverity.Warning:
                    return DB.FailureProcessingResult.ProceedWithRollBack
            fa.DeleteAllWarnings()
        except Exception:
            pass
        return DB.FailureProcessingResult.Continue


def valider_tx(t):
    """Commit ; leve une Exception si Revit a refuse la modification."""
    if t.Commit() != DB.TransactionStatus.Committed:
        raise Exception("Revit a refuse la modification (raccords invalides)")


def jambe(doc, pl):
    """Longueur prise par un coude de chaque cote de son angle."""
    leg = 0.0
    pts = [pl["q1"], pl["q2"], pl["q3"], pl["q4"]]
    for i in pl.get("coudes", []):
        f = doc.GetElement(i)
        for c in rel.connectors(f):
            leg = max(leg, min(c.Origin.DistanceTo(q) for q in pts))
    return leg


def tient(pl, leg):
    """Vrai si les coudes ont la place (aucun troncon ecrase / retourne)."""
    if pl["mode"] != "baionnette":
        return True
    m = 20 * MM
    return (pl["q1"].DistanceTo(pl["q2"]) - 2 * leg >= m and
            pl["q2"].DistanceTo(pl["q3"]) - 2 * leg >= m and
            pl["bouts"] - leg >= m)


def tx_debut(doc, name):
    """Transaction (ou sous-transaction si une transaction est deja ouverte)."""
    if doc.IsModifiable:
        t = DB.SubTransaction(doc)
        t.Start()
        return t
    t = DB.Transaction(doc, name)
    t.Start()
    o = t.GetFailureHandlingOptions()
    o.SetFailuresPreprocessor(_Silence())
    try:
        o.SetClearAfterRollback(True)
        o.SetForcedModalHandling(False)
    except Exception:
        pass
    t.SetFailureHandlingOptions(o)
    return t


def verifier(doc, ids, pre, ot_id, univ):
    """Apres une modification : '' si OK, sinon la raison."""
    soi = set(eid(i) for i in ids)
    post, vs = set(), set()
    for i in ids:
        e = doc.GetElement(i)
        post |= touches(doc, e, univ)
        vs |= voisins(e)
    post -= soi
    if (ot_id if isinstance(ot_id, tuple) else eid(ot_id)) in post:
        return "touche encore l'autre reseau"
    nouveaux = post - pre - vs
    if nouveaux:
        return "creerait %d nouveau(x) clash(s)" % len(nouveaux)
    return ""


def simuler(doc, clash, mv, ot, sens, jeu, univ, mode):
    """Essaie la solution dans Revit puis annule. Retourne le plan valide
    (sans nouveau clash) ou leve une Exception avec la raison."""
    pre = touches(doc, mv.el, univ)
    coude = 0.0
    if mode == "baionnette":
        coude = mesurer_coude(doc, mv, direction(mv, sens))
    raison = ""
    for extra in PAS:
        pl = plan(mv, ot, clash.pt, sens, jeu, extra * MM, mode, coude)
        t = tx_debut(doc, "Allan BIM - essai clash")
        try:
            ids = executer(doc, mv.el, pl)
            if mode == "baionnette" and not tient(pl, jambe(doc, pl)):
                raison = "pas la place pour les coudes"
            else:
                raison = verifier(doc, ids, pre, ot.id, univ)
        except Exception as ex:
            raison = "raccords impossibles (%s)" % str(ex).split("\n")[0][:80]
        finally:
            t.RollBack()
        if not raison:
            return pl
    raise Exception(raison)


class Var(object):
    def __init__(self, mv, ot, sens, mode, pl=None, raison=""):
        self.mv, self.ot, self.sens, self.mode = mv, ot, sens, mode
        self.pl, self.raison = pl, raison
        self.ok = pl is not None
        self.reco = False

    def cout(self):
        pl, mv = self.pl, self.mv
        if self.mode == "decalage":
            c = pl["delta"] * 0.5 + pl["long"] * 0.05
        else:
            c = 2 * pl["delta"] + pl["long"]
        c *= (1.0 + mv.gros() / (150 * MM))                 # gros reseau = plus cher a devier
        if self.sens == "dessous":
            c *= 1.15                                        # perte de hauteur libre
        if self.sens in ("gauche", "droite"):
            c *= 1.25
        if mv.pipe and abs(mv.d.Z) > 0.002:                  # tuyau en pente (ecoulement)
            c *= 5.0 if self.sens == "dessus" else 1.5
        return c

    def texte(self):
        if self.mv is None:
            return self.raison
        qui = "%s (id %s)" % (self.mv.nom, eid(self.mv.id))
        if not self.ok:
            return "Impossible : %s.\n%s" % (self.raison, qui)
        mm = round(self.pl["delta"] / MM)
        if self.mode == "decalage":
            return "%s : tout le troncon est decale %s de %d mm, aucun raccord.\nAucun nouveau clash." % (
                qui, TXT_SENS[self.sens], mm)
        return "%s passe %s : baionnette de %d mm, 4 coudes a 45 deg, sur %.2f m.\nAucun nouveau clash." % (
            qui, TXT_SENS[self.sens], mm, self.pl["long"] * 0.3048)


def variantes(doc, clash, jeu, univ):
    """[dessus, dessous, proposition] - chacune simulee et verifiee."""
    cands = []
    for mv, ot in ((clash.a, clash.b), (clash.b, clash.a)):
        if mv.curve:
            cands.append((mv, ot))
    cands.sort(key=lambda x: (x[0].vertical(), x[0].pipe and abs(x[0].d.Z) > 0.002, x[0].section()))
    cache = {}

    def ev(mv, ot, sens, mode):
        k = (eid(mv.id), sens, mode)
        if k not in cache:
            try:
                cache[k] = Var(mv, ot, sens, mode, simuler(doc, clash, mv, ot, sens, jeu, univ, mode))
            except Exception as ex:
                cache[k] = Var(mv, ot, sens, mode, None, str(ex))
        return cache[k]

    out = []
    for sens in ("dessus", "dessous"):
        v = None
        for mv, ot in cands:
            w = ev(mv, ot, sens, "baionnette")
            if v is None or w.ok:
                v = w
            if w.ok:
                break
        out.append(v)
    pool = []
    for mv, ot in cands:
        for sens in SENS:
            for mode in ("decalage", "baionnette"):
                w = ev(mv, ot, sens, mode)
                if w.ok and w not in out:
                    pool.append(w)
    if pool:
        out.append(min(pool, key=lambda v: v.cout()))
    else:
        out.append(Var(None, None, "", "", None, "Pas d'autre solution sans nouveau clash."))
    oks = [v for v in out if v.ok]
    if oks:
        min(oks, key=lambda v: v.cout()).reco = True
    return out


def appliquer(doc, clash, var, univ):
    """Applique pour de bon (transaction validee). Leve une Exception si la
    solution n'est plus valable (nouveau clash) - dans ce cas rien n'est modifie.
    Retourne les ids des elements de la solution."""
    pre = touches(doc, var.mv.el, univ)
    t = tx_debut(doc, "Allan BIM - resoudre clash")
    try:
        ids = executer(doc, var.mv.el, var.pl)
        if var.mode == "baionnette" and not tient(var.pl, jambe(doc, var.pl)):
            raise Exception("pas la place pour les coudes")
        raison = verifier(doc, ids, pre, var.ot.id, univ)
        if raison:
            raise Exception(raison)
        valider_tx(t)
        return ids
    except Exception:
        try:
            t.RollBack()
        except Exception:
            pass
        raise


# ------------------------------------------------------------ vues
def _plein(doc):
    for f in DB.FilteredElementCollector(doc).OfClass(DB.FillPatternElement):
        try:
            if f.GetFillPattern().IsSolidFill:
                return f.Id
        except Exception:
            pass
    return None


ROUGE, BLEU = (230, 40, 40), (40, 110, 230)


def colorer(doc, vue_ids, ids, rgb):
    plein = _plein(doc)
    for vid in vue_ids:
        v = doc.GetElement(vid)
        if v is None:
            continue
        for i in ids:
            _couleur(doc, v, i, rgb, plein)


def _couleur(doc, view, el_id, rgb, plein):
    try:
        col = DB.Color(rgb[0], rgb[1], rgb[2])
        o = DB.OverrideGraphicSettings()
        o.SetProjectionLineColor(col)
        o.SetCutLineColor(col)
        if plein:
            o.SetSurfaceForegroundPatternId(plein)
            o.SetSurfaceForegroundPatternColor(col)
            o.SetCutForegroundPatternId(plein)
            o.SetCutForegroundPatternColor(col)
        view.SetElementOverrides(el_id, o)
    except Exception:
        pass


def supprimer_vues(doc):
    for v in list(DB.FilteredElementCollector(doc).OfClass(DB.View)):
        try:
            if nom(v) in (VUE_COUPE, VUE_3D):
                doc.Delete(v.Id)
        except Exception:
            pass


def boite3d(doc, vid, tr3, box):
    """Regle la zone de coupe de la vue 3D : demi-dimensions (le long du
    reseau, en travers, en hauteur) autour du clash."""
    sb = DB.BoundingBoxXYZ()
    sb.Transform = tr3
    sb.Min = DB.XYZ(-box[0], -box[1], -box[2])
    sb.Max = DB.XYZ(box[0], box[1], box[2])
    doc.GetElement(vid).SetSectionBox(sb)


def preparer_vues(doc, clash, k=1.0, box3=None):
    """Cree la coupe et la vue 3D centrees sur le clash (dans une transaction).
    Retourne {"coupe": id, "3d": id}."""
    supprimer_vues(doc)
    types = list(DB.FilteredElementCollector(doc).OfClass(DB.ViewFamilyType))
    ts = [t for t in types if t.ViewFamily == DB.ViewFamily.Section][0]
    t3 = [t for t in types if t.ViewFamily == DB.ViewFamily.ThreeDimensional][0]
    pt = clash.pt
    ref = None
    for n in (clash.a, clash.b):
        if n.curve and not n.vertical():
            if ref is None or n.section() < ref.section():
                ref = n
    x = DB.XYZ.BasisX
    if ref is not None:
        x = DB.XYZ(ref.d.X, ref.d.Y, 0).Normalize()
    y = DB.XYZ.BasisZ
    tr = DB.Transform.Identity
    tr.Origin, tr.BasisX, tr.BasisY, tr.BasisZ = pt, x, y, x.CrossProduct(y)
    g = max(clash.a.gros(), clash.b.gros())
    lx, ly, lz = (1500 * MM + 4 * g) * k, (800 * MM + 3 * g) * k, (500 * MM + g) * k
    box = DB.BoundingBoxXYZ()
    box.Transform = tr
    box.Min, box.Max = DB.XYZ(-lx, -ly, -lz), DB.XYZ(lx, ly, lz)
    coupe = DB.ViewSection.CreateSection(doc, ts.Id, box)
    v3 = DB.View3D.CreateIsometric(doc, t3.Id)
    tr3 = DB.Transform.Identity
    tr3.Origin, tr3.BasisX, tr3.BasisY, tr3.BasisZ = pt, x, DB.XYZ.BasisZ.CrossProduct(x), DB.XYZ.BasisZ
    box3 = box3 or (lx, lx, ly)
    doc.Regenerate()
    boite3d(doc, v3.Id, tr3, box3)
    plein = _plein(doc)
    for v, name, sc in ((coupe, VUE_COUPE, 20), (v3, VUE_3D, 50)):
        for fn in (lambda: setattr(v, "ViewTemplateId", DB.ElementId.InvalidElementId),
                   lambda: setattr(v, "Name", name),
                   lambda: setattr(v, "Scale", sc),
                   lambda: setattr(v, "Discipline", DB.ViewDiscipline.Coordination),
                   lambda: setattr(v, "DetailLevel", DB.ViewDetailLevel.Fine),
                   lambda: setattr(v, "DisplayStyle", DB.DisplayStyle.ShadingWithEdges)):
            try:
                fn()
            except Exception:
                pass
        _couleur(doc, v, clash.a.id, ROUGE, plein)
        _couleur(doc, v, clash.b.id, BLEU, plein)
    doc.Regenerate()
    return {"coupe": coupe.Id, "3d": v3.Id, "tr3": tr3, "box": box3}
