# -*- coding: utf-8 -*-
"""Allan BIM - modelisation d'un trace dessine entre deux reseaux.

build_route(doc, e1, pick1, points, e2=None, pick2=None)
  e1     : 1re gaine / tuyau (depart)
  pick1  : point clique sur e1 (sert a choisir le bon bout)
  points : points de passage (XYZ) dans l'ordre
  e2     : 2e gaine / tuyau (arrivee) ou None = extremite libre
Cree les troncons (meme type, taille, systeme que e1), un coude a chaque
changement de direction, et raccorde au depart et a l'arrivee
(coude, te/piquage ou reduction). A appeler dans une transaction.
"""

import math
from Autodesk.Revit import DB
import allan_relier as rel

MM = 1.0 / 304.8
MIN_SEG = 150 * MM          # longueur mini d'un troncon (place pour les coudes)


# ------------------------------------------------------------ geometrie
def view_axes(view):
    return view.RightDirection.Normalize(), view.UpDirection.Normalize(), view.ViewDirection.Normalize()


def to_plane(pt, origin, normal):
    """Projette pt sur le plan (origin, normal)."""
    return pt - normal * (pt - origin).DotProduct(normal)


def ortho_snap(prev, pt, u, v, tol_deg=10.0):
    """Si le segment prev->pt est presque horizontal / vertical (dans la vue),
    on le rend parfaitement horizontal / vertical."""
    d = pt - prev
    du, dv = d.DotProduct(u), d.DotProduct(v)
    if abs(du) < 1e-9 and abs(dv) < 1e-9:
        return pt
    ang = math.degrees(math.atan2(abs(dv), abs(du)))
    rest = d - u * du - v * dv
    if ang < tol_deg:
        return prev + u * du + rest
    if ang > 90 - tol_deg:
        return prev + v * dv + rest
    return pt


def end_connector_near(el, pt):
    best = None
    for c in rel.connectors(el):
        if c.ConnectorType != DB.ConnectorType.End:
            continue
        d = c.Origin.DistanceTo(pt)
        if not c.IsConnected:
            d *= 0.5            # on prefere un bout libre
        if best is None or d < best[0]:
            best = (d, c)
    return best[1] if best else None


def clean_points(pts):
    """Retire les points doublons et les points alignes (inutiles)."""
    out = []
    for p in pts:
        if out and out[-1].DistanceTo(p) < 5 * MM:
            continue
        out.append(p)
    i = 1
    while i < len(out) - 1:
        a = (out[i] - out[i - 1]).Normalize()
        b = (out[i + 1] - out[i]).Normalize()
        if a.DotProduct(b) > 0.9999:
            out.pop(i)
        else:
            i += 1
    return out


# ------------------------------------------------------------ modelisation
def build_route(doc, e1, pick1, points, e2=None, pick2=None):
    """Retourne (nb_troncons, nb_coudes, message_arrivee)."""
    if not rel.is_curve(e1):
        raise Exception("le depart doit etre une gaine ou un tuyau")
    c_start = end_connector_near(e1, pick1)
    if c_start is None:
        raise Exception("aucun bout de reseau trouve sur le 1er element")
    lvl = rel.level_of(e1, doc)

    # ---- arrivee : bout de e2, ou milieu de e2 (te)
    end_mode, c_end, tee_pt = "libre", None, None
    if e2 is not None:
        ref = points[-1] if points else c_start.Origin
        c2 = end_connector_near(e2, pick2 or ref) if rel.is_curve(e2) else \
            min(rel.connectors(e2), key=lambda c: c.Origin.DistanceTo(ref))
        if rel.is_curve(e2):
            crv = e2.Location.Curve
            proj = crv.Project(ref)
            p0, p1 = crv.GetEndPoint(0), crv.GetEndPoint(1)
            if proj is not None and proj.XYZPoint.DistanceTo(p0) > 300 * MM and \
                    proj.XYZPoint.DistanceTo(p1) > 300 * MM and \
                    (c2 is None or c2.Origin.DistanceTo(ref) > proj.XYZPoint.DistanceTo(ref)):
                end_mode, tee_pt = "te", proj.XYZPoint
            else:
                end_mode, c_end = "bout", c2
        else:
            end_mode, c_end = "bout", c2

    pts = [c_start.Origin] + list(points)
    if end_mode == "bout":
        pts.append(c_end.Origin)
    elif end_mode == "te":
        pts.append(tee_pt)
    pts = clean_points(pts)
    if len(pts) < 2:
        raise Exception("trace trop court")
    for a, b in zip(pts[:-1], pts[1:]):
        if a.DistanceTo(b) < MIN_SEG:
            raise Exception("un troncon fait moins de %d mm : pas la place pour les coudes. "
                            "Espace un peu plus tes points." % int(MIN_SEG * 304.8))

    # ---- changement de diametre / section a l'arrivee ?
    reduc = False
    if end_mode == "bout" and rel.is_curve(e2):
        reduc = not rel.same_size(c_start, c_end) or \
            doc.GetElement(e1.GetTypeId()).Shape != doc.GetElement(e2.GetTypeId()).Shape
    if reduc and pts[-2].DistanceTo(pts[-1]) < 2 * MIN_SEG:
        raise Exception("les deux reseaux n'ont pas la meme taille : le dernier troncon doit faire "
                        "au moins %d mm pour placer la reduction." % int(2 * MIN_SEG * 304.8))

    # ---- troncons
    segs = []
    for k, (a, b) in enumerate(zip(pts[:-1], pts[1:])):
        if reduc and k == len(pts) - 2:
            # dernier troncon coupe en deux : taille du depart puis taille de l'arrivee
            mid = a + (b - a) * 0.5
            sa = rel.new_segment(doc, e1, a, mid, lvl)
            sb = rel.new_segment(doc, e2, mid, b, lvl, size_from=e2)
            doc.Regenerate()
            rel.join_straight(doc, rel.conn_at(sa, mid), rel.conn_at(sb, mid))
            segs.append(sa)
            last_seg = sb
        else:
            segs.append(rel.new_segment(doc, e1, a, b, lvl))
    doc.Regenerate()

    coudes = 0
    # depart
    r = rel.join_angle(doc, c_start, rel.conn_at(segs[0], pts[0]))
    coudes += 1 if r == "coude" else 0
    # coudes intermediaires
    for i in range(len(segs) - 1):
        p = pts[i + 1]
        r = rel.join_angle(doc, rel.conn_at(segs[i], p), rel.conn_at(segs[i + 1], p))
        coudes += 1 if r == "coude" else 0
    # arrivee
    msg = "extremite libre"
    last = last_seg if reduc else segs[-1]
    if end_mode == "bout":
        r = rel.join_angle(doc, rel.conn_at(last, pts[-1]), c_end)
        coudes += 1 if r == "coude" else 0
        msg = "raccorde au 2e reseau (%s%s)" % (r, " + reduction" if reduc else "")
    elif end_mode == "te":
        branch = rel.conn_at(last, pts[-1])
        msg = "raccorde au 2e reseau (%s)" % rel._te(doc, last, branch, e2, pts[-1])
    # ---- controle : un troncon trop court est ecrase / retourne par ses coudes
    doc.Regenerate()
    for k, sg in enumerate(segs):
        try:
            ln = sg.Location.Curve
            d = (ln.GetEndPoint(1) - ln.GetEndPoint(0))
            voulu = pts[k + 1] - pts[k]
            mauvais = d.GetLength() < 10 * MM or d.DotProduct(voulu) <= 0
        except Exception:
            mauvais = False
        if mauvais:
            raise Exception("le troncon %d (%d mm) est trop court pour ses coudes : "
                            "allonge-le ou ecarte les points." % (k + 1, int(voulu.GetLength() * 304.8)))
    return len(segs), coudes, msg


# ------------------------------------------------------------ plan de dessin
def set_work_plane(doc, view, origin):
    """Plan de travail de la vue passant par origin (a la hauteur du reseau en
    plan, dans le plan de la coupe en coupe). A appeler dans une transaction."""
    n = view.ViewDirection.Normalize()
    sp = DB.SketchPlane.Create(doc, DB.Plane.CreateByNormalAndOrigin(n, origin))
    view.SketchPlane = sp
    return sp
