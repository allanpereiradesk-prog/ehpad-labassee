# -*- coding: utf-8 -*-
"""Allan BIM - outils reseaux : Calorifuge auto et Couleurs reseaux.

Calorifuge auto
  Des regles "systeme + plage de diametre -> type d'isolant + epaisseur"
  sont appliquees aux canalisations / gaines (et a leurs raccords et
  accessoires). On analyse d'abord (ce qui va etre ajoute / modifie),
  puis on applique.

Couleurs reseaux
  Un filtre de vue par type de systeme (tuyaux, raccords, accessoires,
  isolants, bouches, appareils...) avec une couleur, applique aux vues ou
  aux gabarits de vue choisis. Marche en plan, coupe, elevation et 3D.
"""

import json
import os
import clr
from System.Collections.Generic import List
from Autodesk.Revit import DB
from Autodesk.Revit.DB.Plumbing import PipingSystemType, PipeInsulationType, PipeInsulation
from Autodesk.Revit.DB.Mechanical import MechanicalSystemType, DuctInsulationType, DuctInsulation

MM = 1.0 / 304.8
CANA = u"Canalisations"
GAINE = u"Gaines"
TOUS = u"(tous les systèmes)"
GRP = u"▸ "

MSC = DB.MEPSystemClassification
GROUPES = [
    (CANA, u"Hydraulique (chauffage / eau glacée)", [MSC.SupplyHydronic, MSC.ReturnHydronic]),
    (CANA, u"Eau chaude sanitaire", [MSC.DomesticHotWater]),
    (CANA, u"Eau froide sanitaire", [MSC.DomesticColdWater]),
    (GAINE, u"Soufflage", [MSC.SupplyAir]),
    (GAINE, u"Reprise", [MSC.ReturnAir]),
    (GAINE, u"Extraction", [MSC.ExhaustAir]),
    (GAINE, u"Air neuf / autre air", [MSC.OtherAir]),
]


def _id(e):
    i = e.Id if not isinstance(e, DB.ElementId) else e
    return i.Value if hasattr(i, "Value") else i.IntegerValue


def nom(e):
    try:
        return DB.Element.Name.GetValue(e)
    except Exception:
        return getattr(e, "Name", u"?")


# =================================================================== CALORIFUGE
def types_isolant(doc, cat):
    cls = PipeInsulationType if cat == CANA else DuctInsulationType
    return sorted([nom(t) for t in DB.FilteredElementCollector(doc).OfClass(cls)])


def systemes(doc, cat):
    cls = PipingSystemType if cat == CANA else MechanicalSystemType
    return sorted([nom(t) for t in DB.FilteredElementCollector(doc).OfClass(cls)])


def choix_systemes(doc, cat):
    """Liste proposee dans la colonne Systeme : tous / groupes / types du projet."""
    return [TOUS] + [GRP + g[1] for g in GROUPES if g[0] == cat] + systemes(doc, cat)


def regles_defaut(doc):
    """Exemple de regles courantes (a adapter au CCTP du projet)."""
    pi = types_isolant(doc, CANA)
    di = types_isolant(doc, GAINE)
    pi0 = ([t for t in pi if u"laine" in t.lower()] or pi or [u""])[0]
    di0 = ([t for t in di if u"fibre" in t.lower() or u"laine" in t.lower()] or di or [u""])[0]
    return [
        {"cat": CANA, "sys": GRP + u"Hydraulique (chauffage / eau glacée)", "dmin": 0, "dmax": 25, "type": pi0, "ep": 25},
        {"cat": CANA, "sys": GRP + u"Hydraulique (chauffage / eau glacée)", "dmin": 26, "dmax": 50, "type": pi0, "ep": 30},
        {"cat": CANA, "sys": GRP + u"Hydraulique (chauffage / eau glacée)", "dmin": 51, "dmax": 9999, "type": pi0, "ep": 40},
        {"cat": CANA, "sys": GRP + u"Eau chaude sanitaire", "dmin": 0, "dmax": 9999, "type": pi0, "ep": 25},
        {"cat": GAINE, "sys": GRP + u"Soufflage", "dmin": 0, "dmax": 99999, "type": di0, "ep": 25},
        {"cat": GAINE, "sys": GRP + u"Air neuf / autre air", "dmin": 0, "dmax": 99999, "type": di0, "ep": 25},
    ]


def fichier_regles(ext_dir):
    return os.path.join(ext_dir, "Familles", "calorifuge_regles.json")


def charger_regles(ext_dir, doc):
    try:
        with open(fichier_regles(ext_dir), "r") as f:
            r = json.loads(f.read())
            if isinstance(r, list) and r:
                return r
    except Exception:
        pass
    return regles_defaut(doc)


def sauver_regles(ext_dir, regles):
    try:
        p = fichier_regles(ext_dir)
        d = os.path.dirname(p)
        if not os.path.isdir(d):
            os.makedirs(d)
        with open(p, "w") as f:
            f.write(json.dumps(regles, indent=1))
        return True
    except Exception:
        return False


_CATS = {
    CANA: [DB.BuiltInCategory.OST_PipeCurves, DB.BuiltInCategory.OST_PipeFitting, DB.BuiltInCategory.OST_PipeAccessory],
    GAINE: [DB.BuiltInCategory.OST_DuctCurves, DB.BuiltInCategory.OST_DuctFitting, DB.BuiltInCategory.OST_DuctAccessory],
}
_SYS_PARAM = {CANA: DB.BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM, GAINE: DB.BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM}


def _taille_mm(el, cat):
    """Diametre nominal (tuyau / gaine ronde) ou plus grand cote (gaine rect.)."""
    try:
        if cat == CANA:
            p = el.get_Parameter(DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM)
            if p is not None and p.HasValue and p.AsDouble() > 0:
                return p.AsDouble() / MM
        else:
            for bip in (DB.BuiltInParameter.RBS_CURVE_DIAMETER_PARAM,):
                p = el.get_Parameter(bip)
                if p is not None and p.HasValue and p.AsDouble() > 0:
                    return p.AsDouble() / MM
            w = el.get_Parameter(DB.BuiltInParameter.RBS_CURVE_WIDTH_PARAM)
            h = el.get_Parameter(DB.BuiltInParameter.RBS_CURVE_HEIGHT_PARAM)
            if w is not None and w.HasValue and w.AsDouble() > 0:
                return max(w.AsDouble(), h.AsDouble() if h is not None else 0) / MM
    except Exception:
        pass
    # raccords / accessoires : plus grand connecteur
    best = 0.0
    try:
        cm = el.MEPModel.ConnectorManager if hasattr(el, "MEPModel") and el.MEPModel else el.ConnectorManager
        for c in cm.Connectors:
            if c.Shape == DB.ConnectorProfileType.Round:
                best = max(best, 2 * c.Radius)
            else:
                best = max(best, c.Width, c.Height)
    except Exception:
        pass
    return best / MM


def _systeme(doc, el, cat):
    """(nom du type de systeme, classification) de l'element, ou (None, None)."""
    st = None
    p = el.get_Parameter(_SYS_PARAM[cat])
    if p is not None and p.HasValue:
        i = p.AsElementId()
        if i is not None and i != DB.ElementId.InvalidElementId:
            st = doc.GetElement(i)
    if st is None:
        try:
            cm = el.MEPModel.ConnectorManager if hasattr(el, "MEPModel") and el.MEPModel else el.ConnectorManager
            for c in cm.Connectors:
                if c.MEPSystem is not None:
                    st = doc.GetElement(c.MEPSystem.GetTypeId())
                    break
        except Exception:
            pass
    if st is None:
        return None, None
    try:
        return nom(st), st.SystemClassification
    except Exception:
        return nom(st), None


def _regle_ok(r, cat, sysnom, sysclass, taille):
    if r.get("cat") != cat:
        return False
    s = r.get("sys") or TOUS
    if s != TOUS:
        if sysnom is None:
            return False
        if s.startswith(GRP):
            g = [x for x in GROUPES if x[1] == s[len(GRP):]]
            if not g or sysclass not in g[0][2]:
                return False
        elif s != sysnom:
            return False
    try:
        return float(r.get("dmin", 0)) <= taille + 1e-6 and taille <= float(r.get("dmax", 99999)) + 1e-6
    except Exception:
        return False


def elements(doc, cat, portee, uidoc=None, raccords=True, accessoires=True):
    cats = list(_CATS[cat][:1])
    if raccords:
        cats.append(_CATS[cat][1])
    if accessoires:
        cats.append(_CATS[cat][2])
    res = []
    if portee == "selection" and uidoc is not None:
        ids = list(uidoc.Selection.GetElementIds())
        cids = set(int(c) for c in cats)
        for i in ids:
            e = doc.GetElement(i)
            try:
                if e is not None and e.Category is not None and _id(e.Category) in cids:
                    res.append(e)
            except Exception:
                pass
        return res
    for c in cats:
        col = DB.FilteredElementCollector(doc, doc.ActiveView.Id) if portee == "vue" else DB.FilteredElementCollector(doc)
        res.extend(list(col.OfCategory(c).WhereElementIsNotElementType()))
    return res


class Action(object):
    def __init__(self, el, cat, quoi, type_nom=None, ep=None, ins=None, regle=None, info=u""):
        self.el, self.cat, self.quoi = el, cat, quoi
        self.type_nom, self.ep, self.ins, self.regle, self.info = type_nom, ep, ins, regle, info


def analyser(doc, regles, portee, uidoc=None, raccords=True, accessoires=True, mettre_a_jour=True, supprimer=False):
    """Renvoie la liste des Action (quoi = ajouter / modifier / ok / supprimer / sans)."""
    actions = []
    tins = {CANA: dict((nom(t), t) for t in DB.FilteredElementCollector(doc).OfClass(PipeInsulationType)),
            GAINE: dict((nom(t), t) for t in DB.FilteredElementCollector(doc).OfClass(DuctInsulationType))}
    for cat in (CANA, GAINE):
        if not any(r.get("cat") == cat for r in regles) and not supprimer:
            continue
        for el in elements(doc, cat, portee, uidoc, raccords, accessoires):
            try:
                sysnom, sysclass = _systeme(doc, el, cat)
                taille = _taille_mm(el, cat)
                regle = None
                for i, r in enumerate(regles):
                    if _regle_ok(r, cat, sysnom, sysclass, taille):
                        regle = (i, r)
                        break
                ids = list(DB.InsulationLiningBase.GetInsulationIds(doc, el.Id))
                ins = None
                for i in ids:
                    x = doc.GetElement(i)
                    if isinstance(x, (PipeInsulation, DuctInsulation)):
                        ins = x
                        break
                info = u"%s - %.0f mm" % (sysnom or u"sans système", taille)
                if regle is None:
                    if ins is not None and supprimer:
                        actions.append(Action(el, cat, "supprimer", ins=ins, info=info))
                    else:
                        actions.append(Action(el, cat, "sans", ins=ins, info=info))
                    continue
                r = regle[1]
                t = tins[cat].get(r.get("type"))
                if t is None:
                    actions.append(Action(el, cat, "sans", info=info + u" - type d'isolant introuvable : %s" % r.get("type")))
                    continue
                ep = float(r.get("ep", 0)) * MM
                if ins is None:
                    actions.append(Action(el, cat, "ajouter", t, ep, None, regle[0], info))
                elif abs(ins.Thickness - ep) > 1e-6 or ins.GetTypeId() != t.Id:
                    actions.append(Action(el, cat, "modifier" if mettre_a_jour else "ok", t, ep, ins, regle[0], info))
                else:
                    actions.append(Action(el, cat, "ok", t, ep, ins, regle[0], info))
            except Exception as ex:
                actions.append(Action(el, cat, "sans", info=u"erreur : %s" % ex))
    return actions


def appliquer(doc, actions, log):
    n = {"ajouter": 0, "modifier": 0, "supprimer": 0, "erreur": 0}
    t = DB.Transaction(doc, u"Allan BIM - Calorifuge auto")
    t.Start()
    try:
        for a in actions:
            try:
                if a.quoi == "ajouter":
                    if a.cat == CANA:
                        PipeInsulation.Create(doc, a.el.Id, a.type_nom.Id, a.ep)
                    else:
                        DuctInsulation.Create(doc, a.el.Id, a.type_nom.Id, a.ep)
                    n["ajouter"] += 1
                elif a.quoi == "modifier":
                    if a.ins.GetTypeId() != a.type_nom.Id:
                        a.ins.ChangeTypeId(a.type_nom.Id)
                    a.ins.Thickness = a.ep
                    n["modifier"] += 1
                elif a.quoi == "supprimer":
                    doc.Delete(a.ins.Id)
                    n["supprimer"] += 1
            except Exception as ex:
                n["erreur"] += 1
                if n["erreur"] <= 10:
                    log.append(u"Élément %s : %s" % (_id(a.el), ex))
        t.Commit()
    except Exception as ex:
        if t.HasStarted() and not t.HasEnded():
            t.RollBack()
        log.append(u"Annulé : %s" % ex)
        return n
    log.append(u"Calorifuge : %d ajouté(s), %d modifié(s), %d supprimé(s), %d erreur(s)."
               % (n["ajouter"], n["modifier"], n["supprimer"], n["erreur"]))
    return n


def importer_types_isolant(doc, log):
    """Copie les types d'isolant d'un gabarit Revit si le projet n'en a pas."""
    app = doc.Application
    dossier = os.path.dirname(app.DefaultProjectTemplate or u"")
    candidats = [os.path.join(dossier, n) for n in ("Systems-DefaultFRAFRA.rte", "Mechanical-DefaultFRAFRA.rte")]
    candidats = [c for c in candidats if os.path.exists(c)]
    if not candidats:
        log.append(u"Aucun gabarit Revit trouvé pour récupérer des types d'isolant.")
        return False
    src = app.OpenDocumentFile(candidats[0])
    try:
        ids = List[DB.ElementId]()
        for cls in (PipeInsulationType, DuctInsulationType):
            deja = set(nom(t) for t in DB.FilteredElementCollector(doc).OfClass(cls))
            for t in DB.FilteredElementCollector(src).OfClass(cls):
                if nom(t) not in deja:
                    ids.Add(t.Id)
        if ids.Count == 0:
            log.append(u"Les types d'isolant du gabarit sont déjà dans le projet.")
            return True
        t = DB.Transaction(doc, u"Allan BIM - Types d'isolant")
        t.Start()
        opt = DB.CopyPasteOptions()
        DB.ElementTransformUtils.CopyElements(src, ids, doc, DB.Transform.Identity, opt)
        t.Commit()
        log.append(u"%d type(s) d'isolant importé(s) depuis %s." % (ids.Count, os.path.basename(candidats[0])))
        return True
    finally:
        src.Close(False)


# =================================================================== COULEURS RESEAUX
PREFIXE = u"AB Réseau - "
PALETTE = {
    MSC.SupplyAir: (0, 112, 255), MSC.ReturnAir: (220, 0, 180), MSC.ExhaustAir: (0, 170, 60),
    MSC.OtherAir: (255, 150, 0),
    MSC.SupplyHydronic: (230, 0, 0), MSC.ReturnHydronic: (0, 120, 230),
    MSC.DomesticHotWater: (255, 60, 60), MSC.DomesticColdWater: (0, 160, 255),
    MSC.Sanitary: (140, 90, 40), MSC.Vent: (150, 150, 150),
    MSC.FireProtectWet: (200, 0, 0), MSC.FireProtectDry: (200, 0, 0),
    MSC.FireProtectPreaction: (200, 0, 0), MSC.FireProtectOther: (200, 0, 0),
    MSC.OtherPipe: (120, 120, 120),
}
MOTS = [(u"glac", (0, 200, 220)), (u"retour", (0, 120, 230)), (u"aller", (230, 0, 0)), (u"chauffage", (230, 0, 0)),
        (u"pluvial", (0, 150, 120)), (u"vanne", (110, 70, 30)), (u"usée", (140, 90, 40)), (u"usee", (140, 90, 40)),
        (u"gaz", (255, 200, 0)), (u"rejet", (150, 110, 0)), (u"air neuf", (255, 150, 0)), (u"vmc", (0, 170, 60)),
        (u"désenfumage", (120, 0, 160)), (u"desenfumage", (120, 0, 160))]

CATS_CANA = ["OST_PipeCurves", "OST_PipeFitting", "OST_PipeAccessory", "OST_PipeInsulations",
             "OST_FlexPipeCurves", "OST_PlumbingFixtures", "OST_Sprinklers"]
CATS_GAINE = ["OST_DuctCurves", "OST_DuctFitting", "OST_DuctAccessory", "OST_DuctInsulations", "OST_DuctLinings",
              "OST_FlexDuctCurves", "OST_DuctTerminal"]


class Systeme(object):
    def __init__(self, st, cat, nb):
        self.st, self.cat, self.nb = st, cat, nb
        self.nom = nom(st)
        self.couleur = couleur_defaut(st)


def couleur_defaut(st):
    n = nom(st).lower()
    for mot, c in MOTS:
        if mot in n:
            return c
    try:
        c = PALETTE.get(st.SystemClassification)
        if c:
            return c
    except Exception:
        pass
    return (128, 128, 128)


def lister_systemes(doc):
    res = []
    for cls, cat, bip, oc in ((PipingSystemType, CANA, DB.BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM, DB.BuiltInCategory.OST_PipeCurves),
                              (MechanicalSystemType, GAINE, DB.BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM, DB.BuiltInCategory.OST_DuctCurves)):
        compte = {}
        for e in DB.FilteredElementCollector(doc).OfCategory(oc).WhereElementIsNotElementType():
            p = e.get_Parameter(bip)
            if p is not None and p.HasValue:
                k = _id(p.AsElementId())
                compte[k] = compte.get(k, 0) + 1
        for st in DB.FilteredElementCollector(doc).OfClass(cls):
            res.append(Systeme(st, cat, compte.get(_id(st), 0)))
    res.sort(key=lambda s: (s.cat, -s.nb, s.nom.lower()))
    return res


def _cats_valides(doc, noms, bip):
    ids = List[DB.ElementId]()
    for n in noms:
        try:
            c = getattr(DB.BuiltInCategory, n)
        except AttributeError:
            continue
        one = List[DB.ElementId]()
        one.Add(DB.ElementId(c))
        try:
            ok = any(_id(p) == int(bip) for p in DB.ParameterFilterUtilities.GetFilterableParametersInCommon(doc, one))
        except Exception:
            ok = False
        if ok:
            ids.Add(DB.ElementId(c))
    return ids


def _remplissage_plein(doc):
    for f in DB.FilteredElementCollector(doc).OfClass(DB.FillPatternElement):
        try:
            if f.GetFillPattern().IsSolidFill:
                return f.Id
        except Exception:
            pass
    return None


def filtre_systeme(doc, s):
    """Cree ou met a jour le filtre de vue d'un type de systeme. Renvoie son Id."""
    bip = DB.BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM if s.cat == CANA else DB.BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM
    cats = _cats_valides(doc, CATS_CANA if s.cat == CANA else CATS_GAINE, bip)
    regle = DB.ParameterFilterRuleFactory.CreateEqualsRule(DB.ElementId(bip), s.st.Id)
    filtre = DB.ElementParameterFilter(regle)
    nomf = PREFIXE + s.nom
    for c in u'\\:{}[]|;<>?`~':
        nomf = nomf.replace(c, u"-")
    ex = [f for f in DB.FilteredElementCollector(doc).OfClass(DB.ParameterFilterElement) if f.Name == nomf]
    if ex:
        pf = ex[0]
        pf.SetCategories(cats)
        pf.SetElementFilter(filtre)
    else:
        pf = DB.ParameterFilterElement.Create(doc, nomf, cats, filtre)
    return pf.Id


def reglages(doc, couleur, remplir=True, epaisseur=None):
    ogs = DB.OverrideGraphicSettings()
    c = DB.Color(couleur[0], couleur[1], couleur[2])
    ogs.SetProjectionLineColor(c)
    ogs.SetCutLineColor(c)
    if epaisseur:
        ogs.SetProjectionLineWeight(epaisseur)
    if remplir:
        plein = _remplissage_plein(doc)
        if plein is not None:
            ogs.SetSurfaceForegroundPatternId(plein)
            ogs.SetSurfaceForegroundPatternColor(c)
            ogs.SetCutForegroundPatternId(plein)
            ogs.SetCutForegroundPatternColor(c)
    return ogs


def vues_possibles(doc):
    """Vues et gabarits ou l'on peut mettre des filtres : (libelle, vue)."""
    res = []
    types_ok = (DB.ViewType.FloorPlan, DB.ViewType.CeilingPlan, DB.ViewType.Section, DB.ViewType.Elevation,
                DB.ViewType.ThreeD, DB.ViewType.EngineeringPlan, DB.ViewType.Detail)
    for v in DB.FilteredElementCollector(doc).OfClass(DB.View):
        try:
            if v.ViewType not in types_ok or not v.AreGraphicsOverridesAllowed():
                continue
            if v.IsTemplate:
                res.append((u"[Gabarit] " + v.Name, v))
            else:
                res.append((u"%s : %s" % (_libelle_type(v.ViewType), v.Name), v))
        except Exception:
            pass
    res.sort(key=lambda x: (0 if x[0].startswith(u"[Gabarit]") else 1, x[0].lower()))
    return res


def _libelle_type(vt):
    return {DB.ViewType.FloorPlan: u"Plan", DB.ViewType.CeilingPlan: u"Plafond", DB.ViewType.Section: u"Coupe",
            DB.ViewType.Elevation: u"Élévation", DB.ViewType.ThreeD: u"3D", DB.ViewType.EngineeringPlan: u"Plan struct.",
            DB.ViewType.Detail: u"Détail"}.get(vt, u"Vue")


def appliquer_couleurs(doc, systemes_choisis, vues, remplir, log, prioritaire=True):
    """Cree les filtres et les applique aux vues (ou a leur gabarit)."""
    t = DB.Transaction(doc, u"Allan BIM - Couleurs réseaux")
    t.Start()
    nv = 0
    gabarits_utilises = set()
    try:
        fids = [(s, filtre_systeme(doc, s)) for s in systemes_choisis]
        cibles = []
        for v in vues:
            tid = v.ViewTemplateId
            if not v.IsTemplate and tid is not None and tid != DB.ElementId.InvalidElementId:
                gab = doc.GetElement(tid)
                if _id(gab) not in gabarits_utilises:
                    gabarits_utilises.add(_id(gab))
                    cibles.append(gab)
                    log.append(u"« %s » est piloté par le gabarit « %s » : couleurs mises dans le gabarit." % (v.Name, gab.Name))
            else:
                cibles.append(v)
        mes_ids = set(_id(f) for s, f in fids)
        for v in cibles:
            # les filtres deja presents passeraient devant : on les met de cote
            # (avec leurs reglages) puis on les remet apres ceux d'Allan BIM
            autres = []
            if prioritaire:
                for fid in list(v.GetOrderedFilters()):
                    if _id(fid) in mes_ids:
                        continue
                    autres.append((fid, v.GetFilterOverrides(fid), v.GetFilterVisibility(fid), v.GetIsFilterEnabled(fid)))
                    v.RemoveFilter(fid)
            for s, fid in fids:
                if not v.IsFilterApplied(fid):
                    v.AddFilter(fid)
                v.SetFilterOverrides(fid, reglages(doc, s.couleur, remplir))
                v.SetFilterVisibility(fid, True)
            for fid, ogs, vis, en in autres:
                v.AddFilter(fid)
                v.SetFilterOverrides(fid, ogs)
                v.SetFilterVisibility(fid, vis)
                try:
                    v.SetIsFilterEnabled(fid, en)
                except Exception:
                    pass
            nv += 1
        t.Commit()
        log.append(u"Couleurs : %d système(s) appliqué(s) sur %d vue(s)/gabarit(s)." % (len(fids), nv))
        return True
    except Exception as ex:
        if t.HasStarted() and not t.HasEnded():
            t.RollBack()
        log.append(u"Annulé : %s" % ex)
        return False


def retirer_couleurs(doc, vues, supprimer_filtres, log):
    t = DB.Transaction(doc, u"Allan BIM - Retirer couleurs réseaux")
    t.Start()
    try:
        ab = [f for f in DB.FilteredElementCollector(doc).OfClass(DB.ParameterFilterElement) if f.Name.startswith(PREFIXE)]
        n = 0
        for v in vues:
            cible = v
            if not v.IsTemplate and v.ViewTemplateId != DB.ElementId.InvalidElementId:
                cible = doc.GetElement(v.ViewTemplateId)
            for f in ab:
                if cible.IsFilterApplied(f.Id):
                    cible.RemoveFilter(f.Id)
                    n += 1
        if supprimer_filtres:
            for f in ab:
                doc.Delete(f.Id)
        t.Commit()
        log.append(u"%d filtre(s) retiré(s) des vues%s." % (n, u", filtres supprimés du projet" if supprimer_filtres else u""))
        return True
    except Exception as ex:
        if t.HasStarted() and not t.HasEnded():
            t.RollBack()
        log.append(u"Annulé : %s" % ex)
        return False
