# -*- coding: utf-8 -*-
"""Allan BIM - Atelier familles (moteur).

Fonctions utilisees par le bouton "Atelier familles" :
  generer(spec)              -> cree une famille d'equipement CVC parametree
                                (plans de reference, cotes EQ, cadenas,
                                viroles + connecteurs de gaine)
  cadrer_extrusion(fd, ext)  -> plans de reference sur les 6 faces d'une
                                extrusion + cotes liees a des parametres
  ajouter_virole(fd, ...)    -> virole rectangulaire ou ronde sur une face,
                                avec son connecteur lie aux cotes
  ajouter_parametres(fd, ..) -> parametres CVC courants (Local traite, Debit...)
  test_flexion(fd)           -> fait varier chaque cote et dit ce qui casse

Toutes les cotes sont en mm dans les "spec" (dictionnaires simples).
Axes de la famille : X = largeur, Y = longueur (Avant = -Y), Z = hauteur.
"""

import os
import traceback
import clr
from Autodesk.Revit import DB
from Autodesk.Revit.DB.Mechanical import DuctSystemType

MM = 1.0 / 304.8
X = DB.XYZ.BasisX
Y = DB.XYZ.BasisY
Z = DB.XYZ.BasisZ
TOL = 1e-4

FACES = [u"Avant", u"Arrière", u"Gauche", u"Droite", u"Dessus"]
FACE_KEY = {u"Avant": "Y-", u"Arrière": "Y+", u"Gauche": "X-", u"Droite": "X+", u"Dessus": "Z+"}
FORMES = [u"Rectangulaire", u"Ronde"]
CLASSES = [u"Soufflage", u"Reprise", u"Extraction", u"Air neuf / autre"]
CLASS_TYPE = {u"Soufflage": DuctSystemType.SupplyAir, u"Reprise": DuctSystemType.ReturnAir,
              u"Extraction": DuctSystemType.ExhaustAir, u"Air neuf / autre": DuctSystemType.OtherAir}
SENS = [u"Entrée", u"Sortie", u"Bidirectionnel"]
SENS_TYPE = {u"Entrée": DB.FlowDirectionType.In, u"Sortie": DB.FlowDirectionType.Out,
             u"Bidirectionnel": DB.FlowDirectionType.Bidirectional}


# ---------------------------------------------------------------- modeles
def virole(face, forme=u"Rectangulaire", larg=400, haut=300, saillie=50, classe=u"Soufflage",
           sens=u"Bidirectionnel", decalage=0):
    return {"face": face, "forme": forme, "larg": larg, "haut": haut, "saillie": saillie,
            "classe": classe, "sens": sens, "decalage": decalage}


MODELES = [
    (u"Gainable / caisson simple", {
        "famille": u"Gainable", "type": u"Gainable", "largeur": 700, "longueur": 500, "hauteur": 400,
        "socle": False, "h_socle": 150, "debord": 100,
        "viroles": [virole(u"Gauche", larg=400, haut=300, classe=u"Reprise", sens=u"Bidirectionnel"),
                    virole(u"Droite", larg=400, haut=300, classe=u"Soufflage", sens=u"Bidirectionnel")]}),
    (u"Extracteur sur socle", {
        "famille": u"EXTRACTEUR", "type": u"CTA SIMPLE FLUX", "largeur": 1050, "longueur": 1530, "hauteur": 700,
        "socle": True, "h_socle": 150, "debord": 100,
        "viroles": [virole(u"Avant", larg=500, haut=500, saillie=100, classe=u"Extraction", sens=u"Entrée"),
                    virole(u"Arrière", larg=500, haut=500, saillie=100, classe=u"Extraction", sens=u"Sortie")]}),
    (u"CTA simple flux", {
        "famille": u"CTA simple flux", "type": u"1000 m3/h", "largeur": 1200, "longueur": 1000, "hauteur": 800,
        "socle": False, "h_socle": 150, "debord": 100,
        "viroles": [virole(u"Avant", larg=300, haut=200, classe=u"Reprise", sens=u"Entrée"),
                    virole(u"Arrière", larg=300, haut=200, classe=u"Soufflage", sens=u"Sortie")]}),
    (u"CTA double flux", {
        "famille": u"CTA double flux", "type": u"2000 m3/h", "largeur": 1400, "longueur": 2200, "hauteur": 1000,
        "socle": True, "h_socle": 150, "debord": 100,
        "viroles": [virole(u"Avant", larg=400, haut=400, classe=u"Air neuf / autre", sens=u"Entrée", decalage=-350),
                    virole(u"Avant", larg=400, haut=400, classe=u"Extraction", sens=u"Sortie", decalage=350),
                    virole(u"Arrière", larg=400, haut=400, classe=u"Soufflage", sens=u"Sortie", decalage=-350),
                    virole(u"Arrière", larg=400, haut=400, classe=u"Reprise", sens=u"Entrée", decalage=350)]}),
    (u"Ventilateur / caisson rond", {
        "famille": u"Caisson ventilation", "type": u"Standard", "largeur": 600, "longueur": 600, "hauteur": 600,
        "socle": False, "h_socle": 150, "debord": 100,
        "viroles": [virole(u"Gauche", forme=u"Ronde", larg=315, classe=u"Extraction", sens=u"Entrée"),
                    virole(u"Droite", forme=u"Ronde", larg=315, classe=u"Extraction", sens=u"Sortie")]}),
]


# ---------------------------------------------------------------- parametres CVC
# nom, specification, groupe, occurrence, unite pour la valeur, valeur par defaut
def _spec(n):
    return getattr(DB.SpecTypeId, n)


PARAMS_CVC = [
    (u"Local traité", "texte", "Mechanical", True, None, u""),
    (u"Débit d'air", "HvacAirflow", "MechanicalAirflow", False, "CubicMetersPerHour", u"1000"),
    (u"pdc", "HvacFriction", "MechanicalAirflow", True, "PascalsPerMeter", u"0"),
    (u"Pression disponible", "HvacPressure", "MechanicalAirflow", False, "Pascals", u"200"),
    (u"Perte de charge", "HvacPressure", "MechanicalAirflow", False, "Pascals", u"100"),
    (u"Puissance calorifique", "HvacPower", "Mechanical", False, "Watts", u"0"),
    (u"Puissance frigorifique", "HvacPower", "Mechanical", False, "Watts", u"0"),
    (u"Puissance électrique", "HvacPower", "Mechanical", False, "Watts", u"0"),
    (u"Niveau sonore (dBA)", "nombre", "Mechanical", False, None, u"0"),
    (u"Masse", "Mass", "Mechanical", False, "Kilograms", u"0"),
]
INFOS = [(u"Fabricant", DB.BuiltInParameter.ALL_MODEL_MANUFACTURER),
         (u"Modèle", DB.BuiltInParameter.ALL_MODEL_MODEL),
         (u"Description", DB.BuiltInParameter.ALL_MODEL_DESCRIPTION)]


# ---------------------------------------------------------------- transactions
class _FP(DB.IFailuresPreprocessor):
    msgs = []

    def PreprocessFailures(self, fa):
        grave = False
        for f in fa.GetFailureMessages():
            _FP.msgs.append(f.GetDescriptionText())
            if f.GetSeverity() == DB.FailureSeverity.Warning:
                fa.DeleteWarning(f)
            else:
                grave = True
        if grave:
            return DB.FailureProcessingResult.ProceedWithRollBack
        return DB.FailureProcessingResult.Continue


def run(d, nom, fn, log, garder=True):
    """Execute fn() dans une transaction de d. Renvoie (ok, messages Revit)."""
    t = DB.Transaction(d, nom)
    t.Start()
    o = t.GetFailureHandlingOptions()
    o.SetFailuresPreprocessor(_FP())
    o.SetClearAfterRollback(True)
    t.SetFailureHandlingOptions(o)
    _FP.msgs = []
    try:
        res = fn()
        if not garder:
            t.RollBack()
            return True, list(_FP.msgs), res
        st = t.Commit()
        ok = st == DB.TransactionStatus.Committed
        if not ok:
            log.append(u"%s : annulé par Revit (%s)" % (nom, u" / ".join(_FP.msgs)))
        return ok, list(_FP.msgs), res
    except Exception as ex:
        log.append(u"%s : erreur %s" % (nom, ex))
        log.append(traceback.format_exc()[-600:])
        if t.HasStarted() and not t.HasEnded():
            t.RollBack()
        return False, list(_FP.msgs), None


# ---------------------------------------------------------------- contexte famille
class Ctx(object):
    """Outils de construction dans un document famille."""

    def __init__(self, fd):
        self.fd = fd
        self.fm = fd.FamilyManager
        vs = [v for v in DB.FilteredElementCollector(fd).OfClass(DB.View) if not v.IsTemplate]
        plans = [v for v in vs if v.ViewType == DB.ViewType.FloorPlan]
        if not plans:
            raise Exception(u"Pas de vue en plan dans la famille")
        self.plan = plans[0]
        elevs = [v for v in vs if v.ViewType == DB.ViewType.Elevation]
        av = [v for v in elevs if v.ViewDirection.Y < -0.9] or [v for v in elevs if v.ViewDirection.Y > 0.9]
        self.avant = av[0]
        self.gauche = [v for v in elevs if abs(v.ViewDirection.X) > 0.9][0]
        lv = list(DB.FilteredElementCollector(fd).OfClass(DB.Level))
        self.lvl = lv[0] if lv else None
        self.cLR = self._centre(X)
        self.cFB = self._centre(Y)

    def _centre(self, n):
        best = None
        for r in DB.FilteredElementCollector(self.fd).OfClass(DB.ReferencePlane):
            if abs(abs(r.Normal.DotProduct(n)) - 1) < 1e-6 and abs(r.BubbleEnd.DotProduct(n)) < TOL:
                if best is None or r.Pinned:
                    best = r
        return best

    # -- parametres
    def p(self, nom):
        return self.fm.get_Parameter(nom)

    def param(self, nom, val_mm, inst=False, groupe=None):
        fp = self.p(nom)
        if fp is None:
            fp = self.fm.AddParameter(nom, groupe or DB.GroupTypeId.Geometry, DB.SpecTypeId.Length, inst)
        if val_mm is not None and fp.Formula is None:
            self.fm.Set(fp, val_mm * MM)
        return fp

    # -- plans de reference
    def plan_ref(self, axe, val, nom):
        """axe = 'X', 'Y' (crees en plan) ou 'Z' (cree en elevation)."""
        B = 5.0
        fc = self.fd.FamilyCreate
        if axe == "X":
            r = fc.NewReferencePlane(DB.XYZ(val, -B, 0), DB.XYZ(val, B, 0), Z, self.plan)
            n = X
        elif axe == "Y":
            r = fc.NewReferencePlane(DB.XYZ(-B, val, 0), DB.XYZ(B, val, 0), Z, self.plan)
            n = Y
        else:
            r = fc.NewReferencePlane(DB.XYZ(-B, 0, val), DB.XYZ(B, 0, val), Y, self.avant)
            n = Z
        try:
            r.Name = nom
        except Exception:
            r.Name = nom + u" " + str(r.Id.IntegerValue if hasattr(r.Id, "IntegerValue") else r.Id.Value)
        self.fd.Regenerate()
        if val * r.Normal.DotProduct(n) < 0:
            r.Flip()
        return r

    def trouver_plan(self, axe, val):
        n = {"X": X, "Y": Y, "Z": Z}[axe]
        for r in DB.FilteredElementCollector(self.fd).OfClass(DB.ReferencePlane):
            if abs(abs(r.Normal.DotProduct(n)) - 1) < 1e-6 and abs(r.BubbleEnd.DotProduct(n) - val) < TOL:
                return r
        return None

    @staticmethod
    def ref(o):
        if isinstance(o, DB.Reference):
            return o
        if isinstance(o, DB.Level):
            return o.GetPlaneReference()
        return o.GetReference()

    def vue(self, axe_normal):
        """Vue ou les plans de normale donnee apparaissent en ligne."""
        return self.plan if axe_normal in ("X", "Y") else self.avant

    # -- cotes
    def cote(self, axe, objs, label=None, eq=False, lock=False, off=4.0, vue=None):
        a = DB.ReferenceArray()
        for o in objs:
            a.Append(self.ref(o))
        B = 6.0
        if axe == "X":
            v = vue or self.plan
            if v.ViewType == DB.ViewType.FloorPlan:
                ln = DB.Line.CreateBound(DB.XYZ(-B, off, 0), DB.XYZ(B, off, 0))
            else:
                y = v.Origin.Y
                ln = DB.Line.CreateBound(DB.XYZ(-B, y, off), DB.XYZ(B, y, off))
        elif axe == "Y":
            v = vue or self.plan
            if v.ViewType == DB.ViewType.FloorPlan:
                ln = DB.Line.CreateBound(DB.XYZ(off, -B, 0), DB.XYZ(off, B, 0))
            else:
                x = v.Origin.X
                ln = DB.Line.CreateBound(DB.XYZ(x, -B, off), DB.XYZ(x, B, off))
        else:
            v = vue or self.avant
            if abs(v.ViewDirection.Y) > 0.9:
                y = v.Origin.Y
                ln = DB.Line.CreateBound(DB.XYZ(off, y, -B), DB.XYZ(off, y, B))
            else:
                x = v.Origin.X
                ln = DB.Line.CreateBound(DB.XYZ(x, off, -B), DB.XYZ(x, off, B))
        d = self.fd.FamilyCreate.NewDimension(v, ln, a)
        if eq:
            d.AreSegmentsEqual = True
        if label is not None:
            d.FamilyLabel = label if isinstance(label, DB.FamilyParameter) else self.p(label)
        if lock:
            d.IsLocked = True
        return d

    # -- geometrie
    def faces(self, el):
        o = DB.Options()
        o.ComputeReferences = True
        o.IncludeNonVisibleObjects = True
        res = []
        for g in el.get_Geometry(o):
            if isinstance(g, DB.Solid):
                for f in g.Faces:
                    if isinstance(f, DB.PlanarFace):
                        res.append(f)
        return res

    def face(self, el, n, val):
        """Face plane de normale n dont la coordonnee (sur l'axe X, Y ou Z de n) vaut val."""
        axe = X if abs(n.X) > 0.5 else (Y if abs(n.Y) > 0.5 else Z)
        for f in self.faces(el):
            if f.FaceNormal.IsAlmostEqualTo(n) and abs(f.Origin.DotProduct(axe) - val) < TOL:
                return f
        raise Exception(u"face introuvable (normale %s, position %.0f mm)" % (n, val / MM))

    def aligner(self, vue, plan, f):
        a = self.fd.FamilyCreate.NewAlignment(vue, self.ref(plan), f.Reference)
        a.IsLocked = True
        return a

    def boite(self, x0, x1, y0, y1, z0, z1):
        p = [DB.XYZ(x0, y0, 0), DB.XYZ(x1, y0, 0), DB.XYZ(x1, y1, 0), DB.XYZ(x0, y1, 0)]
        ca = DB.CurveArray()
        for i in range(4):
            ca.Append(DB.Line.CreateBound(p[i], p[(i + 1) % 4]))
        a = DB.CurveArrArray()
        a.Append(ca)
        sp = DB.SketchPlane.Create(self.fd, DB.Plane.CreateByNormalAndOrigin(Z, DB.XYZ.Zero))
        e = self.fd.FamilyCreate.NewExtrusion(True, a, sp, z1)
        e.get_Parameter(DB.BuiltInParameter.EXTRUSION_START_PARAM).Set(z0)
        self.fd.Regenerate()
        return e


def _bbox(el):
    b = el.get_BoundingBox(None)
    return b.Min, b.Max


# ---------------------------------------------------------------- cadre (plans d'une boite)
def plans_boite(C, el, creer=True):
    """Trouve (ou cree, aligne et cadenasse) les plans de reference des faces
    d'une boite + les plans milieux (EQ). Renvoie un dict :
    X-, X+, Y-, Y+, Zb (dessous : niveau ou plan), Zh (dessus), MX, MY, MZ."""
    mn, mx = _bbox(el)
    B = {}
    for axe, n, lo, hi in (("X", X, mn.X, mx.X), ("Y", Y, mn.Y, mx.Y)):
        for sgn, val in ((-1, lo), (1, hi)):
            k = axe + ("+" if sgn > 0 else "-")
            r = C.trouver_plan(axe, val)
            neuf = r is None
            if neuf:
                if not creer:
                    return None
                r = C.plan_ref(axe, val, u"Face %s" % {"X-": u"gauche", "X+": u"droite", "Y-": u"avant", "Y+": u"arrière"}[k])
            try:
                C.aligner(C.plan, r, C.face(el, n.Multiply(sgn), val))
            except Exception:
                if neuf:
                    raise
            B[k] = r
    # dessous
    if abs(mn.Z) < TOL and C.lvl is not None:
        B["Zb"] = C.lvl
        try:
            C.aligner(C.avant, C.lvl, C.face(el, Z.Negate(), 0.0))
        except Exception:
            pass
    else:
        r = C.trouver_plan("Z", mn.Z)
        neuf = r is None
        if neuf:
            r = C.plan_ref("Z", mn.Z, u"Face dessous")
            if C.lvl is not None:
                C.cote("Z", [C.lvl, r], lock=True, off=-5.0)
        try:
            C.aligner(C.avant, r, C.face(el, Z.Negate(), mn.Z))
        except Exception:
            if neuf:
                raise
        B["Zb"] = r
    r = C.trouver_plan("Z", mx.Z)
    neuf = r is None
    if neuf:
        r = C.plan_ref("Z", mx.Z, u"Face dessus")
    try:
        C.aligner(C.avant, r, C.face(el, Z, mx.Z))
    except Exception:
        if neuf:
            raise
    B["Zh"] = r
    # milieux
    for axe, kk, lo, hi in (("X", ("X-", "X+"), mn.X, mx.X), ("Y", ("Y-", "Y+"), mn.Y, mx.Y), ("Z", ("Zb", "Zh"), mn.Z, mx.Z)):
        mid = (lo + hi) / 2
        r = None
        if axe == "X" and C.cLR is not None and abs(mid) < TOL:
            r = C.cLR
        elif axe == "Y" and C.cFB is not None and abs(mid) < TOL:
            r = C.cFB
        else:
            r = C.trouver_plan(axe, mid)
        if r is None:
            r = C.plan_ref(axe, mid, u"Milieu %s" % {"X": u"largeur", "Y": u"longueur", "Z": u"hauteur"}[axe])
        if not _a_eq(C, B[kk[0]], r, B[kk[1]]):
            C.cote(axe, [B[kk[0]], r, B[kk[1]]], eq=True, off=-6.5 if axe != "Z" else 6.5)
        B["M" + axe] = r
    return B


def _rid(o):
    if isinstance(o, DB.Level):
        return o.Id
    return o.Id


def _a_eq(C, a, m, b):
    ids = set([_rid(a), _rid(m), _rid(b)])
    for d in DB.FilteredElementCollector(C.fd).OfClass(DB.Dimension):
        try:
            if d.NumberOfSegments == 2 and d.AreSegmentsEqual:
                refs = set([r.ElementId for r in d.References])
                if ids.issubset(refs):
                    return True
        except Exception:
            pass
    return False


# ---------------------------------------------------------------- virole
def _axes_face(face_key):
    """Pour une face : (axe normal, signe, axe a, axe b)."""
    return {"X+": ("X", 1, "Y", "Z"), "X-": ("X", -1, "Y", "Z"),
            "Y+": ("Y", 1, "X", "Z"), "Y-": ("Y", -1, "X", "Z"),
            "Z+": ("Z", 1, "X", "Y")}[face_key]


def _vec(axe):
    return {"X": X, "Y": Y, "Z": Z}[axe]


def _coord(o, axe):
    if isinstance(o, DB.Level):
        return o.Elevation
    return o.BubbleEnd.DotProduct(_vec(axe))


def creer_virole(C, B, face_key, spec, prefixe, inst=False, log=None):
    """Cree une virole (rect. ou ronde) centree (ou decalee) sur une face de
    la boite B, ses parametres, ses cotes, son extrusion et son connecteur."""
    fd, fm = C.fd, C.fm
    ax, sgn, aa, bb = _axes_face(face_key)
    nface = _vec(ax).Multiply(sgn)
    plan_face = B[face_key if face_key != "Z+" else "Zh"]
    f = _coord(plan_face, ax)
    ronde = spec["forme"] == u"Ronde"
    sail = float(spec["saillie"]) * MM
    larg = float(spec["larg"]) * MM
    haut = larg if ronde else float(spec["haut"]) * MM

    # parametres
    if ronde:
        p_d = C.param(prefixe + u" diamètre", spec["larg"], inst)
    else:
        p_l = C.param(prefixe + u" largeur", spec["larg"], inst)
        p_h = C.param(prefixe + u" hauteur", spec["haut"], inst)
    p_s = C.param(prefixe + u" saillie", spec["saillie"], inst)

    # centre (decalage le long de l'axe a)
    Ma = B["M" + aa]
    Mb = B["M" + bb]
    ca = _coord(Ma, aa)
    cb = _coord(Mb, bb)
    dec = float(spec.get("decalage") or 0) * MM
    if abs(dec) > TOL:
        p_dec = C.param(prefixe + u" décalage", abs(spec["decalage"]), inst)
        Ca = C.plan_ref(aa, ca + dec, prefixe + u" axe")
        C.cote(aa, [Ma, Ca], label=p_dec, off=-7.5 if aa != "Z" else 7.5, vue=C.vue(aa))
        ca = ca + dec
    else:
        Ca = Ma

    # plan exterieur + saillie
    Pext = C.plan_ref(ax, f + sgn * sail, prefixe + u" extérieur")
    C.cote(ax, [plan_face, Pext], label=p_s, off=3.0 + 0.4 * len(prefixe), vue=C.vue(ax))

    # vue ou la face est vue de face (pour la virole ronde)
    vue_face = {"X": C.gauche, "Y": C.avant, "Z": C.plan}[ax]

    sp = DB.SketchPlane.Create(fd, plan_face.Id) if not isinstance(plan_face, DB.Level) else \
        DB.SketchPlane.Create(fd, DB.Plane.CreateByNormalAndOrigin(Z, DB.XYZ(0, 0, f)))

    def pt(a, b):
        v = {"X": 0.0, "Y": 0.0, "Z": 0.0}
        v[ax] = f
        v[aa] = a
        v[bb] = b
        return DB.XYZ(v["X"], v["Y"], v["Z"])

    ca_arr = DB.CurveArray()
    if ronde:
        c = pt(ca, cb)
        ua, ub = _vec(aa), _vec(bb)
        r = larg / 2
        ca_arr.Append(DB.Arc.Create(c, r, 0, 3.14159265358979, ua, ub))
        ca_arr.Append(DB.Arc.Create(c, r, 3.14159265358979, 6.28318530717959, ua, ub))
    else:
        p = [pt(ca - larg / 2, cb - haut / 2), pt(ca + larg / 2, cb - haut / 2),
             pt(ca + larg / 2, cb + haut / 2), pt(ca - larg / 2, cb + haut / 2)]
        for i in range(4):
            ca_arr.Append(DB.Line.CreateBound(p[i], p[(i + 1) % 4]))
    caa = DB.CurveArrArray()
    caa.Append(ca_arr)
    ext = fd.FamilyCreate.NewExtrusion(True, caa, sp, sail)
    fd.Regenerate()
    mn, mx = _bbox(ext)
    milieu = ((mn + mx) / 2).DotProduct(_vec(ax))
    if sgn * (milieu - f) < 0:
        ext.get_Parameter(DB.BuiltInParameter.EXTRUSION_END_PARAM).Set(-sail)
        fd.Regenerate()

    if ronde:
        arcs = [fd.GetElement(i) for i in ext.Sketch.GetAllElements()]
        arcs = [a for a in arcs if isinstance(a, DB.CurveElement) and isinstance(a.GeometryCurve, DB.Arc)]
        d = fd.FamilyCreate.NewDiameterDimension(vue_face, arcs[0].GeometryCurve.Reference,
                                                  pt(ca, cb) + _vec(aa).Multiply(larg))
        d.FamilyLabel = p_d
        for pl in (Ca, Mb):
            al = fd.FamilyCreate.NewAlignment(vue_face, C.ref(pl), arcs[0].CenterPointReference)
            al.IsLocked = True
    else:
        # plans des cotes de la virole
        A1 = C.plan_ref(aa, ca - larg / 2, prefixe + u" bord 1")
        A2 = C.plan_ref(aa, ca + larg / 2, prefixe + u" bord 2")
        B1 = C.plan_ref(bb, cb - haut / 2, prefixe + u" bord 3")
        B2 = C.plan_ref(bb, cb + haut / 2, prefixe + u" bord 4")
        k = 0.35 * (1 + len(prefixe) % 5)
        C.cote(aa, [A1, A2], label=p_l, off=5.0 + k if aa != "Z" else -5.0 - k, vue=C.vue(aa))
        C.cote(aa, [A1, Ca, A2], eq=True, off=4.8 + k if aa != "Z" else -4.8 - k, vue=C.vue(aa))
        C.cote(bb, [B1, B2], label=p_h, off=5.0 + k if bb != "Z" else 5.0 + k, vue=C.vue(bb))
        C.cote(bb, [B1, Mb, B2], eq=True, off=4.8 + k if bb != "Z" else 4.8 + k, vue=C.vue(bb))
        for pl, axe, s, val in ((A1, aa, -1, ca - larg / 2), (A2, aa, 1, ca + larg / 2),
                                (B1, bb, -1, cb - haut / 2), (B2, bb, 1, cb + haut / 2)):
            C.aligner(C.vue(axe), pl, C.face(ext, _vec(axe).Multiply(s), val))
    ext_face = C.face(ext, nface, f + sgn * sail)
    C.aligner(C.vue(ax), Pext, ext_face)

    # connecteur
    prof = DB.ConnectorProfileType.Round if ronde else DB.ConnectorProfileType.Rectangular
    con = DB.ConnectorElement.CreateDuctConnector(fd, CLASS_TYPE.get(spec["classe"], DuctSystemType.SupplyAir),
                                                  prof, ext_face.Reference)
    fd.Regenerate()
    if ronde:
        fm.AssociateElementParameterToFamilyParameter(con.get_Parameter(DB.BuiltInParameter.CONNECTOR_DIAMETER), p_d)
    else:
        # largeur du connecteur = cote le long de son axe X
        bx = con.CoordinateSystem.BasisX
        if abs(bx.DotProduct(_vec(aa))) > 0.9:
            pw, ph = p_l, p_h
        else:
            pw, ph = p_h, p_l
        fm.AssociateElementParameterToFamilyParameter(con.get_Parameter(DB.BuiltInParameter.CONNECTOR_WIDTH), pw)
        fm.AssociateElementParameterToFamilyParameter(con.get_Parameter(DB.BuiltInParameter.CONNECTOR_HEIGHT), ph)
    con.get_Parameter(DB.BuiltInParameter.RBS_DUCT_FLOW_DIRECTION_PARAM).Set(
        int(SENS_TYPE.get(spec["sens"], DB.FlowDirectionType.Bidirectional)))
    return ext, con


def prochain_prefixe(fm):
    noms = set(p.Definition.Name for p in fm.Parameters)
    i = 1
    while (u"V%d saillie" % i) in noms:
        i += 1
    return u"V%d" % i


# ---------------------------------------------------------------- generateur
def gabarit(app):
    d = app.FamilyTemplatePath
    for nom in os.listdir(d):
        n = nom.lower()
        if n.endswith(".rft") and (u"mécanique" in n or "mecanique" in n or "mechanical" in n) \
                and "mur" not in n and "plafond" not in n and "wall" not in n and "ceiling" not in n:
            return os.path.join(d, nom)
    raise Exception(u"Gabarit 'Equipement mécanique métrique.rft' introuvable dans " + d)


def generer(app, spec, dossier, log):
    """Cree la famille et l'enregistre. Renvoie le chemin du .rfa (ou None)."""
    fd = app.NewFamilyDocument(gabarit(app))
    chemin = None
    try:
        C = Ctx(fd)
        fm = C.fm
        inst = bool(spec.get("occurrence"))
        Lx, Ly, H = spec["largeur"] * MM, spec["longueur"] * MM, spec["hauteur"] * MM
        socle = bool(spec.get("socle"))
        hs, deb = spec.get("h_socle", 150) * MM, spec.get("debord", 100) * MM
        st = {}

        def etape1():
            if fm.Types.Size == 0:
                fm.NewType(spec["type"])
            else:
                fm.RenameCurrentType(spec["type"])
            C.param(u"Largeur", spec["largeur"], inst)
            C.param(u"Longueur", spec["longueur"], inst)
            C.param(u"Hauteur", spec["hauteur"], inst)
            if socle:
                C.param(u"Hauteur socle", spec["h_socle"], False)
                C.param(u"Débord socle", spec["debord"], False)
                C.param(u"Largeur socle", spec["largeur"] + 2 * spec["debord"], inst)
                C.param(u"Longueur socle", spec["longueur"] + 2 * spec["debord"], inst)
            R = {}
            R["X-"] = C.plan_ref("X", -Lx / 2, u"Face gauche")
            R["X+"] = C.plan_ref("X", Lx / 2, u"Face droite")
            R["Y-"] = C.plan_ref("Y", -Ly / 2, u"Face avant")
            R["Y+"] = C.plan_ref("Y", Ly / 2, u"Face arrière")
            z0 = hs if socle else 0.0
            R["Zh"] = C.plan_ref("Z", z0 + H, u"Face dessus")
            R["MZ"] = C.plan_ref("Z", z0 + H / 2, u"Milieu hauteur")
            C.cote("X", [R["X-"], R["X+"]], label=u"Largeur", off=3.2)
            C.cote("X", [R["X-"], C.cLR, R["X+"]], eq=True, off=3.0)
            C.cote("Y", [R["Y-"], R["Y+"]], label=u"Longueur", off=-3.2)
            C.cote("Y", [R["Y-"], C.cFB, R["Y+"]], eq=True, off=-3.0)
            if socle:
                R["Zb"] = C.plan_ref("Z", hs, u"Dessus socle")
                C.cote("Z", [C.lvl, R["Zb"]], label=u"Hauteur socle", off=-3.6)
                R["SX-"] = C.plan_ref("X", -Lx / 2 - deb, u"Socle gauche")
                R["SX+"] = C.plan_ref("X", Lx / 2 + deb, u"Socle droite")
                R["SY-"] = C.plan_ref("Y", -Ly / 2 - deb, u"Socle avant")
                R["SY+"] = C.plan_ref("Y", Ly / 2 + deb, u"Socle arrière")
                C.cote("X", [R["SX-"], R["SX+"]], label=u"Largeur socle", off=3.8)
                C.cote("X", [R["SX-"], C.cLR, R["SX+"]], eq=True, off=3.6)
                C.cote("Y", [R["SY-"], R["SY+"]], label=u"Longueur socle", off=-3.8)
                C.cote("Y", [R["SY-"], C.cFB, R["SY+"]], eq=True, off=-3.6)
            else:
                R["Zb"] = C.lvl
            C.cote("Z", [R["Zb"], R["Zh"]], label=u"Hauteur", off=-3.2)
            C.cote("Z", [R["Zb"], R["MZ"], R["Zh"]], eq=True, off=-3.0)
            st["R"] = R

        ok = run(fd, u"Plans et cotes", etape1, log)[0]
        if ok and socle:
            def formules():
                fm.SetFormula(C.p(u"Largeur socle"), u"Largeur + 2 * Débord socle")
                fm.SetFormula(C.p(u"Longueur socle"), u"Longueur + 2 * Débord socle")
            ok = run(fd, u"Formules socle", formules, log)[0]

        if ok:
            def etape2():
                R = st["R"]
                z0 = hs if socle else 0.0
                box = C.boite(-Lx / 2, Lx / 2, -Ly / 2, Ly / 2, z0, z0 + H)
                for k, n, v in (("X-", X.Negate(), -Lx / 2), ("X+", X, Lx / 2), ("Y-", Y.Negate(), -Ly / 2), ("Y+", Y, Ly / 2)):
                    C.aligner(C.plan, R[k], C.face(box, n, v))
                C.aligner(C.avant, R["Zh"], C.face(box, Z, z0 + H))
                C.aligner(C.avant, R["Zb"], C.face(box, Z.Negate(), z0))
                if socle:
                    sb = C.boite(-Lx / 2 - deb, Lx / 2 + deb, -Ly / 2 - deb, Ly / 2 + deb, 0, hs)
                    for k, n, v in (("SX-", X.Negate(), -Lx / 2 - deb), ("SX+", X, Lx / 2 + deb),
                                    ("SY-", Y.Negate(), -Ly / 2 - deb), ("SY+", Y, Ly / 2 + deb)):
                        C.aligner(C.plan, R[k], C.face(sb, n, v))
                    C.aligner(C.avant, R["Zb"], C.face(sb, Z, hs))
                    C.aligner(C.avant, C.lvl, C.face(sb, Z.Negate(), 0.0))
                st["box"] = box
            ok = run(fd, u"Caisson", etape2, log)[0]

        if ok:
            R = st["R"]
            B = {"X-": R["X-"], "X+": R["X+"], "Y-": R["Y-"], "Y+": R["Y+"], "Zb": R["Zb"], "Zh": R["Zh"],
                 "MX": C.cLR, "MY": C.cFB, "MZ": R["MZ"]}
            for i, v in enumerate(spec.get("viroles", [])):
                pre = u"V%d" % (i + 1)
                fk = FACE_KEY[v["face"]]
                ok2 = run(fd, u"Virole %s (%s)" % (pre, v["face"]),
                          lambda: creer_virole(C, B, fk, v, pre, inst, log), log)[0]
                if not ok2:
                    log.append(u"La virole %s n'a pas pu être créée." % pre)

        if ok:
            def infos():
                for nom, val in (spec.get("infos") or {}).items():
                    for n2, bip in INFOS:
                        if n2 == nom and val:
                            fp = fm.get_Parameter(bip)
                            if fp is not None:
                                fm.Set(fp, val)
                ajouter_parametres_dans(fd, spec.get("params") or [], log)
            run(fd, u"Paramètres", infos, log)

        if ok:
            if not os.path.isdir(dossier):
                os.makedirs(dossier)
            chemin = os.path.join(dossier, spec["famille"] + u".rfa")
            so = DB.SaveAsOptions()
            so.OverwriteExistingFile = True
            fd.SaveAs(chemin, so)
            log.append(u"Famille enregistrée : " + chemin)
    finally:
        fd.Close(False)
    return chemin


class _Charge(DB.IFamilyLoadOptions):
    def OnFamilyFound(self, familyInUse, overwriteParameterValues):
        overwriteParameterValues.Value = True
        return True

    def OnSharedFamilyFound(self, sharedFamily, familyInUse, source, overwriteParameterValues):
        overwriteParameterValues.Value = True
        return True


def charger(doc, chemin, log):
    fam = clr.Reference[DB.Family]()
    res = {}

    def go():
        doc.LoadFamily(chemin, _Charge(), fam)
        f = fam.Value
        if f is None:
            nom = os.path.splitext(os.path.basename(chemin))[0]
            for x in DB.FilteredElementCollector(doc).OfClass(DB.Family):
                if x.Name == nom:
                    f = x
        res["f"] = f
        if f is not None:
            for sid in f.GetFamilySymbolIds():
                s = doc.GetElement(sid)
                if not s.IsActive:
                    s.Activate()
                res["s"] = s
                break
    run(doc, u"Charger " + os.path.basename(chemin), go, log)
    return res.get("s")


# ---------------------------------------------------------------- cadrer une extrusion
def cadrer_extrusion(fd, el, noms, centrer, inst, log):
    C = Ctx(fd)
    mn, mx = _bbox(el)
    if isinstance(el, DB.Extrusion):
        n = el.Sketch.SketchPlane.GetPlane().Normal
        if abs(abs(n.Z) - 1) > 1e-6:
            log.append(u"L'extrusion doit être dessinée à plat (esquisse horizontale).")
            return False

    def go():
        if centrer:
            c = (mn + mx) / 2
            if abs(c.X) > TOL or abs(c.Y) > TOL:
                DB.ElementTransformUtils.MoveElement(fd, el.Id, DB.XYZ(-c.X, -c.Y, 0))
                fd.Regenerate()
        a, b = _bbox(el)
        B = plans_boite(C, el)
        fpL = C.param(noms[0], (b.X - a.X) / MM, inst)
        fpl = C.param(noms[1], (b.Y - a.Y) / MM, inst)
        fph = C.param(noms[2], (b.Z - a.Z) / MM, inst)
        C.cote("X", [B["X-"], B["X+"]], label=fpL, off=3.4)
        C.cote("Y", [B["Y-"], B["Y+"]], label=fpl, off=-3.4)
        C.cote("Z", [B["Zb"], B["Zh"]], label=fph, off=-3.4)
    ok = run(fd, u"Cadrer l'extrusion", go, log)[0]
    if ok:
        log.append(u"Extrusion cadrée : %s / %s / %s." % tuple(noms))
    return ok


def ajouter_virole(fd, el, face_normal, spec, inst, log):
    C = Ctx(fd)
    n = face_normal
    if abs(n.X - 1) < 1e-3:
        fk = "X+"
    elif abs(n.X + 1) < 1e-3:
        fk = "X-"
    elif abs(n.Y - 1) < 1e-3:
        fk = "Y+"
    elif abs(n.Y + 1) < 1e-3:
        fk = "Y-"
    elif abs(n.Z - 1) < 1e-3:
        fk = "Z+"
    else:
        log.append(u"Choisis une face verticale (avant, arrière, gauche, droite) ou le dessus.")
        return False
    pre = prochain_prefixe(C.fm)

    def go():
        B = plans_boite(C, el)
        creer_virole(C, B, fk, spec, pre, inst, log)
    ok = run(fd, u"Ajouter la virole " + pre, go, log)[0]
    if ok:
        log.append(u"Virole %s ajoutée (face %s)." % (pre, fk))
    return ok


# ---------------------------------------------------------------- parametres CVC
def ajouter_parametres_dans(fd, choix, log):
    """choix = liste de (nom, valeur texte). A appeler dans une transaction."""
    fm = fd.FamilyManager
    if fm.Types.Size == 0:
        fm.NewType(u"Type 1")
    for nom, val in choix:
        defn = None
        for d in PARAMS_CVC:
            if d[0] == nom:
                defn = d
        if defn is None:
            continue
        nom, spec, grp, inst, unite, _ = defn
        fp = fm.get_Parameter(nom)
        if fp is None:
            if spec == "texte":
                sid = DB.SpecTypeId.String.Text
            elif spec == "nombre":
                sid = DB.SpecTypeId.Number
            else:
                sid = _spec(spec)
            fp = fm.AddParameter(nom, getattr(DB.GroupTypeId, grp, DB.GroupTypeId.Mechanical), sid, inst)
        try:
            if spec == "texte":
                fm.Set(fp, val or u"")
            elif val not in (None, u""):
                x = float(unicode(val).replace(u",", u"."))
                if unite:
                    x = DB.UnitUtils.ConvertToInternalUnits(x, getattr(DB.UnitTypeId, unite))
                fm.Set(fp, x)
        except Exception as ex:
            log.append(u"%s : valeur non appliquée (%s)" % (nom, ex))
    return True


def ajouter_parametres(fd, choix, infos, log):
    def go():
        ajouter_parametres_dans(fd, choix, log)
        fm = fd.FamilyManager
        for nom, val in infos:
            for n2, bip in INFOS:
                if n2 == nom and val:
                    fp = fm.get_Parameter(bip)
                    if fp is not None:
                        fm.Set(fp, val)
    ok = run(fd, u"Paramètres CVC", go, log)[0]
    if ok:
        log.append(u"%d paramètre(s) ajouté(s) / mis à jour." % (len(choix) + len([i for i in infos if i[1]])))
    return ok


# ---------------------------------------------------------------- test de flexion
def _signature(fd):
    s = []
    for e in DB.FilteredElementCollector(fd).OfClass(DB.GenericForm):
        try:
            b = e.get_BoundingBox(None)
            s.append(tuple(round(v, 5) for v in (b.Min.X, b.Min.Y, b.Min.Z, b.Max.X, b.Max.Y, b.Max.Z)))
        except Exception:
            pass
    for c in DB.FilteredElementCollector(fd).OfClass(DB.ConnectorElement):
        try:
            o = c.Origin
            s.append((round(o.X, 5), round(o.Y, 5), round(o.Z, 5)))
        except Exception:
            pass
    return s


def test_flexion(fd):
    """Renvoie une liste de (nom, ok, message)."""
    fm = fd.FamilyManager
    res = []
    if fm.Types.Size == 0:
        return [(u"(famille)", False, u"La famille n'a aucun type.")]
    ref = _signature(fd)
    params = []
    for p in fm.Parameters:
        try:
            if p.Definition.GetDataType() != DB.SpecTypeId.Length:
                continue
        except Exception:
            continue
        if p.Formula or p.IsReporting or p.IsDeterminedByFormula:
            continue
        if p.Definition.Name.startswith(u"Elévation") or p.Definition.Name.startswith(u"Élévation") \
                or p.Definition.Name.startswith(u"Default Elevation"):
            continue
        params.append(p)
    if not params:
        return [(u"(famille)", False, u"Aucune cote paramétrée à tester.")]
    for p in params:
        v0 = fm.CurrentType.AsDouble(p) or 0.0
        msgs_tot = []
        bouge = False
        ok_all = True
        for k in (1.25, 0.8):
            log = []

            def go():
                fm.Set(p, max(v0 * k, 10 * MM))
                fd.Regenerate()
                return _signature(fd)
            # on valide vraiment (pour que Revit signale les erreurs) puis on annule tout
            tg = DB.TransactionGroup(fd, u"Test de flexion")
            tg.Start()
            try:
                ok, msgs, sig = run(fd, u"Flexion " + p.Definition.Name, go, log)
            finally:
                tg.RollBack()
            if not ok:
                ok_all = False
                msgs_tot.extend(log)
            if msgs:
                ok_all = False
                msgs_tot.extend(msgs)
            if sig is not None and sig != ref:
                bouge = True
        if ok_all and not bouge:
            res.append((p.Definition.Name, False, u"ne fait rien bouger (cote pas reliée à la géométrie)"))
        elif ok_all:
            res.append((p.Definition.Name, True, u"OK (+25 % / -20 %)"))
        else:
            res.append((p.Definition.Name, False, u" / ".join(sorted(set(msgs_tot)))[:300]))
    return res
