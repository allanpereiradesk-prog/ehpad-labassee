# -*- coding: utf-8 -*-
"""Allan BIM - pose automatique des reservations sur une canalisation / gaine.

place_for_curve(doc, mep_curve) cherche tous les murs et dalles traverses
par la canalisation ou la gaine et pose la bonne famille RES_* a chaque
traversee, en remplissant les parametres. A appeler dans une transaction.
"""

import os
import clr
from Autodesk.Revit import DB

MM = 1.0 / 304.8
TOL_DOUBLON = 30 * MM

# Reglages par defaut (modifiables avec le bouton Reglages)
DEFAUTS = {
    "jeu_gaine_mm": 50.0,      # jeu de chaque cote pour les gaines
    "jeu_canal_mm": 50.0,      # jeu de chaque cote pour les canalisations
    "pas_rect_mm": 50.0,       # arrondi des reservations rectangulaires
    "pas_circ_mm": 10.0,       # arrondi des reservations circulaires
}

FORMES = {"Automatique": "auto", "Circulaire": "circ", "Rectangulaire": "rect"}


def get_reglages():
    """Lit les reglages Allan BIM (pyRevit config, par utilisateur)."""
    out = dict(DEFAUTS)
    try:
        from pyrevit import script
        cfg = script.get_config("AllanBIM_Reservations")
        for k in DEFAUTS:
            v = getattr(cfg, k, None)
            if v is not None:
                out[k] = float(v)
    except Exception:
        pass
    return out


def save_reglages(values):
    from pyrevit import script
    cfg = script.get_config("AllanBIM_Reservations")
    for k, v in values.items():
        setattr(cfg, k, v)
    script.save_config()


def apply_pas(syms, reg=None):
    """Ecrit le pas d'arrondi (parametre de type) sur les familles RES_."""
    reg = reg or get_reglages()
    for (orient, shape), sym in syms.items():
        p = sym.LookupParameter("RES_Pas_Arrondi")
        if p and not p.IsReadOnly:
            p.Set((reg["pas_rect_mm"] if shape == "rect" else reg["pas_circ_mm"]) * MM)


FAM = {
    ("H", "circ"): "RES_Horizontale_Circulaire",
    ("H", "rect"): "RES_Horizontale_Rectangulaire",
    ("V", "circ"): "RES_Verticale_Circulaire",
    ("V", "rect"): "RES_Verticale_Rectangulaire",
}


# ------------------------------------------------------------------ outils
def _p(el, bip):
    try:
        return el.get_Parameter(bip)
    except Exception:
        return None


def _dbl(el, bip, default=0.0):
    p = _p(el, bip)
    if p and p.HasValue:
        return p.AsDouble()
    return default


def _str(el, bip):
    p = _p(el, bip)
    if p and p.HasValue:
        return p.AsString() or p.AsValueString() or ""
    return ""


def _set(inst, name, value):
    p = inst.LookupParameter(name)
    if p is None or p.IsReadOnly:
        return
    try:
        p.Set(value)
    except Exception:
        pass


def _type_name(doc, el):
    try:
        t = el.Document.GetElement(el.GetTypeId())     # marche aussi pour un mur de maquette liee
        return _str(t, DB.BuiltInParameter.ALL_MODEL_TYPE_NAME) or t.Name
    except Exception:
        return ""


def _solids(el):
    opt = DB.Options()
    opt.ComputeReferences = False
    opt.IncludeNonVisibleObjects = False
    out = []
    geo = el.get_Geometry(opt)
    if geo is None:
        return out
    for g in geo:
        if isinstance(g, DB.Solid) and g.Volume > 1e-9:
            out.append(g)
        elif isinstance(g, DB.GeometryInstance):
            for gg in g.GetInstanceGeometry():
                if isinstance(gg, DB.Solid) and gg.Volume > 1e-9:
                    out.append(gg)
    return out


def ensure_families(doc, fam_dir):
    """Charge les familles RES_* manquantes depuis le dossier Familles."""
    _NUM["last"] = 0
    import allan_reservations as ar
    have = dict((f.Name, f) for f in DB.FilteredElementCollector(doc).OfClass(DB.Family))
    for name in FAM.values():
        if name not in have:
            path = os.path.join(fam_dir, name + ".rfa")
            if not os.path.exists(path):
                ar.build_all(doc, fam_dir, load=True)
                break
            ref = clr.Reference[DB.Family]()
            doc.LoadFamily(path, ar._LoadOpts(), ref)
    have = dict((f.Name, f) for f in DB.FilteredElementCollector(doc).OfClass(DB.Family))
    syms = {}
    for key, name in FAM.items():
        fam = have.get(name)
        if fam is None:
            continue
        sym = doc.GetElement(list(fam.GetFamilySymbolIds())[0])
        if not sym.IsActive:
            sym.Activate()
        syms[key] = sym
    doc.Regenerate()
    return syms


# --------------------------------------------------------- lecture reseau
def reseau_info(doc, c):
    """Forme, dimensions exterieures, isolant, nom de reseau et lot."""
    info = {"shape": "circ", "d": 0.0, "w": 0.0, "h": 0.0,
            "iso": 0.0, "reseau": "", "lot": "CVC", "wdir": None}
    info["iso"] = _dbl(c, DB.BuiltInParameter.RBS_REFERENCE_INSULATION_THICKNESS)

    if isinstance(c, DB.Plumbing.Pipe):
        info["d"] = _dbl(c, DB.BuiltInParameter.RBS_PIPE_OUTER_DIAMETER) or \
            _dbl(c, DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM)
        cls = _str(c, DB.BuiltInParameter.RBS_SYSTEM_CLASSIFICATION_PARAM).lower()
        plomb = ("domestique" in cls or "domestic" in cls or "sanitaire" in cls
                 or "sanitary" in cls or "eaux" in cls or "vent" == cls)
        info["lot"] = "PLB" if plomb else "CVC"
    else:
        shape = None
        try:
            for con in c.ConnectorManager.Connectors:
                shape = con.Shape
                if con.Shape == DB.ConnectorProfileType.Rectangular:
                    info["wdir"] = con.CoordinateSystem.BasisX
                break
        except Exception:
            pass
        if shape == DB.ConnectorProfileType.Rectangular:
            info["shape"] = "rect"
            info["w"] = _dbl(c, DB.BuiltInParameter.RBS_CURVE_WIDTH_PARAM)
            info["h"] = _dbl(c, DB.BuiltInParameter.RBS_CURVE_HEIGHT_PARAM)
        else:
            info["d"] = _dbl(c, DB.BuiltInParameter.RBS_CURVE_DIAMETER_PARAM)
            if shape == DB.ConnectorProfileType.Oval:
                info["d"] = max(_dbl(c, DB.BuiltInParameter.RBS_CURVE_WIDTH_PARAM),
                                _dbl(c, DB.BuiltInParameter.RBS_CURVE_HEIGHT_PARAM))
        info["lot"] = "CVC"

    info["reseau"] = (_str(c, DB.BuiltInParameter.RBS_SYSTEM_NAME_PARAM)
                      or _str(c, DB.BuiltInParameter.RBS_SYSTEM_CLASSIFICATION_PARAM))
    try:
        st = doc.GetElement(c.MEPSystem.GetTypeId()) if c.MEPSystem else None
        if st is not None:
            info["reseau"] = _str(st, DB.BuiltInParameter.RBS_SYSTEM_ABBREVIATION_PARAM) \
                or _str(st, DB.BuiltInParameter.ALL_MODEL_TYPE_NAME) or info["reseau"]
    except Exception:
        pass
    return info


# --------------------------------------------------------- traversees
def _sources(doc):
    """Le projet + chaque maquette liee chargee (archi, structure...) :
    [(document, transformation lien -> projet)]."""
    out = [(doc, None)]
    for li in DB.FilteredElementCollector(doc).OfClass(DB.RevitLinkInstance):
        try:
            ld = li.GetLinkDocument()
            if ld is not None:
                out.append((ld, li.GetTotalTransform()))
        except Exception:
            pass
    return out


def traversees(doc, c):
    """Liste (element, point_entree, point_sortie) des murs/dalles traverses,
    dans le projet ET dans les maquettes liees. Les points sont toujours
    donnes dans les coordonnees du projet."""
    line0 = c.Location.Curve
    bb = c.get_BoundingBox(None)
    marge = 1.0
    res = []
    for sdoc, T in _sources(doc):
        if T is None:
            line = line0
            outline = DB.Outline(bb.Min - DB.XYZ(marge, marge, marge), bb.Max + DB.XYZ(marge, marge, marge))
        else:
            inv = T.Inverse
            line = line0.CreateTransformed(inv)
            pts = [inv.OfPoint(DB.XYZ(x, y, z)) for x in (bb.Min.X, bb.Max.X)
                   for y in (bb.Min.Y, bb.Max.Y) for z in (bb.Min.Z, bb.Max.Z)]
            outline = DB.Outline(
                DB.XYZ(min(p.X for p in pts) - marge, min(p.Y for p in pts) - marge, min(p.Z for p in pts) - marge),
                DB.XYZ(max(p.X for p in pts) + marge, max(p.Y for p in pts) + marge, max(p.Z for p in pts) + marge))
        bbf = DB.BoundingBoxIntersectsFilter(outline)
        for bic in (DB.BuiltInCategory.OST_Walls, DB.BuiltInCategory.OST_Floors):
            try:
                col = list(DB.FilteredElementCollector(sdoc).OfCategory(bic)
                           .WhereElementIsNotElementType().WherePasses(bbf))
            except Exception:
                continue
            for el in col:
                for s in _solids(el):
                    try:
                        r = s.IntersectWithCurve(line, DB.SolidCurveIntersectionOptions())
                    except Exception:
                        continue
                    for i in range(r.SegmentCount):
                        seg = r.GetCurveSegment(i)
                        if seg.Length < 5 * MM:
                            continue
                        a, b = _pleine_epaisseur(s, line, seg)
                        if T is not None:
                            a, b = T.OfPoint(a), T.OfPoint(b)
                        res.append((el, a, b))
    return res


def _pleine_epaisseur(solid, line, seg):
    """Le reseau peut s'arreter DANS la paroi (bout, coude, raccord noye) :
    le morceau de reseau a l'interieur est alors plus court que la paroi.
    On prolonge donc l'axe du reseau des deux cotes pour retrouver les deux
    vraies faces de la paroi (epaisseur complete, vrai dessus de dalle)."""
    a, b = seg.GetEndPoint(0), seg.GetEndPoint(1)
    try:
        d = (line.GetEndPoint(1) - line.GetEndPoint(0)).Normalize()
        L = 3000 * MM
        longue = DB.Line.CreateBound(line.GetEndPoint(0) - d * L, line.GetEndPoint(1) + d * L)
        r = solid.IntersectWithCurve(longue, DB.SolidCurveIntersectionOptions())
        o = longue.GetEndPoint(0)
        ta, tb = sorted(((a - o).DotProduct(d), (b - o).DotProduct(d)))
        for i in range(r.SegmentCount):
            sg = r.GetCurveSegment(i)
            p, q = sg.GetEndPoint(0), sg.GetEndPoint(1)
            tp, tq = sorted(((p - o).DotProduct(d), (q - o).DotProduct(d)))
            if tp <= ta + MM and tq >= tb - MM:          # ce morceau contient la traversee
                return (p, q) if (p - o).DotProduct(d) <= (q - o).DotProduct(d) else (q, p)
    except Exception:
        pass
    return a, b


def _existing_near(doc, pt):
    for i in DB.FilteredElementCollector(doc).OfClass(DB.FamilyInstance):
        try:
            if not i.Symbol.Family.Name.startswith("RES_"):
                continue
            lp = i.Location.Point
            if lp.DistanceTo(pt) < TOL_DOUBLON:
                return True
        except Exception:
            pass
    return False


def _level_below(doc, z):
    lv = sorted(DB.FilteredElementCollector(doc).OfClass(DB.Level),
                key=lambda l: l.ProjectElevation)
    best = lv[0]
    for l in lv:
        if l.ProjectElevation <= z + 1 * MM:
            best = l
    return best


_NUM = {"last": 0}


def _next_numero(doc):
    """Numero court unique dans tout le projet (1, 2, 3...).
    Garde en memoire le dernier numero donne pendant le lancement du bouton,
    pour ne jamais donner deux fois le meme numero."""
    n = _NUM["last"]
    for i in DB.FilteredElementCollector(doc).OfClass(DB.FamilyInstance):
        p = i.LookupParameter("RES_Numero")
        if p and p.AsString():
            try:
                n = max(n, int(p.AsString()))
            except Exception:
                pass
    _NUM["last"] = n + 1
    return n + 1


def renumeroter(doc):
    """Renumerote toutes les reservations 1, 2, 3... dans l'ordre :
    niveau (du bas vers le haut), puis de gauche a droite, puis de bas en haut
    sur le plan. Retourne le nombre de reservations."""
    res = all_reservations(doc)

    def cle(i):
        pt = i.Location.Point
        lvl = _level_below(doc, pt.Z + 1 * MM)
        return (round(lvl.ProjectElevation, 3), round(pt.X, 2), round(pt.Y, 2))
    res.sort(key=cle)
    for k, i in enumerate(res):
        _set(i, "RES_Numero", str(k + 1))
    _NUM["last"] = len(res)
    return len(res)


def _next_code(doc, level_name):
    pref = "R-%s-" % level_name
    n = 0
    for i in DB.FilteredElementCollector(doc).OfClass(DB.FamilyInstance):
        p = i.LookupParameter("RES_Code")
        if p and p.AsString() and p.AsString().startswith(pref):
            try:
                n = max(n, int(p.AsString()[len(pref):]))
            except Exception:
                pass
    return pref + "%03d" % (n + 1)


def _lien(el):
    try:
        if el.Document.IsLinked:
            return u", maquette liee %s" % el.Document.Title
    except Exception:
        pass
    return u""


# --------------------------------------------------------- pose
def place_for_curve(doc, c, syms, new_insts=None, forme="auto", reg=None):
    """Pose les reservations sur la canalisation / gaine c.
    Retourne (liste des codes crees, liste des messages)."""
    crees, msgs = [], []
    line = c.Location.Curve
    if not isinstance(line, DB.Line):
        return crees, ["Troncon non droit ignore."]
    d = line.Direction.Normalize()
    info = reseau_info(doc, c)
    Z = DB.XYZ.BasisZ
    reg = reg or get_reglages()
    jeu = (reg["jeu_canal_mm"] if isinstance(c, DB.Plumbing.Pipe) else reg["jeu_gaine_mm"]) * MM

    # forme de la reservation : auto = meme forme que le reseau
    shape = info["shape"] if forme == "auto" else forme
    if shape == "rect":
        if info["shape"] == "circ":
            res_w = res_h = info["d"]
        else:
            res_w, res_h = info["w"], info["h"]
    else:
        if info["shape"] == "rect":
            res_d = (info["w"] ** 2 + info["h"] ** 2) ** 0.5   # diagonale
        else:
            res_d = info["d"]

    for host, a, b in traversees(doc, c):
        is_floor = isinstance(host, DB.Floor) or \
            host.Category.Id == DB.Category.GetCategory(doc, DB.BuiltInCategory.OST_Floors).Id
        vertical = abs(d.Z) > 0.9
        horizontal = abs(d.Z) < 0.35
        if is_floor and vertical:
            orient = "V"
            target = a if a.Z > b.Z else b          # dessus de dalle
            ref_dir = info["wdir"] if info["wdir"] is not None else DB.XYZ.BasisX
            ref_dir = DB.XYZ(ref_dir.X, ref_dir.Y, 0)
            if ref_dir.GetLength() < 1e-6:
                ref_dir = DB.XYZ.BasisX
        elif (not is_floor) and horizontal:
            orient = "H"
            target = (a + b) * 0.5                  # centre du mur
            dh = DB.XYZ(d.X, d.Y, 0).Normalize()
            ref_dir = dh.CrossProduct(Z)
        else:
            msgs.append(u"%s id %s%s : traversee en biais ignoree" % (
                "Dalle" if is_floor else "Mur", host.Id, _lien(host)))
            continue

        if _existing_near(doc, target):
            msgs.append(u"Reservation deja presente a cet endroit (id %s%s)." % (host.Id, _lien(host)))
            continue

        sym = syms.get((orient, shape))
        if sym is None:
            msgs.append(u"Famille manquante pour %s %s" % (orient, shape))
            continue

        lvl = _level_below(doc, target.Z)
        inst = doc.Create.NewFamilyInstance(
            lvl.GetPlaneReference(), DB.XYZ(target.X, target.Y, lvl.ProjectElevation),
            ref_dir.Normalize(), sym)
        doc.Regenerate()
        cur = inst.Location.Point
        delta = target - cur
        if delta.GetLength() > 1e-6:
            DB.ElementTransformUtils.MoveElement(doc, inst.Id, delta)

        # ---- parametres
        ep = a.DistanceTo(b)
        _set(inst, "RES_Epaisseur_Paroi", ep)
        _set(inst, "RES_Epaisseur_Isolant", info["iso"])
        _set(inst, "RES_Jeu", jeu)
        if shape == "circ":
            _set(inst, "RES_Diametre_Reseau", res_d)
        else:
            _set(inst, "RES_Largeur_Reseau", res_w)
            _set(inst, "RES_Hauteur_Reseau", res_h)
        _set(inst, "RES_Reseau", info["reseau"])
        _set(inst, "RES_Lot", info["lot"])
        _set(inst, "RES_Paroi", _type_name(doc, host))
        _set(inst, "RES_Statut", "A valider")
        cf = _str(host.Document.GetElement(host.GetTypeId()), DB.BuiltInParameter.FIRE_RATING)
        if cf:
            _set(inst, "RES_Coupe_Feu", 1)
            _set(inst, "RES_Degre_CF", cf)
        code = _next_code(doc, lvl.Name)
        _set(inst, "RES_Code", code)
        _set(inst, "RES_Numero", str(_next_numero(doc)))
        try:
            inst.get_Parameter(DB.BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS).Set(
                u"Auto - %s id %s" % (c.Category.Name, c.Id))
        except Exception:
            pass
        doc.Regenerate()
        update_tag_values(doc, inst)
        crees.append(code)
        if new_insts is not None:
            new_insts.append(inst)
    if not crees and not msgs:
        msgs.append(u"Aucun mur ni dalle traverse par cet element.")
    return crees, msgs


# --------------------------------------------------------- valeurs etiquettes
def get_ngf_setting(doc):
    """(nom_niveau, ngf_en_pieds) si un NGF est saisi dans le projet, sinon None."""
    pi = doc.ProjectInformation
    pn = pi.LookupParameter("RES_NGF_Niveau_Ref")
    pv = pi.LookupParameter("RES_NGF_Reference")
    if pn is None or pv is None or not pn.AsString():
        return None
    return pn.AsString(), pv.AsDouble()


def set_ngf_setting(doc, level_name, ngf_ft):
    """Enregistre le NGF de reference dans les Informations sur le projet
    (cree les parametres si besoin). level_name=None -> desactive."""
    import allan_reservations as ar
    pi = doc.ProjectInformation
    if pi.LookupParameter("RES_NGF_Reference") is None:
        app = doc.Application
        fam_dir = os.path.join(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__))), "Familles")
        defs = ar.get_shared_definitions(
            app, os.path.join(fam_dir, "Parametres_Reservations.txt"))
        cats = app.Create.NewCategorySet()
        cats.Insert(DB.Category.GetCategory(doc, DB.BuiltInCategory.OST_ProjectInformation))
        bind = app.Create.NewInstanceBinding(cats)
        for n in ("RES_NGF_Reference", "RES_NGF_Niveau_Ref"):
            doc.ParameterBindings.Insert(defs[n], bind, DB.GroupTypeId.IdentityData)
        doc.Regenerate()
    pi.LookupParameter("RES_NGF_Niveau_Ref").Set(level_name or "")
    if level_name:
        pi.LookupParameter("RES_NGF_Reference").Set(ngf_ft)


def _ngf_offset(doc):
    """Valeur a ajouter a un Z interne pour obtenir l'altitude NGF.
    1) NGF saisi dans le reglage Allan BIM (prioritaire)
    2) sinon altitude du point de topographie du projet."""
    reg = get_ngf_setting(doc)
    if reg:
        name, ngf = reg
        for l in DB.FilteredElementCollector(doc).OfClass(DB.Level):
            if l.Name == name:
                return ngf - l.ProjectElevation
    try:
        pos = doc.ActiveProjectLocation.GetProjectPosition(DB.XYZ.Zero)
        return pos.Elevation
    except Exception:
        return 0.0


def _len(inst, name):
    p = inst.LookupParameter(name)
    return p.AsDouble() if (p and p.HasValue) else 0.0


def _fmt_mm(v):
    return "%d" % int(round(v * 304.8))


def update_tag_values(doc, inst, ngf0=None):
    """Recalcule RES_Dimensions, RES_AI, RES_NGF, RES_Niveau d'une reservation."""
    if ngf0 is None:
        ngf0 = _ngf_offset(doc)
    name = inst.Symbol.Family.Name
    vertical = "Verticale" in name
    pn = inst.LookupParameter("RES_Numero")
    if pn is not None and not pn.AsString():
        pn.Set(str(_next_numero(doc)))
    circ = "Circulaire" in name
    if circ:
        d = _len(inst, "RES_Diametre_Reservation")
        _set(inst, "RES_Dimensions", u"\u00d8" + _fmt_mm(d))
        demi_h = d / 2.0
    else:
        w = _len(inst, "RES_Largeur_Reservation")
        h = _len(inst, "RES_Hauteur_Reservation")
        _set(inst, "RES_Dimensions", _fmt_mm(w) + "x" + _fmt_mm(h))
        demi_h = h / 2.0
    z = inst.Location.Point.Z
    if vertical:
        z_ref = z                      # dessus de dalle (point d'insertion)
        lvl = _level_below(doc, z + 1 * MM)
        _set(inst, "RES_AI", z - lvl.ProjectElevation)
    else:
        z_ref = z - demi_h             # arase inferieure
        lvl = _level_below(doc, z_ref)
        _set(inst, "RES_AI", z_ref - lvl.ProjectElevation)
    _set(inst, "RES_NGF", z_ref + ngf0)
    _set(inst, "RES_Niveau", lvl.Name)


def all_reservations(doc, view_id=None):
    col = DB.FilteredElementCollector(doc, view_id) if view_id else DB.FilteredElementCollector(doc)
    return [i for i in col.OfClass(DB.FamilyInstance)
            if i.Symbol.Family.Name.startswith("RES_")]


# --------------------------------------------------------- etiquettes
TAGS = {"H": "RES_Etiquette_Horizontale", "V": "RES_Etiquette_Verticale"}


def ensure_tags(doc, fam_dir):
    """(Re)charge les 2 familles d'etiquette et renvoie {"H": sym, "V": sym}."""
    import allan_reservations as ar
    out = {}
    for key, name in TAGS.items():
        path = os.path.join(fam_dir, name + ".rfa")
        if os.path.exists(path):
            ref = clr.Reference[DB.Family]()
            doc.LoadFamily(path, ar._LoadOpts(), ref)
        fam = None
        for f in DB.FilteredElementCollector(doc).OfClass(DB.Family):
            if f.Name == name:
                fam = f
        if fam is None:
            continue
        sym = doc.GetElement(list(fam.GetFamilySymbolIds())[0])
        if not sym.IsActive:
            sym.Activate()
        out[key] = sym
    doc.Regenerate()
    return out


def tag_view(doc, view, tag_syms):
    """Met a jour les valeurs et etiquette les reservations visibles
    de la vue qui n'ont pas encore d'etiquette RES_. Retourne (nb_maj, nb_tags)."""
    doc.Regenerate()
    res = all_reservations(doc, view.Id)
    ngf0 = _ngf_offset(doc)
    for i in res:
        update_tag_values(doc, i, ngf0)

    deja = set()
    for t in DB.FilteredElementCollector(doc, view.Id).OfClass(DB.IndependentTag):
        try:
            if not doc.GetElement(t.GetTypeId()).FamilyName.startswith("RES_Etiquette"):
                continue
            for eid in t.GetTaggedLocalElementIds():
                deja.add(eid)
        except Exception:
            pass

    n = tag_elements(doc, view, [i for i in res if i.Id not in deja], tag_syms)
    return len(res), n


def tag_elements(doc, view, insts, tag_syms):
    """Pose l'etiquette H ou V sur chaque reservation. Retourne le nombre pose."""
    try:
        ech = view.Scale
    except Exception:
        ech = 50
    dec = 12 * MM * ech          # 12 mm papier
    try:
        right, up = view.RightDirection, view.UpDirection
    except Exception:
        return 0
    n = 0
    for i in insts:
        key = "V" if "Verticale" in i.Symbol.Family.Name else "H"
        sym = tag_syms.get(key)
        if sym is None:
            continue
        pt = i.Location.Point + right * dec + up * dec
        try:
            DB.IndependentTag.Create(doc, sym.Id, view.Id, DB.Reference(i), True,
                                     DB.TagOrientation.Horizontal, pt)
            n += 1
        except Exception:
            pass       # vue qui n'accepte pas les etiquettes (3D non verrouillee...)
    return n


def update_all(doc):
    """Recalcule les infos d'etiquette de toutes les reservations du projet."""
    doc.Regenerate()
    ngf0 = _ngf_offset(doc)
    res = all_reservations(doc)
    for i in res:
        update_tag_values(doc, i, ngf0)
    return len(res)



def curves_to_scan(doc, scope, uidoc=None):
    """Canalisations et gaines droites a traiter.
    scope : 'projet', 'vue' ou 'selection'."""
    if scope == "selection" and uidoc is not None:
        els = [doc.GetElement(i) for i in uidoc.Selection.GetElementIds()]
    elif scope == "vue":
        v = doc.ActiveView
        els = list(DB.FilteredElementCollector(doc, v.Id).OfClass(DB.Plumbing.Pipe)) + \
            list(DB.FilteredElementCollector(doc, v.Id).OfClass(DB.Mechanical.Duct))
    else:
        els = list(DB.FilteredElementCollector(doc).OfClass(DB.Plumbing.Pipe)) + \
            list(DB.FilteredElementCollector(doc).OfClass(DB.Mechanical.Duct))
    out = []
    for e in els:
        if isinstance(e, (DB.Plumbing.Pipe, DB.Mechanical.Duct)) and \
                isinstance(e.Location, DB.LocationCurve) and \
                isinstance(e.Location.Curve, DB.Line):
            out.append(e)
    return out


def choose_forme(titre="Forme des reservations"):
    """Fenetre de choix : Automatique / Circulaire / Rectangulaire.
    Retourne 'auto', 'circ', 'rect' ou None si annule."""
    from pyrevit import forms
    reg = get_reglages()
    ordre = [("Automatique (rond > rond, rect > rect)", "auto"),
             ("Circulaire", "circ"),
             ("Rectangulaire", "rect")]
    options = dict(ordre)
    msg = u"Forme ?   jeu %d mm/cote - arrondi %d mm" % (
        reg["jeu_gaine_mm"], reg["pas_rect_mm"])
    c = forms.CommandSwitchWindow.show([k for k, v in ordre], message=msg)
    return options.get(c) if c else None
