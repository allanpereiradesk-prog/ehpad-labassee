# -*- coding: utf-8 -*-
"""Allan BIM - generation des familles de reservation (Modele generique).

4 familles :
  RES_Horizontale_Circulaire    -> traversee de mur, reseau rond
  RES_Horizontale_Rectangulaire -> traversee de mur, reseau rectangulaire
  RES_Verticale_Circulaire      -> traversee de dalle, reseau rond
  RES_Verticale_Rectangulaire   -> traversee de dalle, reseau rectangulaire

Taille de la reservation = taille du reseau + 2 x (isolant + jeu),
arrondie au pas superieur (10 mm par defaut).
Tous les parametres RES_* sont des parametres partages : on peut les
mettre en nomenclature et les etiqueter dans le projet.
"""

import os
import math
import clr
from System import Guid
from Autodesk.Revit import DB

MM = 1.0 / 304.8

# nom, type, guid, groupe, instance, description
SHARED = [
    ("RES_Code", "text", "349e948e-765c-4b0b-a5f4-8bfd607e013d", "id", True, u"Repere unique de la reservation (ex : R-RDC-001)"),
    ("RES_Lot", "text", "7c4650ca-43cd-4cda-b96f-8d3f4afcaf78", "id", True, u"Lot demandeur (CVC, Plomberie, Elec...)"),
    ("RES_Reseau", "text", "8786a602-95db-47a9-97c0-6990209d947e", "id", True, u"Reseau qui traverse (EF, ECS, Chauffage, VMC...)"),
    ("RES_Paroi", "text", "d89baa51-c6d5-44a7-8a3e-bc636cf0b88d", "id", True, u"Paroi traversee (voile BA, dalle BA, cloison...)"),
    ("RES_Statut", "text", "45f9985a-81d8-4c03-82b1-35ab4b0cf44b", "id", True, u"A valider / Validee / Realisee / Refusee"),
    ("RES_Forme", "text", "a7e24597-113a-4aef-add0-0cc95928c57d", "id", False, u"Circulaire ou Rectangulaire"),
    ("RES_Orientation", "text", "0d2550e4-7248-4faa-b53e-38d1100b4674", "id", False, u"Horizontale (mur) ou Verticale (dalle)"),
    ("RES_Coupe_Feu", "yesno", "977e3b00-d80a-49e7-9621-b68416e7a270", "fire", True, u"Traversee a calfeutrer coupe-feu"),
    ("RES_Degre_CF", "text", "31a3cf8b-d461-4239-b2cf-7bb484813ca4", "fire", True, u"Degre coupe-feu de la paroi (EI 60, EI 120...)"),
    ("RES_Diametre_Reseau", "len", "8d6d70aa-7aa8-4fea-b4ea-b1998ddfeeb8", "geo", True, u"Diametre exterieur du tuyau ou de la gaine"),
    ("RES_Largeur_Reseau", "len", "2851eeaa-4797-4287-921a-f0e8d9acedf5", "geo", True, u"Largeur exterieure du reseau rectangulaire"),
    ("RES_Hauteur_Reseau", "len", "0523dc43-8e5b-4c07-ab56-c5bf6bcdb7f2", "geo", True, u"Hauteur exterieure du reseau rectangulaire"),
    ("RES_Epaisseur_Isolant", "len", "ffded3be-e1e5-4a98-acca-3bdf4a0d605f", "geo", True, u"Epaisseur d'isolant autour du reseau"),
    ("RES_Jeu", "len", "c93c4925-7a09-4c45-8279-e742dde265d4", "geo", True, u"Jeu de chaque cote (calfeutrement)"),
    ("RES_Pas_Arrondi", "len", "e471398c-4820-4e04-bfc9-1b299771a095", "geo", False, u"La reservation est arrondie a ce pas superieur"),
    ("RES_Epaisseur_Paroi", "len", "186baea0-86a6-4b40-91d6-914d465f3bc8", "geo", True, u"Epaisseur du mur ou de la dalle traverse"),
    ("RES_Debord", "len", "7ce32d86-3850-44aa-9ed9-a5523a6c2a2b", "geo", True, u"Depassement de chaque cote de la paroi"),
    ("RES_Diametre_Reservation", "len", "574781ad-1230-4aa8-a9f6-0a1d01ac096d", "geo", True, u"Diametre de la reservation (calcule)"),
    ("RES_Largeur_Reservation", "len", "fc538b66-60dd-4ee0-a04c-94d327a702ce", "geo", True, u"Largeur de la reservation (calculee)"),
    ("RES_Hauteur_Reservation", "len", "88f60d04-7f2a-41ed-b11d-2f4f35ee4313", "geo", True, u"Hauteur de la reservation (calculee)"),
    ("RES_Longueur_Reservation", "len", "13ba816f-9186-48ac-85df-952ce79a2055", "geo", True, u"Longueur du fourreau = paroi + 2 x debord (calculee)"),
    ("RES_Section", "area", "2c07b35e-8f10-41f2-b958-3e7660bad41f", "geo", True, u"Section de la reservation (calculee)"),
    # --- infos pour les etiquettes (mises a jour par Allan BIM)
    ("RES_Dimensions", "text", "5570e77b-d49c-4525-87f4-7f5ca059cac0", "id", True, u"Texte des dimensions (ex : 110 ou 440x240) - auto"),
    ("RES_AI", "len", "1875c82d-d7b3-4aae-8e36-cbf95248de6c", "id", True, u"Arase inferieure par rapport au niveau - auto"),
    ("RES_NGF", "len", "2177f4d3-b655-4301-a21d-7810296c6d33", "id", True, u"Altitude NGF (AI pour mur, dessus de dalle pour dalle) - auto"),
    ("RES_Niveau", "text", "25c36ec2-c326-467b-8a80-dd26d44dada0", "id", True, u"Niveau de reference - auto"),
    ("RES_Numero", "text", "5350fb43-c329-4bc3-92a4-4200f1456ee5", "id", True, u"Numero court de la reservation (pour l'etiquette) - auto"),
    # --- reglage projet (Informations sur le projet)
    ("RES_NGF_Reference", "len", "f31ab643-332f-45cd-941f-4214513ecfee", "id", True, u"Altitude NGF du niveau de reference (saisie manuelle)"),
    ("RES_NGF_Niveau_Ref", "text", "92afcca4-d259-4df2-9ab5-bd5624462d58", "id", True, u"Niveau de reference du NGF saisi (vide = point de topographie)"),
]

COMMON = ["RES_Code", "RES_Lot", "RES_Reseau", "RES_Paroi", "RES_Statut",
          "RES_Forme", "RES_Orientation", "RES_Coupe_Feu", "RES_Degre_CF",
          "RES_Epaisseur_Isolant", "RES_Jeu", "RES_Pas_Arrondi",
          "RES_Epaisseur_Paroi", "RES_Debord", "RES_Longueur_Reservation",
          "RES_Section", "RES_Dimensions", "RES_AI", "RES_NGF", "RES_Niveau",
          "RES_Numero"]
CIRC = ["RES_Diametre_Reseau", "RES_Diametre_Reservation"]
RECT = ["RES_Largeur_Reseau", "RES_Hauteur_Reseau",
        "RES_Largeur_Reservation", "RES_Hauteur_Reservation"]

FAMILIES = [
    # nom, forme, orientation
    ("RES_Horizontale_Circulaire", "circ", "H"),
    ("RES_Horizontale_Rectangulaire", "rect", "H"),
    ("RES_Verticale_Circulaire", "circ", "V"),
    ("RES_Verticale_Rectangulaire", "rect", "V"),
]


def _spec(kind):
    return {"len": DB.SpecTypeId.Length,
            "area": DB.SpecTypeId.Area,
            "text": DB.SpecTypeId.String.Text,
            "yesno": DB.SpecTypeId.Boolean.YesNo}[kind]


def _group(key):
    if key == "id":
        return DB.GroupTypeId.IdentityData
    if key == "fire":
        return getattr(DB.GroupTypeId, "FireProtection", DB.GroupTypeId.Data)
    return DB.GroupTypeId.Geometry


def get_shared_definitions(app, sp_path):
    """Cree / relit le fichier de parametres partages des reservations."""
    old = app.SharedParametersFilename
    if not os.path.exists(sp_path):
        open(sp_path, "w").close()
    app.SharedParametersFilename = sp_path
    try:
        dfile = app.OpenSharedParameterFile()
        grp = dfile.Groups.get_Item("Reservations")
        if grp is None:
            grp = dfile.Groups.Create("Reservations")
        defs = {}
        for name, kind, guid, g, inst, desc in SHARED:
            d = grp.Definitions.get_Item(name)
            if d is None:
                opt = DB.ExternalDefinitionCreationOptions(name, _spec(kind))
                opt.GUID = Guid(guid)
                opt.Description = desc
                d = grp.Definitions.Create(opt)
            defs[name] = d
    finally:
        try:
            if old:
                app.SharedParametersFilename = old
        except Exception:
            pass
    return defs


def _view(fdoc, kind):
    for v in DB.FilteredElementCollector(fdoc).OfClass(DB.View):
        if v.IsTemplate:
            continue
        if kind == "plan" and v.ViewType == DB.ViewType.FloorPlan:
            return v
        if kind == "front" and v.ViewType == DB.ViewType.Elevation \
                and abs(v.ViewDirection.Y) > 0.99:
            return v
    return None


def _center_plane(fdoc, axis):
    """Plan de reference du gabarit passant par l'origine, normale = axis."""
    for rp in DB.FilteredElementCollector(fdoc).OfClass(DB.ReferencePlane):
        n = rp.Normal
        if abs(abs(n.DotProduct(axis)) - 1.0) < 1e-6 and \
                abs(rp.BubbleEnd.DotProduct(axis)) < 1e-6:
            return rp
    return None


def _new_rp(fdoc, view, normal, pos, along, name):
    o = normal.Multiply(pos)
    p1 = o - along.Multiply(3.0)
    p2 = o + along.Multiply(3.0)
    rp = fdoc.FamilyCreate.NewReferencePlane(p1, p2, view.ViewDirection, view)
    rp.Name = name
    return rp


def _lin_dim(fdoc, view, planes, along, offset_dir, offset):
    ra = DB.ReferenceArray()
    for rp in planes:
        ra.Append(rp.GetReference())
    base = offset_dir.Multiply(offset)
    line = DB.Line.CreateBound(base - along.Multiply(2.0),
                               base + along.Multiply(2.0))
    return fdoc.FamilyCreate.NewLinearDimension(view, line, ra)


class _LoadOpts(DB.IFamilyLoadOptions):
    def OnFamilyFound(self, familyInUse, overwriteParameterValues):
        overwriteParameterValues.Value = True
        return True

    def OnSharedFamilyFound(self, sharedFamily, familyInUse, source,
                            overwriteParameterValues):
        source.Value = DB.FamilySource.Family
        overwriteParameterValues.Value = True
        return True


def build_family(app, defs, name, shape, orient, out_dir):
    tpl = os.path.join(app.FamilyTemplatePath,
                       u"Modèle générique métrique.rft")
    if not os.path.exists(tpl):
        tpl = os.path.join(os.path.dirname(app.FamilyTemplatePath),
                           "English", "Metric Generic Model.rft")
    fdoc = app.NewFamilyDocument(tpl)
    fm = fdoc.FamilyManager
    create = fdoc.FamilyCreate
    X, Y, Z = DB.XYZ.BasisX, DB.XYZ.BasisY, DB.XYZ.BasisZ

    t = DB.Transaction(fdoc, "Construction reservation")
    t.Start()

    if fm.CurrentType is None:
        fm.NewType("Standard")

    # base sur un plan de travail -> placable en coupe / elevation / 3D
    # toujours vertical -> la reservation garde son orientation
    # (horizontale = axe perpendiculaire au plan choisi, verticale = axe Z)
    own = fdoc.OwnerFamily
    own.get_Parameter(DB.BuiltInParameter.FAMILY_WORK_PLANE_BASED).Set(1)
    own.get_Parameter(DB.BuiltInParameter.FAMILY_ALWAYS_VERTICAL).Set(1)

    # ---------- parametres
    names = COMMON + (CIRC if shape == "circ" else RECT)
    P = {}
    for n, kind, guid, g, inst, desc in SHARED:
        if n in names:
            P[n] = fm.AddParameter(defs[n], _group(g), inst)
    p_dep = fm.AddParameter("Extrusion_Debut", DB.GroupTypeId.Constraints,
                            DB.SpecTypeId.Length, True)
    p_fin = fm.AddParameter("Extrusion_Fin", DB.GroupTypeId.Constraints,
                            DB.SpecTypeId.Length, True)
    p_mat = fm.AddParameter("RES_Materiau", DB.GroupTypeId.Materials,
                            DB.SpecTypeId.Reference.Material, False)

    # valeurs par defaut
    wall = (orient == "H")
    fm.Set(P["RES_Lot"], "CVC")
    fm.Set(P["RES_Reseau"], "")
    fm.Set(P["RES_Code"], "")
    fm.Set(P["RES_Paroi"], "Voile BA" if wall else "Dalle BA")
    fm.Set(P["RES_Statut"], "A valider")
    fm.Set(P["RES_Forme"], "Circulaire" if shape == "circ" else "Rectangulaire")
    fm.Set(P["RES_Orientation"], "Horizontale (traversee de mur)" if wall
           else "Verticale (traversee de dalle)")
    fm.Set(P["RES_Coupe_Feu"], 0)
    fm.Set(P["RES_Degre_CF"], "")
    fm.Set(P["RES_Epaisseur_Isolant"], 0.0)
    fm.Set(P["RES_Jeu"], 50 * MM)
    fm.Set(P["RES_Pas_Arrondi"], (10 if shape == "circ" else 50) * MM)
    fm.Set(P["RES_Epaisseur_Paroi"], 200 * MM)
    fm.Set(P["RES_Debord"], 0.0)

    enrob = "2 * (RES_Epaisseur_Isolant + RES_Jeu)"
    fm.SetFormula(P["RES_Longueur_Reservation"],
                  "RES_Epaisseur_Paroi + 2 * RES_Debord")
    if shape == "circ":
        fm.Set(P["RES_Diametre_Reseau"], 100 * MM)
        fm.SetFormula(P["RES_Diametre_Reservation"],
                      "roundup((RES_Diametre_Reseau + %s) / RES_Pas_Arrondi) * RES_Pas_Arrondi" % enrob)
        fm.SetFormula(P["RES_Section"], "pi() * RES_Diametre_Reservation ^ 2 / 4")
        size_u = size_v = 200 * MM
    else:
        fm.Set(P["RES_Largeur_Reseau"], 300 * MM)
        fm.Set(P["RES_Hauteur_Reseau"], 200 * MM)
        fm.SetFormula(P["RES_Largeur_Reservation"],
                      "roundup((RES_Largeur_Reseau + %s) / RES_Pas_Arrondi) * RES_Pas_Arrondi" % enrob)
        fm.SetFormula(P["RES_Hauteur_Reservation"],
                      "roundup((RES_Hauteur_Reseau + %s) / RES_Pas_Arrondi) * RES_Pas_Arrondi" % enrob)
        fm.SetFormula(P["RES_Section"],
                      "RES_Largeur_Reservation * RES_Hauteur_Reservation")
        size_u, size_v = 400 * MM, 300 * MM

    if wall:
        fm.SetFormula(p_dep, "-RES_Longueur_Reservation / 2")
        fm.SetFormula(p_fin, "RES_Longueur_Reservation / 2")
        dep, fin = -100 * MM, 100 * MM
    else:
        fm.SetFormula(p_dep, "-RES_Epaisseur_Paroi - RES_Debord")
        fm.SetFormula(p_fin, "RES_Debord")
        dep, fin = -200 * MM, 0.0

    # description
    try:
        pd = fm.get_Parameter(DB.BuiltInParameter.ALL_MODEL_DESCRIPTION)
        fm.Set(pd, u"Reservation %s %s - Allan BIM" % (
            "circulaire" if shape == "circ" else "rectangulaire",
            "horizontale (mur)" if wall else "verticale (dalle)"))
    except Exception:
        pass

    # ---------- materiau + sous-categorie
    mid = DB.Material.Create(fdoc, "AllanBIM - Reservation")
    mat = fdoc.GetElement(mid)
    red = DB.Color(230, 30, 30)
    mat.Color = red
    mat.Transparency = 50
    try:
        solid = [fp for fp in DB.FilteredElementCollector(fdoc).OfClass(DB.FillPatternElement)
                 if fp.GetFillPattern().IsSolidFill][0]
        mat.SurfaceForegroundPatternId = solid.Id
        mat.SurfaceForegroundPatternColor = red
        mat.CutForegroundPatternId = solid.Id
        mat.CutForegroundPatternColor = red
    except Exception:
        pass
    fm.Set(p_mat, mid)

    cats = fdoc.Settings.Categories
    parent = fdoc.OwnerFamily.FamilyCategory
    sub = cats.NewSubcategory(parent, "Reservations")
    sub.LineColor = red

    # ---------- repere geometrique
    if wall:
        view = _view(fdoc, "front")
        u, v, n = X, Z, Y
        cu = _center_plane(fdoc, X)
        cv = _new_rp(fdoc, view, Z, 0.0, X, "Centre (Haut/Bas)")
    else:
        view = _view(fdoc, "plan")
        u, v, n = X, Y, Z
        cu = _center_plane(fdoc, X)
        cv = _center_plane(fdoc, Y)

    plane = DB.Plane.CreateByNormalAndOrigin(n, DB.XYZ.Zero)
    sp = DB.SketchPlane.Create(fdoc, plane)

    prof = DB.CurveArray()
    if shape == "circ":
        r = size_u / 2.0
        prof.Append(DB.Arc.Create(plane, r, 0.0, math.pi))
        prof.Append(DB.Arc.Create(plane, r, math.pi, 2 * math.pi))
    else:
        hu, hv = size_u / 2.0, size_v / 2.0
        pts = [u * (-hu) + v * (-hv), u * hu + v * (-hv),
               u * hu + v * hv, u * (-hu) + v * hv]
        for i in range(4):
            prof.Append(DB.Line.CreateBound(pts[i], pts[(i + 1) % 4]))
    caa = DB.CurveArrArray()
    caa.Append(prof)
    extr = create.NewExtrusion(True, caa, sp, fin - dep)
    extr.StartOffset = dep
    extr.EndOffset = fin
    extr.Subcategory = sub
    fdoc.Regenerate()

    fm.AssociateElementParameterToFamilyParameter(
        extr.get_Parameter(DB.BuiltInParameter.EXTRUSION_START_PARAM), p_dep)
    fm.AssociateElementParameterToFamilyParameter(
        extr.get_Parameter(DB.BuiltInParameter.EXTRUSION_END_PARAM), p_fin)
    fm.AssociateElementParameterToFamilyParameter(
        extr.get_Parameter(DB.BuiltInParameter.MATERIAL_ID_PARAM), p_mat)

    curves = [c for arr in extr.Sketch.Profile for c in arr]

    if shape == "circ":
        arc = curves[0]
        d = create.NewDiameterDimension(view, arc.Reference,
                                        u * (size_u) + v * (size_u))
        d.FamilyLabel = P["RES_Diametre_Reservation"]
    else:
        hu, hv = size_u / 2.0, size_v / 2.0
        ru_m = _new_rp(fdoc, view, u, -hu, v, "Res_Gauche")
        ru_p = _new_rp(fdoc, view, u, hu, v, "Res_Droite")
        rv_m = _new_rp(fdoc, view, v, -hv, u, "Res_Bas")
        rv_p = _new_rp(fdoc, view, v, hv, u, "Res_Haut")
        fdoc.Regenerate()
        # verrouillage des cotes du croquis sur les plans
        for c in curves:
            mid_pt = c.Evaluate(0.5, True)
            du, dv = mid_pt.DotProduct(u), mid_pt.DotProduct(v)
            if abs(du - hu) < 1e-6:
                rp = ru_p
            elif abs(du + hu) < 1e-6:
                rp = ru_m
            elif abs(dv - hv) < 1e-6:
                rp = rv_p
            else:
                rp = rv_m
            al = create.NewAlignment(view, rp.GetReference(), c.Reference)
            al.IsLocked = True
        # cotes EQ + cotes labelisees
        eq1 = _lin_dim(fdoc, view, [ru_m, cu, ru_p], u, v, hv + 0.5)
        eq1.AreSegmentsEqual = True
        eq2 = _lin_dim(fdoc, view, [rv_m, cv, rv_p], v, u, hu + 0.5)
        eq2.AreSegmentsEqual = True
        dl = _lin_dim(fdoc, view, [ru_m, ru_p], u, v, hv + 0.9)
        dl.FamilyLabel = P["RES_Largeur_Reservation"]
        dh = _lin_dim(fdoc, view, [rv_m, rv_p], v, u, hu + 0.9)
        dh.FamilyLabel = P["RES_Hauteur_Reservation"]

    fdoc.Regenerate()
    t.Commit()

    path = os.path.join(out_dir, name + ".rfa")
    opts = DB.SaveAsOptions()
    opts.OverwriteExistingFile = True
    fdoc.SaveAs(path, opts)
    fdoc.Close(False)
    return path


def build_all(doc, out_dir, load=True):
    """Genere les 4 familles dans out_dir et les charge dans doc
    (doc doit etre dans une transaction ouverte si load=True)."""
    app = doc.Application
    if not os.path.isdir(out_dir):
        os.makedirs(out_dir)
    defs = get_shared_definitions(
        app, os.path.join(out_dir, "Parametres_Reservations.txt"))
    results = []
    for name, shape, orient in FAMILIES:
        path = build_family(app, defs, name, shape, orient, out_dir)
        ok = None
        if load:
            ref = clr.Reference[DB.Family]()
            ok = doc.LoadFamily(path, _LoadOpts(), ref)
        results.append((name, path, ok))
    return results
