# -*- coding: utf-8 -*-
"""Allan BIM - fenetre de dessin de traces (logique + interface)."""

import os
import math
import clr
clr.AddReference("PresentationFramework")
clr.AddReference("PresentationCore")
clr.AddReference("WindowsBase")
from System.Windows import Point
from System.Windows.Shapes import Line, Ellipse
from System.Windows.Controls import Canvas, TextBlock
from System.Windows.Media import SolidColorBrush, Color, DoubleCollection
from Autodesk.Revit import DB
from pyrevit import forms
import allan_trace as tr

rel = tr.rel
FT = 0.3048
MSG_DRAW = u"Dessiner ON : clique un reseau (pres d'un bout) pour commencer, puis tes points, et finis sur un autre reseau (bout ou milieu).  Clic droit = retirer le dernier point."
MSG_EDIT = u"Dessiner OFF : clique sur un trait rouge pour le modifier (panneau a droite) ou glisse un point rouge."


def brush(r, g, b):
    return SolidColorBrush(Color.FromRgb(r, g, b))




def mep_ok(el):
    if isinstance(el, (DB.Plumbing.Pipe, DB.Mechanical.Duct)):
        return True
    try:
        return el.MEPModel is not None and el.MEPModel.ConnectorManager is not None
    except Exception:
        return False


class Ctx(object):
    """Repere de dessin : plan de la vue passant par le 1er connecteur."""
    def __init__(self, view, sel):
        self.U, self.V, self.N = tr.view_axes(view)
        first = None
        for e in sel:
            cs = rel.connectors(e)
            if cs:
                first = cs[0]
                break
        if first is None:
            raise Exception("Aucun connecteur trouve sur la selection.")
        self.O = first.Origin
        self.elems = []
        for e in sel:
            item = {"el": e, "curve": rel.is_curve(e), "line": None, "ends": [], "dirs": []}
            if item["curve"]:
                c = e.Location.Curve
                item["line"] = (self.uv(c.GetEndPoint(0)), self.uv(c.GetEndPoint(1)))
                for con in rel.connectors(e):
                    if con.ConnectorType == DB.ConnectorType.End:
                        item["ends"].append((self.uv(con.Origin), con.Origin, con.IsConnected))
                        item["dirs"].append(self.dir_uv(con))
            else:
                for con in rel.connectors(e):
                    item["ends"].append((self.uv(con.Origin), con.Origin, con.IsConnected))
                    item["dirs"].append(self.dir_uv(con))
            self.elems.append(item)

    def dir_uv(self, con):
        """Direction sortante du connecteur dans le plan de dessin (ou None
        s'il sort perpendiculairement a la vue)."""
        try:
            z = con.CoordinateSystem.BasisZ
            x, y = z.DotProduct(self.U), z.DotProduct(self.V)
            L = math.hypot(x, y)
            return (x / L, y / L) if L > 0.3 else None
        except Exception:
            return None

    def uv(self, p):
        d = p - self.O
        return (d.DotProduct(self.U) * FT, d.DotProduct(self.V) * FT)

def seg_dist(p, a, b):
    """Distance point-segment et point projete (en metres)."""
    ax, ay = a; bx, by = b; px, py = p
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    t = 0.0 if L2 < 1e-12 else max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / L2))
    q = (ax + t * dx, ay + t * dy)
    return math.hypot(px - q[0], py - q[1]), q, t


# ------------------------------------------------------------ fenetre
class DessinWindow(forms.WPFWindow):
    def __init__(self, xaml, ctx):
        self.ready = False
        self.ctx = ctx
        forms.WPFWindow.__init__(self, xaml)
        self.traces = []         # {"start": (idx, uv, xyz), "pts": [uv], "end": None|(idx, uv, xyz)}
        self.cur = None          # trace en cours de dessin
        self.sel = None          # (trace, k) troncon selectionne
        self.drag = None         # (trace, i) point deplace
        self.mouse = None
        self.hover = None
        self.hover_net = None
        self.guide = None
        self.ok = False
        self.info.Text = MSG_DRAW
        self.Loaded += self._loaded

    # ---- repere
    def _loaded(self, s, a):
        xs, ys = [0.0], [0.0]
        for it in self.ctx.elems:
            pts = list(it["line"]) if it["line"] else []
            pts += [x[0] for x in it["ends"]]
            for p in pts:
                xs.append(p[0]); ys.append(p[1])
        cx, cy = (min(xs) + max(xs)) / 2.0, (min(ys) + max(ys)) / 2.0
        span = max(max(xs) - min(xs), max(ys) - min(ys), 3.0) * 1.3
        self.W, self.H = self.canvas.ActualWidth, self.canvas.ActualHeight
        self.scale = min(self.W, self.H) / span
        self.cx, self.cy = cx, cy
        self.ready = True
        self.redraw()

    def to_px(self, p):
        return Point(self.W / 2 + (p[0] - self.cx) * self.scale, self.H / 2 - (p[1] - self.cy) * self.scale)

    def to_m(self, pt):
        return ((pt.X - self.W / 2) / self.scale + self.cx, -(pt.Y - self.H / 2) / self.scale + self.cy)

    def drawing(self):
        return bool(self.tgl_draw.IsChecked)

    # ---- accrochages
    def angle_step(self):
        k = self.cmb_angle.SelectedIndex
        if k == 0:
            return None
        if k == 5:
            try:
                v = float(str(self.txt_angle.Text).replace(",", "."))
                return v if 1 <= v <= 90 else None
            except Exception:
                return None
        return [None, 90.0, 45.0, 30.0, 15.0][k]

    def find_network(self, p, exclude=None):
        """Bout de reseau (prioritaire) ou trait de gaine/tuyau sous le curseur.
        Retourne (idx, uv, xyz, 'bout'|'milieu') ou None."""
        tol = 22.0 / self.scale
        best = None
        for i, it in enumerate(self.ctx.elems):
            for q, xyz, conn in it["ends"]:
                d = math.hypot(p[0] - q[0], p[1] - q[1])
                if d < tol and (best is None or d < best[0]):
                    best = (d, (i, q, xyz, "bout"))
        if best:
            return best[1]
        for i, it in enumerate(self.ctx.elems):
            if i == exclude or not it["line"]:
                continue
            d, q, t = seg_dist(p, it["line"][0], it["line"][1])
            if d < 14.0 / self.scale and 0.02 < t < 0.98:
                c = it["el"].Location.Curve
                xyz = c.Evaluate(t, True)
                return (i, q, xyz, "milieu")
        return None

    def net_dir(self, net):
        """Direction (dans le dessin) du reseau accroche : axe sortant pour un
        bout, direction du trait pour un milieu."""
        it = self.ctx.elems[net[0]]
        if net[3] == "milieu" and it["line"]:
            a, b = it["line"]
            L = math.hypot(b[0] - a[0], b[1] - a[1])
            return ((b[0] - a[0]) / L, (b[1] - a[1]) / L) if L > 1e-9 else None
        best = None
        for (q, xyz, conn), d in zip(it["ends"], it["dirs"]):
            dist = math.hypot(q[0] - net[1][0], q[1] - net[1][1])
            if best is None or dist < best[0]:
                best = (dist, d)
        return best[1] if best else None

    def base_angle(self):
        """Angle de reference : le troncon precedent, ou l'axe du reseau de
        depart. Les angles (90, 45...) sont comptes a partir de lui."""
        if self.cur is None:
            return 0.0
        ch = self.chain(self.cur)
        if len(ch) >= 2:
            return math.degrees(math.atan2(ch[-1][1] - ch[-2][1], ch[-1][0] - ch[-2][0]))
        d = self.net_dir(self.cur["start"])
        return math.degrees(math.atan2(d[1], d[0])) if d else 0.0

    def snap(self, p, prev):
        self.guide = None
        dx, dy = p[0] - prev[0], p[1] - prev[1]
        L = math.hypot(dx, dy)
        if L < 1e-9:
            return prev
        step = self.angle_step()
        grid = self.chk_grille.IsChecked
        if step:
            base = self.base_angle()
            a = base + round((math.degrees(math.atan2(dy, dx)) - base) / step) * step
            ux, uy = math.cos(math.radians(a)), math.sin(math.radians(a))
            L = dx * ux + dy * uy
            if grid:
                L = round(L / 0.05) * 0.05
            # alignement automatique sur l'axe (ou la perpendiculaire) des bouts de reseaux
            tol, best = 14.0 / self.scale, None
            for it in self.ctx.elems:
                for (q, xyz, conn), d in zip(it["ends"], it["dirs"]):
                    if d is None:
                        continue
                    for lx, ly in (d, (-d[1], d[0])):
                        den = ux * ly - uy * lx
                        if abs(den) < 1e-6:
                            continue
                        Li = ((q[0] - prev[0]) * ly - (q[1] - prev[1]) * lx) / den
                        if Li > 0.15 and abs(Li - L) < tol and (best is None or abs(Li - L) < best[0]):
                            best = (abs(Li - L), Li, q)
            if best:
                L = best[1]
                self.guide = (best[2], (prev[0] + L * ux, prev[1] + L * uy))
            return (prev[0] + L * ux, prev[1] + L * uy)
        if grid:
            return (round(p[0] / 0.05) * 0.05, round(p[1] / 0.05) * 0.05)
        return p

    def auto_arrivee(self, net):
        """Corrige la fin du trace pour arriver a angle droit sur le reseau :
        dans l'axe d'un bout (ou perpendiculaire), perpendiculaire a un milieu.
        Deplace le dernier point le long de son troncon, ou ajoute un point."""
        try:
            if not self.chk_auto.IsChecked:
                return False
        except Exception:
            return False
        l = self.net_dir(net)
        if l is None:
            return False
        cur, T = self.cur, net[1]
        ch = self.chain(cur)
        P = ch[-1]
        perp = (-l[1], l[0])
        lignes = [(perp, False)] if net[3] == "milieu" else [(l, True), (perp, False)]
        if len(ch) >= 2:
            orig = ch[-2]
            n = math.hypot(P[0] - orig[0], P[1] - orig[1])
            din = ((P[0] - orig[0]) / n, (P[1] - orig[1]) / n) if n > 1e-9 else None
        else:
            orig, din = P, self.net_dir(cur["start"])
        for a, sortant in lignes:
            def devant(X):
                al = (X[0] - T[0]) * a[0] + (X[1] - T[1]) * a[1]
                return al >= 0.15 if sortant else abs(al) >= 0.15
            off = (P[0] - T[0]) * a[1] - (P[1] - T[1]) * a[0]
            if abs(off) < 0.01 and devant(P) and len(ch) >= 2:
                return False                    # deja bien aligne
            if din is not None:
                den = din[0] * a[1] - din[1] * a[0]
                if abs(den) > 1e-3:
                    k = ((T[0] - orig[0]) * a[1] - (T[1] - orig[1]) * a[0]) / den
                    X = (orig[0] + k * din[0], orig[1] + k * din[1])
                    if k >= 0.15 and devant(X):
                        if len(ch) >= 2:
                            cur["pts"][-1] = X
                        else:
                            cur["pts"].append(X)
                        return True
            al = (P[0] - T[0]) * a[0] + (P[1] - T[1]) * a[1]
            P2 = (T[0] + a[0] * al, T[1] + a[1] * al)
            n2 = math.hypot(P2[0] - P[0], P2[1] - P[1])
            demi_tour = din is not None and n2 > 1e-9 and \
                ((P2[0] - P[0]) * din[0] + (P2[1] - P[1]) * din[1]) / n2 < -0.5
            if n2 >= 0.15 and devant(P2) and not demi_tour:
                cur["pts"].append(P2)
                return True
        return False

    # ---- dessin
    def _line(self, a, b, col, w, dash=False):
        ln = Line()
        pa, pb = self.to_px(a), self.to_px(b)
        ln.X1, ln.Y1, ln.X2, ln.Y2 = pa.X, pa.Y, pb.X, pb.Y
        ln.Stroke, ln.StrokeThickness = col, w
        ln.IsHitTestVisible = False          # le clic passe toujours au canevas
        if dash:
            dc = DoubleCollection(); dc.Add(4); dc.Add(3); ln.StrokeDashArray = dc
        self.canvas.Children.Add(ln)
        return ln

    def _dot(self, p, col, r=5, txt=None):
        e = Ellipse(); e.Width = e.Height = 2 * r; e.Fill = col
        e.IsHitTestVisible = False
        px = self.to_px(p)
        Canvas.SetLeft(e, px.X - r); Canvas.SetTop(e, px.Y - r)
        self.canvas.Children.Add(e)
        if txt:
            t = TextBlock(); t.Text = txt; t.Foreground = col; t.FontSize = 12
            t.IsHitTestVisible = False
            Canvas.SetLeft(t, px.X + 8); Canvas.SetTop(t, px.Y - 18)
            self.canvas.Children.Add(t)
        return e

    def chain(self, t):
        c = [t["start"][1]] + t["pts"]
        if t["end"]:
            c.append(t["end"][1])
        return c

    def redraw(self):
        """Redessine tout (appele seulement quand le dessin change)."""
        if not getattr(self, "ready", False):
            return
        self.canvas.Children.Clear()
        g = brush(40, 48, 56)
        x0, y0 = self.to_m(Point(0, self.H)); x1, y1 = self.to_m(Point(self.W, 0))
        pas = 0.5
        while (x1 - x0) / pas > 80:          # pas trop de lignes de grille
            pas *= 2
        k = math.floor(x0 / pas)
        while k * pas <= x1:
            self._line((k * pas, y0), (k * pas, y1), g, 1); k += 1
        k = math.floor(y0 / pas)
        while k * pas <= y1:
            self._line((x0, k * pas), (x1, k * pas), g, 1); k += 1
        for i, it in enumerate(self.ctx.elems):
            if it["line"]:
                self._line(it["line"][0], it["line"][1], brush(90, 160, 255), 6)
            for q, xyz, conn in it["ends"]:
                self._dot(q, brush(150, 150, 150) if conn else brush(90, 200, 120), 5)
        for t in self.traces:
            ch = self.chain(t)
            done = t["end"] is not None
            for k, (a, b) in enumerate(zip(ch[:-1], ch[1:])):
                selected = self.sel is not None and self.sel[0] is t and self.sel[1] == k
                col = brush(255, 210, 60) if selected else (brush(90, 200, 120) if done and k == len(ch) - 2 else brush(230, 60, 60))
                self._line(a, b, col, 5 if selected else 4)
            for p in t["pts"]:
                self._dot(p, brush(230, 60, 60), 5)
            self._dot(ch[0], brush(90, 200, 120), 7)
            if done:
                self._dot(ch[-1], brush(255, 170, 60), 7)
        # calque dynamique (deplace a chaque mouvement de souris, sans tout redessiner)
        self.rubber = self._line((0, 0), (0, 0), brush(230, 120, 120), 2, True)
        self.hover_el = self._dot((0, 0), brush(255, 230, 80), 10)
        self.guide_el = self._line((0, 0), (0, 0), brush(80, 220, 255), 1, True)
        self.update_dynamic()

    def update_dynamic(self):
        from System.Windows import Visibility
        if not getattr(self, "ready", False) or not hasattr(self, "rubber"):
            return
        if self.cur is not None and self.mouse and self.drawing():
            a, b = self.to_px(self.chain(self.cur)[-1]), self.to_px(self.mouse)
            self.rubber.X1, self.rubber.Y1, self.rubber.X2, self.rubber.Y2 = a.X, a.Y, b.X, b.Y
            self.rubber.Visibility = Visibility.Visible
        else:
            self.rubber.Visibility = Visibility.Hidden
        g = getattr(self, "guide", None)
        if g and self.cur is not None and self.drawing() and hasattr(self, "guide_el"):
            a, b = self.to_px(g[0]), self.to_px(g[1])
            self.guide_el.X1, self.guide_el.Y1, self.guide_el.X2, self.guide_el.Y2 = a.X, a.Y, b.X, b.Y
            self.guide_el.Visibility = Visibility.Visible
        elif hasattr(self, "guide_el"):
            self.guide_el.Visibility = Visibility.Hidden
        if self.hover:
            px = self.to_px(self.hover)
            Canvas.SetLeft(self.hover_el, px.X - 10); Canvas.SetTop(self.hover_el, px.Y - 10)
            self.hover_el.Visibility = Visibility.Visible
        else:
            self.hover_el.Visibility = Visibility.Hidden

    # ---- evenements souris
    def on_move(self, s, a):
        try:
            self._on_move(s, a)
        except Exception as ex:
            self.info.Text = u"Erreur : %s" % ex

    def _on_move(self, s, a):
        if not getattr(self, "ready", False):
            return
        p = self.to_m(a.GetPosition(self.canvas))
        self.hover = None
        self.guide = None
        if self.drag is not None:
            t, i = self.drag
            if self.chk_grille.IsChecked:
                p = (round(p[0] / 0.05) * 0.05, round(p[1] / 0.05) * 0.05)
            t["pts"][i] = p
            self.redraw()
            return
        if self.drawing():
            net = self.find_network(p, self.cur["start"][0] if self.cur else None)
            self.hover_net = net
            if net:
                self.hover = net[1]
                self.mouse = net[1]
            elif self.cur is not None:
                self.mouse = self.snap(p, self.chain(self.cur)[-1])
            else:
                self.mouse = p
            if self.cur is not None:
                last = self.chain(self.cur)[-1]
                dx, dy = self.mouse[0] - last[0], self.mouse[1] - last[1]
                L = math.hypot(dx, dy)
                ang = math.degrees(math.atan2(dy, dx)) if L > 1e-9 else 0
                self.coord.Text = u"longueur %.2f m   angle %.0f deg   (dx %.2f / dy %.2f m)" % (L, ang, dx, dy)
        self.update_dynamic()

    def on_down(self, s, a):
        try:
            self._on_down(s, a)
        except Exception as ex:
            self.info.Text = u"Erreur : %s" % ex

    def _on_down(self, s, a):
        if not getattr(self, "ready", False):
            return
        p = self.to_m(a.GetPosition(self.canvas))
        if self.drawing():
            self._click_draw(p)
        else:
            self._click_edit(p)

    def on_up(self, s, a):
        try:
            self._on_up(s, a)
        except Exception as ex:
            self.info.Text = u"Erreur : %s" % ex

    def _on_up(self, s, a):
        if self.drag is not None:
            self.drag = None
            self.canvas.ReleaseMouseCapture()
            self._fill_panel()
            self.redraw()

    def on_right(self, s, a):
        try:
            self._on_right(s, a)
        except Exception as ex:
            self.info.Text = u"Erreur : %s" % ex

    def _on_right(self, s, a):
        if self.cur is not None:
            if self.cur["pts"]:
                self.cur["pts"].pop()
            else:
                self.traces.remove(self.cur)
                self.cur = None
            self.redraw()

    def _click_draw(self, p):
        try:
            self.__click_draw(p)
        finally:
            self.hover_net = None
            self.hover = None

    def __click_draw(self, p):
        if self.cur is None:
            net = self.hover_net or self.find_network(p)
            if net and net[3] == "milieu":
                # clic sur le trait d'un reseau : on part de son bout le plus proche
                it = self.ctx.elems[net[0]]
                q, xyz, _c = min(it["ends"], key=lambda e: math.hypot(e[0][0] - p[0], e[0][1] - p[1]))
                net = (net[0], q, xyz, "bout")
            if not net:
                self.info.Text = u"Clique sur un reseau (trait bleu ou point vert) pour commencer le trace."
                return
            self.cur = {"start": net, "pts": [], "end": None}
            self.traces.append(self.cur)
            self.info.Text = u"Trace %d : clique les points, puis finis sur un autre reseau (bout ou milieu). Clic droit = retirer." % len(self.traces)
            self.redraw()
            return
        net = self.hover_net or self.find_network(p, self.cur["start"][0])
        if net and net[0] != self.cur["start"][0]:
            corrige = self.auto_arrivee(net)
            self.cur["end"] = net
            self.cur = None
            self.info.Text = (u"Trace termine (arrivee corrigee a angle droit). " if corrige else u"Trace termine. ") + \
                u"Clique le bout d'un autre reseau pour un nouveau trace, ou Modeliser."
            self.redraw()
            return
        last = self.chain(self.cur)[-1]
        q = self.snap(p, last)
        if math.hypot(q[0] - last[0], q[1] - last[1]) < 0.15:
            self.info.Text = u"Point trop proche du precedent (15 cm mini pour placer un coude)."
            return
        self.cur["pts"].append(q)
        self.redraw()

    def _click_edit(self, p):
        tol = 10.0 / self.scale
        # glisser un point
        for t in self.traces:
            for i, q in enumerate(t["pts"]):
                if math.hypot(p[0] - q[0], p[1] - q[1]) < tol:
                    self.drag = (t, i)
                    self.canvas.CaptureMouse()
                    return
        # selectionner un troncon
        best = None
        for t in self.traces:
            ch = self.chain(t)
            for k, (a, b) in enumerate(zip(ch[:-1], ch[1:])):
                d, q, _ = seg_dist(p, a, b)
                if d < tol and (best is None or d < best[0]):
                    best = (d, t, k)
        self.sel = (best[1], best[2]) if best else None
        self._fill_panel()
        self.redraw()

    # ---- panneau de modification
    def _fill_panel(self):
        if not self.sel:
            self.sel_info.Text = u"Aucun troncon selectionne"
            for tb in (self.ed_len, self.ed_ang, self.ed_dx, self.ed_dy):
                tb.Text = ""
            return
        t, k = self.sel
        ch = self.chain(t)
        a, b = ch[k], ch[k + 1]
        dx, dy = b[0] - a[0], b[1] - a[1]
        self.sel_info.Text = u"Trace %d - troncon %d / %d" % (self.traces.index(t) + 1, k + 1, len(ch) - 1)
        self.ed_len.Text = "%.3f" % math.hypot(dx, dy)
        self.ed_ang.Text = "%.1f" % math.degrees(math.atan2(dy, dx))
        self.ed_dx.Text = "%.3f" % dx
        self.ed_dy.Text = "%.3f" % dy

    def _move_end_of_sel(self, new_b):
        t, k = self.sel
        ch = self.chain(t)
        i = k            # index du point de fin dans t["pts"] (chain[k+1] = pts[k])
        if i >= len(t["pts"]):
            self.sel_info.Text = u"Ce troncon arrive sur le reseau : modifie plutot le troncon d'avant."
            return
        old = t["pts"][i]
        ddx, ddy = new_b[0] - old[0], new_b[1] - old[1]
        for j in range(i, len(t["pts"])):          # la suite du trace suit
            q = t["pts"][j]
            t["pts"][j] = (q[0] + ddx, q[1] + ddy)
        self._fill_panel()
        self.redraw()

    def _num(self, tb):
        return float(str(tb.Text).replace(",", ".").strip())

    def apply_polar(self, s, a):
        if not self.sel:
            return
        try:
            L, ang = self._num(self.ed_len), math.radians(self._num(self.ed_ang))
        except Exception:
            self.sel_info.Text = u"Valeurs non valides"
            return
        t, k = self.sel
        a0 = self.chain(t)[k]
        self._move_end_of_sel((a0[0] + L * math.cos(ang), a0[1] + L * math.sin(ang)))

    def apply_dxdy(self, s, a):
        if not self.sel:
            return
        try:
            dx, dy = self._num(self.ed_dx), self._num(self.ed_dy)
        except Exception:
            self.sel_info.Text = u"Valeurs non valides"
            return
        t, k = self.sel
        a0 = self.chain(t)[k]
        self._move_end_of_sel((a0[0] + dx, a0[1] + dy))

    def delete_point(self, s, a):
        if not self.sel:
            return
        t, k = self.sel
        if k < len(t["pts"]):
            t["pts"].pop(k)
        self.sel = None
        self._fill_panel()
        self.redraw()

    def delete_trace(self, s, a):
        if not self.sel:
            return
        t = self.sel[0]
        self.traces.remove(t)
        if self.cur is t:
            self.cur = None
        self.sel = None
        self._fill_panel()
        self.redraw()

    # ---- boutons
    def on_toggle(self, s, a):
        on = self.drawing()
        self.tgl_draw.Content = u"Dessiner : ON" if on else u"Dessiner : OFF"
        self.info.Text = MSG_DRAW if on else MSG_EDIT
        self.mouse = None
        if on:
            self.sel = None
            self._fill_panel()
        self.redraw()

    def refresh(self, s, a):
        try:
            self.redraw()
        except Exception:
            pass

    def clear_all(self, s, a):
        self.traces, self.cur, self.sel = [], None, None
        self._fill_panel()
        self.redraw()

    def cancel(self, s, a):
        self.Close()

    def validate(self, s, a):
        self.ok = True
        self.Close()




def modeliser(doc, ctx, traces):
    """Cree les reseaux pour chaque trace. A appeler dans une transaction.
    Retourne (lignes_ok, lignes_erreur)."""
    res, err = [], []
    for n, tc in enumerate(traces):
        if tc["end"] is None and not tc["pts"]:
            continue
        si, suv, sxyz, _ = tc["start"]
        e1 = ctx.elems[si]["el"]
        if not rel.is_curve(e1):
            err.append(u"Trace %d : doit commencer sur une gaine ou une canalisation" % (n + 1))
            continue
        c0 = tr.end_connector_near(e1, sxyz)
        O_t = c0.Origin
        pts3d = [O_t + ctx.U * ((p[0] - suv[0]) / FT) + ctx.V * ((p[1] - suv[1]) / FT) for p in tc["pts"]]
        e2, pick2 = None, None
        if tc["end"]:
            ei, euv, exyz, _ = tc["end"]
            e2, pick2 = ctx.elems[ei]["el"], exyz
        st = DB.SubTransaction(doc); st.Start()
        try:
            nseg, ncoudes, msg = tr.build_route(doc, e1, sxyz, pts3d, e2, pick2)
            st.Commit()
            res.append(u"Trace %d : %d troncon(s), %d coude(s), %s" % (n + 1, nseg, ncoudes, msg))
        except Exception as ex:
            st.RollBack()
            err.append(u"Trace %d : %s" % (n + 1, ex))
    return res, err
