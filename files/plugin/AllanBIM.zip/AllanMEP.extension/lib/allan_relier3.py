# -*- coding: utf-8 -*-
"""Allan BIM - relier deux reseaux avec 3 solutions au choix.

solutions(doc, e1, e2, univ) -> [Sol, Sol, Sol]
  1. liaison automatique (la plus courte : droit, coude, te ou 2 coudes)
  2. trace a angles droits (coudes a 90 deg)
  3. trace a 45 deg (coudes a 45 deg, moins de pertes de charge)
Chaque solution est essayee dans Revit puis annulee : elle n'est proposee
que si les raccords se posent. Les murs / dalles traverses (reservations a
prevoir) et les autres reseaux croises sont signales, sans bloquer.
"""
from Autodesk.Revit import DB
import allan_relier as rel
import allan_trace as tr
import allan_clash as ac

MM = 1.0 / 304.8
TOL = 5 * MM
MIN = 200 * MM


def bouts(e1, e2):
    """(e1, e2, c1, c2) avec e1 = gaine / tuyau, et les deux bouts a relier."""
    if not rel.is_curve(e1):
        e1, e2 = e2, e1
    if not rel.is_curve(e1):
        raise Exception("choisir au moins une gaine ou une canalisation")
    pair = rel.closest_pair(e1, e2)
    if pair is None:
        raise Exception("aucun connecteur compatible (gaine avec gaine, tuyau avec tuyau)")
    return e1, e2, pair[1], pair[2]


def points_90(pa, da, pb, db):
    v = pb - pa
    if abs(da.DotProduct(db)) > 0.999:
        t = v.DotProduct(da)
        r = v - da * t
        if r.GetLength() < TOL:
            return []
        if da.DotProduct(db) > 0:
            raise Exception("les deux bouts regardent dans le meme sens")
        if t < 2 * MIN:
            raise Exception("pas assez de distance entre les deux bouts")
        return [pa + da * (t / 2.0), pa + da * (t / 2.0) + r]
    res = rel.lines_closest(pa, da, pb, db)
    if res is None:
        raise Exception("axes paralleles")
    q1, q2, t, s = res
    if t < MIN or s < MIN:
        raise Exception("les axes se croisent derriere un des bouts")
    if q1.DistanceTo(q2) < 2 * TOL:
        return [(q1 + q2) * 0.5]
    if q1.DistanceTo(q2) < MIN:
        raise Exception("decalage trop petit entre les deux axes")
    return [q1, q2]


def points_45(pa, da, pb, db):
    v = pb - pa
    if abs(da.DotProduct(db)) > 0.999:
        t = v.DotProduct(da)
        r = v - da * t
        h = r.GetLength()
        if h < TOL:
            return []
        if da.DotProduct(db) > 0:
            raise Exception("les deux bouts regardent dans le meme sens")
        if t - h < 2 * MIN:
            raise Exception("pas assez de longueur pour des coudes a 45 deg")
        a = (t - h) / 2.0
        return [pa + da * a, pa + da * (a + h) + r]
    res = rel.lines_closest(pa, da, pb, db)
    if res is None:
        raise Exception("axes paralleles")
    q1, q2, t, s = res
    if q1.DistanceTo(q2) > 2 * TOL:
        raise Exception("les deux axes ne sont pas dans le meme plan")
    c = min(min(t, s) * 0.5, 1500 * MM)
    if c < MIN:
        raise Exception("pas assez de longueur pour des coudes a 45 deg")
    ip = (q1 + q2) * 0.5
    return [ip - da * c, ip - db * c]


def _ids(doc):
    out = set()
    for cls in (DB.Mechanical.Duct, DB.Plumbing.Pipe):
        for i in DB.FilteredElementCollector(doc).OfClass(cls).ToElementIds():
            out.add(ac.eid(i))
    for i in DB.FilteredElementCollector(doc).WherePasses(ac._cats(ac.CATS_RACC)) \
            .WhereElementIsNotElementType().ToElementIds():
        out.add(ac.eid(i))
    return out


BIC = DB.BuiltInCategory
STRUCTURE = set(int(c) for c in (BIC.OST_StructuralFraming, BIC.OST_StructuralColumns, BIC.OST_Columns,
                                 BIC.OST_Floors, BIC.OST_Ceilings, BIC.OST_Walls, BIC.OST_Roofs, BIC.OST_Stairs))


class Sol(object):
    def __init__(self, titre, mode):
        self.titre, self.mode = titre, mode
        self.points = None
        self.ok, self.raison, self.reco = False, "", False
        self.nseg = self.nracc = 0
        self.long = 0.0
        self.msg = ""
        self.structure = {}      # {"Murs": 2, ...} : parois traversees (reservations a prevoir)
        self.reseaux = 0         # autres reseaux / equipements croises (clash)

    def cout(self):
        return self.long + self.nracc * 1000 * MM + \
            sum(self.structure.values()) * 2000 * MM + self.reseaux * 20000 * MM

    def avertissement(self):
        lignes = []
        if self.reseaux:
            lignes.append("ATTENTION : croise %d autre(s) reseau(x) ou equipement(s) = clash a corriger ensuite." % self.reseaux)
        if self.structure:
            lignes.append("Traverse : %s  ->  reservation(s) a prevoir." % ", ".join(
                "%d %s" % (n, k) for k, n in sorted(self.structure.items())))
        return "\n".join(lignes) or "Ne traverse aucun autre element."

    def texte(self):
        if not self.ok:
            return "Impossible : %s." % self.raison
        return "%d troncon(s), %d raccord(s), %.2f m de reseau ajoute. %s\n%s" % (
            self.nseg, self.nracc, self.long * 0.3048, self.msg, self.avertissement())


def executer(doc, e1, e2, c1, c2, sol):
    """Cree la liaison (dans une transaction ouverte). Retourne les ids crees."""
    avant = _ids(doc)
    if sol.mode == "auto":
        sol.msg = rel.relier(doc, e1, e2)
    else:
        n, c, m = tr.build_route(doc, e1, c1.Origin, sol.points, e2, c2.Origin)
        sol.msg = m
    doc.Regenerate()
    from System import Int64
    return [DB.ElementId(Int64(k)) for k in sorted(_ids(doc) - avant)]


def _essayer(doc, e1, e2, sol, univ):
    e1, e2, c1, c2 = bouts(e1, e2)
    pa, da, pb, db = c1.Origin, rel.out_dir(c1), c2.Origin, rel.out_dir(c2)
    if sol.mode == "90":
        sol.points = points_90(pa, da, pb, db)
    elif sol.mode == "45":
        sol.points = points_45(pa, da, pb, db)
    pre = ac.touches(doc, e1, univ) | ac.touches(doc, e2, univ)
    t = ac.tx_debut(doc, "Allan BIM - essai liaison")
    try:
        ids = executer(doc, e1, e2, c1, c2, sol)
        sol.nseg = sol.nracc = 0
        sol.long = 0.0
        soi = set([ac.eid(e1.Id), ac.eid(e2.Id)] + [ac.eid(i) for i in ids])
        post, vs = set(), set()
        for i in list(ids) + [e1.Id, e2.Id]:
            el = doc.GetElement(i)
            if el is None:
                continue
            post |= ac.touches(doc, el, univ)
            vs |= ac.voisins(el)
        for i in ids:
            el = doc.GetElement(i)
            if rel.is_curve(el):
                sol.nseg += 1
                sol.long += el.Location.Curve.Length
            else:
                sol.nracc += 1
        # ce que le trace traverse : jamais bloquant, mais signale et penalise
        sol.structure, sol.reseaux = {}, 0
        for k in post - soi - pre - vs:
            el = ac.element(doc, k)          # projet ou maquette liee
            if el is None or el.Category is None:
                continue
            if ac.eid(el.Category.Id) in STRUCTURE:
                n = el.Category.Name
                sol.structure[n] = sol.structure.get(n, 0) + 1
            else:
                sol.reseaux += 1
    finally:
        t.RollBack()


def solutions(doc, e1, e2, univ):
    sols = [Sol("Variante 1 - Liaison automatique (la plus courte)", "auto"),
            Sol("Variante 2 - Angles droits (coudes a 90 deg)", "90"),
            Sol("Variante 3 - Coudes a 45 deg (moins de pertes de charge)", "45")]
    for s in sols:
        try:
            _essayer(doc, e1, e2, s, univ)
            s.ok = True
        except Exception as ex:
            s.raison = str(ex).split("\n")[0][:140]
    oks = [s for s in sols if s.ok]
    if oks:
        min(oks, key=lambda s: s.cout()).reco = True
    return sols


class Zone(object):
    """Ce qu'il faut a allan_clash.preparer_vues pour cadrer les deux bouts."""
    def __init__(self, e1, e2):
        e1, e2, c1, c2 = bouts(e1, e2)
        self.a, self.b = ac.Net(e1), ac.Net(e2)
        self.pt = (c1.Origin + c2.Origin) * 0.5
        self.portee = c1.Origin.DistanceTo(c2.Origin)
        self.zoom = max(1.0, (self.portee / 2.0 + 800 * MM) / (1500 * MM))
